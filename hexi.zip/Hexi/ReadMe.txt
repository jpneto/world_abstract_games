Hexi, Hexi for Kids
-------------------
Implemented by Stephen Tavener, July 2000;
based on Octi (tm), US patent # 6,182,967, by Donald Green.


Objective: To win, get any of your pieces onto one of your 
opponent's Hexi spaces (shown in blue on the board).

Each player starts with 5 pieces (pods) and 19 prongs. 
A move consists of either:
(a) adding a prong to a piece
(b) moving a piece in the direction of one of its prongs
(c) dropping a pod on an empty Hexi space (some variants only)
(d) making one or more jumps in the direction of a prong.

When jumping, you may choose to capture any jumped piece - 
friend or enemy.


Also included is Hexi for Kids - a simplified version of the 
program which is easier for children (and computers) to play. 
In this version:
- players have unlimited prongs
- jumping an opponent's piece always captures it
- jumping a friendly piece never results in a capture.


You can find out more about OCTI (tm), on which Hexi is based,
at http://www.octi.net/


You'll find more rules files for download on Stephen's web site 
at http://scat.demon.co.uk/free.html

----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Hexi.zrf" in the Open dialog and click "Open"

Hexi.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

