Shisima
-------

Shisima means "body of water" in Kenyan. It's very simple 3-in-row game.
The pieces are called imbalavali which translates to "water bugs" as the 
pieces move quickly on the board as water bugs do on the surface of a lake.

Goal: To create a '3 in-a-row' of one's pieces running through the middle 
of the octagonal board.

See also: https://glukkazan.github.io/arrange/shisima.htm
