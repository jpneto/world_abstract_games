function PopItUp (url,w,h) {
var winstr='location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,width='+w+',height='+h;
window.open(url,'fonster',winstr);
void(0);
}

function PopNoScroll (url,w,h) {
var winstr='location=no,menubar=no,scrollbars=no,status=no,toolbar=no,width='+w+',height='+h;
window.open(url,'fonster',winstr);
void(0);
}

function PopItUpRedirect (url,w,h,url2) {
var winstr='location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,width='+w+',height='+h;
document.location=url2;
window.open(url,'fonster',winstr);
void(0);
}

function PopNoScrollRedirect (url,w,h,url2) {
var winstr='location=no,menubar=no,scrollbars=no,status=no,toolbar=no,width='+w+',height='+h;
document.location=url2;
window.open(url,'fonster',winstr);
void(0);
}

function NewWin (url) {
window.open(url,'fonster','location=yes,status=yes,menubar=yes,toolbar=yes,resizable=yes,scrollbars=yes');
void(0);
}

function swapImage(image,mode) {
var imagelocation="http://www.passagen.se/img/local/frontpage/32/";
if (document.images)
	document.images[image].src = imagelocation+image+"_"+ mode+".gif";
}

function spelbutik(spel){
  if(spel == 999){spel = 'liveservice'}
  var url = 'http://www.passagen.se/ego/R4/http://www.svenskaspel.se/includes/partnerxp.asp?act=sb&produkt=' + spel + '&vsid=656799';
  var name=(spel=='liveservice'?'liveservice':'spelbutik');
  window.open(url, name, 'resizable=yes,status=no,menubar=no,scrollbars=no');
  return false;
}

function getCookie(NameOfCookie){ 
if (document.cookie.length > 0)
{ begin = document.cookie.indexOf(NameOfCookie+"=");
if (begin != -1)
{ begin += NameOfCookie.length+1;
end = document.cookie.indexOf(";", begin);
if (end == -1) end = document.cookie.length;
return unescape(document.cookie.substring(begin, end)); }
}
return "";
}
