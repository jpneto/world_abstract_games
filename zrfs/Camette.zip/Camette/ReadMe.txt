Camette
Game (c) 2002  Michael W. Nolan 
Based on Camelot, invented by George S. Parker in 1887
Rules file and graphics (c) 2002-03  W. D. Troyka
dtroyka@justice.com


(Requires ZoG version 1.2.3 or higher)

Camette is a surprisingly entertaining miniature version of George S. Parker's famous boardgame Camelot.  The board contains only 23 squares and each player starts with only four pieces.  Despite these limitations, the game is quite challenging and remains -- to date -- unsolved.  The original Camelot was invented by Parker in 1887, and Camette was invented in 2002 by Michael W. Nolan, president of the World Camelot Federation (see http://communities.msn.com/worldcamelotfederation).  To get a sense of the unexpected twists of the game, check out the `problem` saved game that comes with the file.  Red has a forced win. 

Camette is played on a 5x7 board, with three squares removed from each of the corners to give the board an oval shape.  To see a notation key, select "Switch Piece Set" from the View menu.  A single space protrudes from both the top and bottom of the board.  This space is called the "castle."  The object of the game is to move a piece into the enemy castle.  You also win by capturing all opponent pieces.  Stalemate is a loss.

Each player starts the game with four pieces, consisting of three Men and one Knight.  A Man has three basic moves.  It may move one space in any direction, orthogonal or diagonal.  This is called a "plain" move.  It may jump over a friendly adjacent piece and continue jumping, at its option, as long as friendly pieces remain to be jumped.  This move is called "cantering."  And it may jump over an enemy piece, thereby capturing it, in which case it must continue jumping as long as captures are available.  A Man may not canter and capture in the same move. 

The Knight has all the moves of the Man plus one important addition, called the Knight's "charge."  A charge consists of a cantering move (or series) followed by capturing.  Once a Knight makes a capture, it must continue making captures if available and may not return to cantering.

Circular canters, i.e., canters that return to an already visited square, are not permitted. Visited squares are indicated by flags.  The flags are cleared at the end of the cantering sequence.  To pass on further canters, move the piece to the Knight graphic of your color in the lower left or upper right corner of the board.  The piece will not actually change location.

Capturing is compulsory but there is no requirement of choosing a path of maximal captures.  A player is not required to make a Knight's charge, with the exception that when a capture is directly available, the player may satisfy the compulsory capture rule through a Knight's charge.  When cantering a Knight must make a capture if one becomes directly available but may do so through a charge.

You may not enter your own castle except through a capture, in which case the piece must be moved out as soon as possible.  If the piece cannot move out through another capture on the same turn, then it must be moved out on the next turn (even if this means declining a capture elsewhere on the board).  When moving out of the castle, jumps take priority, although the obligation to jump can be satisfied through a charge.

In the Camette All Knight variant each player starts with four Knights."
Please send any comments or bug reports to dtroyka@justice.com. 


----------------------------------------------------------------

To play:

Double click the Camette game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Camette.zrf" in the Open dialog and click "Open"

Camette.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play 
any number of games against the computer or over the Internet. 
Zillions of Games can be purchased online.  For more information,
please visit the Zillions of Games website:

              <http://www.zillions-of-games.com> 


 