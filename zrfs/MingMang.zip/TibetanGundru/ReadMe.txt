******************************************************************************
*** Gundru (Gun-dru, Mig-mang, Ming-mang) is a traditional game from Tibet ***
***                                                                        ***
*** Programmed by Greg Schmidt at the request of Mats Winther.             ***
*** gschmidt958@yahoo.com                                                  ***
***                                                                        ***
*** Utilizes the Axiom Meta-Game System.                                   ***
*** Copyright 2010.  All rights reserved.                                  ***
******************************************************************************

Gundru (Gun-dru, Mig-mang, Ming-mang) is a traditional game from Tibet. It is played on a 9x9 grid with
16 pieces initially placed on the board, and equally many are kept in the reserve. The object is to capture
the enemy stones. Stones slide orthogonally in any direction, like the chess rook. Capture is done by
enclosing a row of enemy stones between two of one's own. Many stones can be captured at the same
time, both vertically and horizontally. Capture can occur over corners, when a line of stones makes a
perpendicular turn anywhere on the board. Captured stones are immediately removed and replaced with
friendly stones. When a player has only one stone left, it acquires the capability to capture by the short leap,
one jump at a time. Capture is not mandatory. The game ends when one player has no remaining stones,
has no available moves, or if a player builds an impenetrable fortress and only moves pieces within it,
then the other party shall be regarded as the winner (note: the latter case is NOT automatically detected).

It is important to gain space, thus leaving the enemy with fewer move freedoms. As this game uses the
ancient interception capture, it is probably quite old. (There seem to exist other references to Mig-mang or
Ming-mang where the rules described are not the correct ones.)

For more information and to download a free stand-alone version of the game, see:
http://hem.passagen.se/melki9/gundru.htm
http://games.groups.yahoo.com/group/axiom-system/ (see `Files`)")


