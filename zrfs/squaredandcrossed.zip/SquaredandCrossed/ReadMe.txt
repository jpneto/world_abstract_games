Squared and Crossed
-------------------
Implemented by L. Lynn Smith, March 2001.

Special Thanks to CrystalVision Software, the makers of MILO,
This game resembles one of that game's challenges which this one 
was founded on.  


Squared and Crossed uses the following rules:
1.  Squares move and capture one space orthogonally.
2.  Crosses can jump and capture up to two spaces diagonally.
3.  Squares can only capture Crosses.
4.  Crosses can only capture Squares.
5.  A player wins by capturing either all the Crosses or all the 
    Squares of the opponent.


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "SquaredandCrossed.zrf" in the Open dialog and click "Open"

SquaredandCrossed.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

