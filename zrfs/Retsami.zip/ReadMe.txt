RETSAMI
-------

Retsami was invented by John Wildsmith (www.retsami.com) in 2006.

Zillions implementation by Luis Bola�os Mures.

--------------------------------------------------------
To play:

Double click the Retsami game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Retsami.zrf" in the Open dialog and click "Open"

Retsami.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com>