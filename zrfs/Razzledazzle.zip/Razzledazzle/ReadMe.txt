Razzledazzle v1.0
-----------------
Invented by Don Green (boardgame version distributed by FamilyGames).
Implemented by Karl Scherer, October 2005


Object: Be the first player to pass a ball to the opponent's end of the board

There are five pieces (light or dark) and one ball per side.
You must either move one of your pieces or pass your ball.
Pieces move like knights to any empty square.
The piece with the ball may not move.
The ball may be passed in a straight unobstructed line to any of your pieces.  The ball may passed horizontally, vertically, or diagonally.
You may pass the ball as many times as you like on a given turn, so long as no piece touches the ball more than once.
When you are done with the partial moves, click the lightning sign at the menu bar.

You win when you have passed your ball to the opponent's end of the board.

There is also a 'Tournament Variant'.
For its special rules see its associated game text.

This game now needs Zillions V2.0 to run.


More freeware and real puzzles and games at my homepage: karl.kiwi.gen.nz .
     

----------------------------------------------------------------
To play:

Double click the Razzledazzle icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Razzledazzle.zrf" in the Open dialog and click "Open"

Razzledazzle.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
		  <http://www.zillions-of-games.com> 

 
