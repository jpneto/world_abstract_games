Symphony
--------
Invented and implemented by Edoardo Annunziata, May 2009.

Players alternate in dropping stones "men" on the board (a player may place up to six men) or moving the ones which have been already dropped. Men can move one square forward or sideways, but not backwards. There is no capture.

The first player to line up five men orthogonally or diagonally wins.

----------------------------------------------------------------
To play:

Double click the "Symphony.zrf" game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Symphony.zrf" in the Open dialog and click "Open"

Simphony.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 