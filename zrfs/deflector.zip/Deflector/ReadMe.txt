Deflector v1.1
--------------
Invented and implemented by Karl Scherer, July 2001.
Updated May 4, 2002: corrected text.


Object: Move all your pieces to your opponent's starting positions.
(3 variants)

Deflector Moves:
If the piece is adjacent to a piece directly ahead,
then the piece may one step forward (North) and then 
sideways an arbitrary number of empty squares.

Similarly, if the piece is has a piece to the left or right of it,
then it may also move to this enemy piece and then North an arbitrary 
number of empty squares.

You may execute several Deflector Moves in a row, using the same piece.
In the default variant, you cannot pass such a partial move.

Deflector moves have priorities over any other moves.

Sliding Moves:
A Token moves one or two steps forward or sidewards to an empty square.

Jumps:
Forward, diagonally forward and sideways jumps are allowed
over enemy pieces, but only if the move starts on one of the first two ranks.

There are no captures in this game.

Variant 2: You may pass a partial move.
Variant 3: Like variant 1, but backward Deflector moves are allowed.
           You may pass a partial move. 

Recommended: Switch Move Animation on!


The game Deflector introduces a new type of moves, the 'Deflector Moves',
into the area of classic Checkers-type board games. 


More freeware as well as real puzzle and games 
at my homepage: http://karl.kiwi.gen.nz .


----------------------------------------------------------------
To play:

Double click the Deflector icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Deflector.zrf" in the Open dialog and click "Open"

Deflector.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
