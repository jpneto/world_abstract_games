   Designed by Larry Wheeler, 1982-2003.
   Zillions Implementation by Larry Wheeler, September 2003.

   In Kroma, the pieces have no fixed powers of movement. Rather, the legal moves of each
   piece are determined by which friendly pieces are currently sitting on squares of the
   piece's color:

     Purple enables friendly pieces to move one square orthogonally (horizontally or vertically).

     Yellow enables friendly pieces to move one square diagonally.

     Blue enables friendly pieces to move two squares orthogonally (horizontally or vertically).

     Orange enables friendly pieces to move two squares diagonally.

     Red enables friendly pieces to make "vertical knight moves", i.e., move two spaces vertically
       and one space horizontally.

     Green enables friendly pieces to make "horizontal knight moves", i.e., move two spaces horizont-
       ally  and one space vertically.

   For example, a White Orange piece on a Blue square enables both of White's Blue pieces to move two
   squares diagonally.

   The game starts in a Placement Phase: two dots appear near the center of an empty board. Click a
   dot, and select a color of square to drop. A new dot will appear, so the next square can be dropped
   on either side. The squares will be centered automatically to allow more room. The two players
   alternate. When one square of each color has been dropped, the squares are extended to columns of 
   the same color, and pieces are placed on their own color squares in the first two and last two rows.
  
   Then the Movement Phase begins, where the object is to stalemate the opponent. Capture is by displace-
   ment.

   Including the standard version, there are 36 variants, allowing for alternate move rules, and more
   complex and/or random setups:

   In the Public variants, the legal moves of each piece are determined by which *friendly and enemy* 
   pieces are currently sitting on squares of the piece's color. In the Reversed variants, the legal
   moves of each piece are determined by which *enemy* pieces are currently sitting on squares of the
   piece's color.

   In the Flipped variants, the Black side of the board has the colors flipped left-to-right from White's,
   instead of mirrored as in the standard variant.

   In the Intermediate variants, after the initial row 4 of squares is set up, these are copied to row 3,
   the players take turns setting up row 2 with one square of each color, and then this is copied to row 1.
   The Advanced variants are similar, but with all four rows set up by the players.

   In the Random variants, a random player sets up both sides. Press the green start button to have
   Zillions set up the position. The Movement Phase is normal.

   Also included are the 4x6 Basic Kroma (24 variants) and the 2x4 Baby Kroma (12 variants).

   Implementation note: due to the dynamic board, when a piece is moved, the part of the square it's
   leaving will appear to be transparent for a moment, then fill in. Also, all piece moves will appear as
   captures in the notation.

   Kroma is an improved and expanded successor to Capriccio (www.flash.net/~markthom/html/capriccio.html).
   More information, as well as portable Kroma sets, will soon be available at the new website
   www.varigames.com. 

