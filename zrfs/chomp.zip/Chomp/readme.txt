CHOMP
-----

Chomp is a 2-dimensional Nim game.
It was invented by David Gale, who also studied the game mechanics of the game.
The game was presented by Martin Gardner in one of his Mathematical Games columns
in Scientific American. Later that column was published as a chapter in Gardner's
book Knotted Doughnuts and Other Mathematical Entertainments (published by
W.H. Freeman and Co 1986, ISBN 0-7167-1799-9).

Surprisingly little is known about the game. Gale himself found the following
facts:

1) Played on a rectangular board, the game is always a win for the first player.
2) If the board is square, the winning first move is taking the piece on b2.
3) On a 2-by-N or N-by-2 board the winning move is to take the top-right single
   piece.

There are also some other results, but not much more. For instance, no general
strategy is known which would be applicable to any position.

Installation:

Copy the files into a separate directory. Copy the *.wav files into the Audio
directory in your main Zillions directory, if you're not running from a CD.
If you're running from a CD, I must apologize for not getting the sounds work
out right for you.  Don't worry though, you don't miss that much.

----------------------------------------------------------------------
Zillions of Games is available from http://www.zillions-of-games.com
