Lines of Action
---------------
Invented by Claude Soucie, circa 1969.
Implemented by Seo Sanghyeon, December 7, 2002.


The object of the game is to move your pieces until they are all in one
connected group. Diagonals are considered to be connected.

More info can be found on 
http://www.msoworld.com/rules/linesofaction-t.html 
Mind Sports rule page. 

http://www.andromeda.com/people/ddyer/loa/loa.html 
Dave Dyer's home page is a rich source of informations. 

http://www.student.nada.kth.se/~f89-cvb/loa.html 
And this is Carl Von Blixen's.


Lines of Action was invented by Claude Soucie, circa 1969, and described
in A Gamut of Games by Sid Sackson.


----------------------------------------------------------------
To play:

Double click the loa icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "loa.zrf" in the Open dialog and click "Open"

loa.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
