Ximaera
-------
Invented and mplemented by L. Lynn Smith, December 2001.


Ximaera is a two-player game utilizing a hexagonal field of three 
cells wide.  There are twelve playing pieces: three Pivots, three 
red Pips, three blue Pips and three yellow Pips.
All pieces are considered neutral and can be controlled by either 
player.

Players may, at a turn, either enter a piece onto the playing field 
or move a piece which is on the playing field.  Pieces introduced 
onto the playing field must be placed on a vacant cell.  Both Pivots 
and Pips may move on the playing field by sliding through directly 
adjacent empty cells.  Pivots may also move by jumping an adjacent 
piece.  Regardless of the type of move, all pieces must land upon 
vacant cells.  There is no taking in this game.

No piece which is directly adjacent a Pivot may be moved, that 
includes fellow Pivots.  A player may not move a piece which was 
last moved by the opponent.

The game is won when three of a kind become adjacent, this includes 
both Pivots and Pips.  Such adjacency can form either a straight line, 
a bowed line or a triangle.
A player can also win if the opponent does not leave the opportunity 
of at least one move.
A player will lose the game if the same position is repeated three times.


Ximaera was designed by L. Lynn Smith. The Ximaera, pronounced with a 'k', 
is a fantastic fire-breathing creature formed of a lion's head, a serpent's 
tail and a goat's body.


This game may appear to be a simple alignment game.  On the surface, 
this is true, but underneath it is also a move-elimination game.

Remember that all pieces which are adjacent Pivots may not be moved.  
If a Pivot becomes adjacent another, both of them can not be moved the 
remainder of the game.  Subsequently, any piece which is also adjacent 
or becomes adjacent is thus stuck for the game.  Creating these types 
of situations can lead to a stalemate win.  Just be careful of the 
opponent going for the three Pivot alignment.

Another technique is the formations around a Pivot, or Pip.  By 
strategically placing Pips of the same colour around a Pivot, or 
another Pip, the player has effectively created a 'frozen' piece.  
One that if moved would assure certain victory for the next player.  
After forming such a pattern, the player should attempt to reduce 
the number of moves available the opponent, forcing the movement of 
that particular piece.  This works best when the Pivot is the center 
of such formation since it must be moved before the others.

It is also possible to win the game without placing all the pieces 
on the board.  The new introduction of a piece is also of great 
consideration.  Even off of the playing field, that third piece can 
be dropped to complete an alignment.


----------------------------------------------------------------
To play:

Double click the Ximaera icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Ximaera.zrf" in the Open dialog and click "Open"

Ximaera.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
