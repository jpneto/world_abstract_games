Nosferatu
---------
Invented and implemented by Chris Huntoon, March 2003.


The countryside is being plagued by a horde of vampires, led by their 
dreadful lord, Nosferatu. A band of villagers has risen up, grabbed 
their torches and pitchforks and sharpened their wooden stakes to confront 
this menace. Unfortunately, any villager attacked by Nosferatu does not 
truly die but rather becomes a vampire under his control. The only hope 
the villagers have of stopping this ever growing army of the undead is to 
slay the head vampire, Nosferatu.

OBJECTIVE: For the Vampires, it is to eliminate all the Villagers. For the 
Villagers, it is to capture Nosferatu.

ACTIONS: A 'move' consists of one of three types of actions: Entering, 
Attacking, or Moving. An attacking move must be made whenever possible; 
when no attack is available, entering takes precedence over moving.

ENTERING: The board starts off empty. The Vampires have six pieces, 
consisting of Nosferatu plus 5 Vampires.  The Villagers have 12 Men.  
The Vampire player begins and places one of his pieces on any space on 
the board, except for the central hex. (Note: there is no particular order 
that the Nosferatu piece needs to be entered. It can be the player's first 
piece or his last, or anywhere in-between.) The players then alternate turns, 
placing their pieces on any open space on the board, with the restriction 
that a piece may not placed in any space that can come under immediate attack 
by an opponent's piece. The players must enter all their pieces on the board 
before they are allowed to move any of them. Thus the Vampires, who have half 
as many pieces as the Villagers, will usually begin moving first.

ATTACKING: Both Villagers and Vampires make captures as in Checkers, jumping 
over an opponent's piece to the empty space just beyond and continuing to 
jump and capture as long as it is possible. Jumps may be done in any of the 
six directions defined by a row of hexes.

Nosferatu, with his ability to change into a bat and fly, has far greater 
maneuverability than any other piece in the game. He may travel over any 
number of empty hexes on either side of a jump. Like the rest of the pieces, 
if he can continue jumping he must do so. When Nosferatu attacks a Villager, 
he has the choice of removing them from the board or having them remain in 
their position and be converted into Vampires.

Since we are dealing here with a bunch of bloodthirsty vampires and riotous 
villagers, all attacks are compulsory. Attacking takes precedence over any 
other action, including entering a piece. When given a choice of attacks, a 
player need not choose the move that results in the greatest possible number 
of attacks.

MOVING: A player may move a piece only when he has no more pieces to enter 
onto the board and when he has no attacks to make. Moving for both Vampires 
and Villagers consist simply of stepping onto an adjacent, empty cell.

Again, Nosferatu can fly as a bat, and so travel farther then the rest of 
the pieces. He may move any number of spaces along an open row.


----------------------------------------------------------------
To play:

Double click the Nosferatu icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Nosferatu.zrf" in the Open dialog and click "Open"

Nosferatu.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

