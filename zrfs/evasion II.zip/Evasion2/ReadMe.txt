Evasion II
----------
Invented and implemented by Karl Scherer, August 2001.


Object: Move all your pieces to the last two ranks of the board.
(2 variants)

All pieces move the same way. 
Various Chess pieces are used for the sole purpose to indicate where
the pieces have to end up.
E.g. the white King on e1 has to end up on e8.

Sliding Moves:
(Note that these are different from the original Evasion game).
A Token slides one or two empty squares into any direction.
Sideways or backward slides are only allowed when there are no forward moves.
There is one exception: Once you have cleared the first two ranks, 
you can slide sideways and backwards if your move starts on rank 7 or 8.
(for Black on rank 1 or 2).

Evasive Moves:
If the piece faces a piece directly ahead (to the North),
then it may also move diagonally forward any number of empty squares.
You may execute several such 'evasive moves' in a row, using the same piece.
At the end of such a series of evasive moves you have an additional 
sliding move available.
You may pass a partial move. 

There are no captures in this game.

Variant 2: Forward, diagonally forward and sideways jumps are allowed
   over enemy pieces, but only if the move starts on one of the first two ranks.

Recommended: Switch Move Animation on!


More freeware and real puzzles and games at my homepage: karl.kiwi.gen.nz .


----------------------------------------------------------------
To play:

Double click the Evasion2 icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Evasion2.zrf" in the Open dialog and click "Open"

Evasion2.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
