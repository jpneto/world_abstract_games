Spark
-----
Invented by John Pursey & Matt Ryan,
implemented by Joseph Peterson, August 2001.


A Magical Game of Pure Strategy for Two Players

A WAVE OF THE WAND...
You're an old, dried up wizard with an attitude.  You don't have enough magic
left to cause any real damage, but you can at least beat the stars and moons
underpants off an old buddy in a friendly sorcerer's strategy game.  Five
magic Orbs supply mystical energy to six Sparks.  The more powerful the Sparks
become, the more quickly and easily you'll be able to upstage your old pal in
front of your peers.  Merlin would have been proud.

OBJECT OF THE GAME
With the Orbs to power your strategy, use your Sparks to capture rival Sparks
and to render your opponent unable to make a move.

THE MAGICAL CIRCUITRY
Your Orbs supply magical energy to your Sparks through Energy Lines.  An
Orb powers a Spark by resting anywhere along either of the Energy Lines that
makes up the intersection upon which the Spark lies.  More than one Orb can
charge the same Spark through the same line.  The larger the number of Orbs
supplying magic to a Spark, the higher the Spark's Magical Charge.  The
larger the number of Sparks an Orb supplies magic to, the farther the Orb
can move.

MOVEMENT AND STRATEGY
A turn consists of moving either a Spark or an Orb.  All pieces move along
the intersections of the Energy Lines.  No piece may jump over another or
occupy the same intersection.

WINNING
If your opponent is unable to make a legal move, or if you have captured all
opposing Sparks, you win!

Right-click on the Sparks and Orbs for detailed information about how they move.


Spark(TM) was designed by John Pursey and Matt Ryan.  
It was listed as one of Games Magazine's 100 favorite games in both 1999 and 2000.

Spark(TM) Zillions of Games Edition (c)2001 John Pursey & Matt Ryan.
Spark(TM) Zillions of Games Edition Implementation by Joseph Peterson.
Spark(TM) Original Board Game (c)1991, 1996, 1997, 1998  John Pursey & Matt Ryan.
Published by Envelope Games(TM).
Spark(TM) is an exclusive trademark of John Pursey and Matt Ryan. All Rights
Reserved.
Envelope Games(TM) is an exclusive trademark of Matt Ryan and Envelope Games.
All Rights Reserved.
Envelope Games - 176 Fountain View Drive, Ames IA 50010
EnvGames@hotmail.com - http://showcase.netins.net/web/envgames/


----------------------------------------------------------------
To play:

Double click the Spark icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Spark.zrf" in the Open dialog and click "Open"

Spark.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
