Tunneler
(c) 2002  W. D. Troyka
dtroyka@justice.com


You were supposed to dig a tunnel connecting England and France but 
somebody lost the map. Now your crew is somewhere under the North 
Atlantic between Ireland and Iceland.  The English workers (Red) blame 
the French and the French workers (Blue) blame the English.  You have 
decided to settle the matter with a death match.

Each player has six pieces, including four Tunnelers and two Foremen. 
The board is filled with bedrock at the start of the game.  Tunnelers 
move like Rooks.  At the end of a move they can capture an enemy piece 
or dig out one block of bedrock.  Foremen move and dig like Tunnelers 
but they cannot capture.   A piece cannot make a move that results in a
2x2 grid of dug-out squares.  Such structures are unstable and lead to
collapse. 

Win by capturing an opponent Foreman.  Stalemate and repetition are 
losses.

As the game progresses, the pieces dig out a maze of passageways 
through the bedrock.  By lining up multiple Tunnelers on a straight 
passageway, a player can attack an enemy Tunneler and force an 
exchange or a retreat.  When a Tunneler attacks an enemy Foreman, 
the Foreman usually has to run away.  The game is often won by 
trapping a Foreman in a dead end.

Tunneler is played in an 11x11 grid of bedrock.  In the variant the 
grid is 15x15 and the players each have ten Tunnelers.


----------------------------------------------------------------

To play:

Double click the Tunneler game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Tunneler.zrf" in the Open dialog and click "Open"

Tunneler.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play 
any number of games against the computer or over the Internet. 
Zillions of Games can be purchased online.  For more information,
please visit the Zillions of Games website:

              <http://www.zillions-of-games.com> 
