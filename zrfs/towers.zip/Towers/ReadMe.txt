Towers
-------------------------------------------------------------
Designed and Implemented by Peter Aronson, September 2001.
-------------------------------------------------------------
The goal of Towers is to capture the opposing Castellan by 
intervention (getting between) or interception (surrounding), 
or to move your Castellan to your opponent's red square.  A 
player with no legal moves also loses.

This game was synthesized from a number of sources: description
of the obscure Thai and Malay games of Mak-yek and Apit-sodok from 
Murray's A HISTORY OF BOARD GAMES OTHER THAN CHESS, Vuthy Tan's 
description of the game of Rek from his article "Cambodian Chess 
Games", the Japanese game of Hasami Shogi, the old Viking game of 
Hnefatafl, and a little bit of Checkers.

The piece graphics are from David Howe's Alfaerie set.

The game often revolves around long series of forced captures.  It is
often necessary to consider where a sequence will end up before starting
one.  Careless play results in very short games.
-------------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "towers.zrf" in the Open dialog and click "Open"
-------------------------------------------------------------------
"towers.zrf" is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
-------------------------------------------------------------------
Contact: peter@chessvariants.com
