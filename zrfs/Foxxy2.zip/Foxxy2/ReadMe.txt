Foxxy2 by Bob Henderson

Versions of this game date back to the medieval Vikings. Can you
move the Geese to block the Fox from escaping? This new version
features eleven boards in various sizes for which the difficulty
of blocking the Fox varies from pretty easy to fiendishly tough!

----------------------------------------------------------------
To play:

Double click the Foxxy2 icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Foxxy2.zrf" in the Open dialog and click "Open"

Foxxy2.zrf is a rules file used by the Windows program
"Zillions of Games."  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more
information, please visit the Zillions of Games website at
              <http://www.zillions-of-games.com> 
