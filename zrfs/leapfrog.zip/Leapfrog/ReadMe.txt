Leapfrog
--------
Created by Chris Huntoon, May 2000.
Updated October 2000: fixed image problem with Windows NT/2000.


Frogs move by leaping over other frogs of either color.  
Enemy frogs lept over are captured.  Thus every capture not
only weakens the enemy by also reduces the player's own 
maneuverability. 

The game is lost when all of a player's frogs have been 
captured or the player is unable to move.


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Leapfrog.zrf" in the Open dialog and click "Open"

Leapfrog.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

