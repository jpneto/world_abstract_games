SideKicker

Ingo Althofer and Eiko Bleicher
Copyright August 2003; all rights reserved.


SideKicker is a board game for two players, Red and Blue. The board is a rectangular 7x6-grid, with permanent walls on the squares c3 and e4. The players move in turn. The last player to move is the winner. 

In his turn a player either has to jump forward one step. "Forward" means in direction north or north-west or north-east for player Red, and in direction south or south-west or south-east for player Blue. Or a player may capture an enemy stone by sidekicking to the west or the east.

In the basic game the second player has a simple winning strategy by mirror play. Zillions does not understand this. Nevertheless the program is a very tough opponent. Don't feel ashamed to try the handicap variant with 7 vs 6 stones against the computer.
