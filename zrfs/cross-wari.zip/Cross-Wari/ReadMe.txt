Cross-Wari

(c) 2001  W. D. Troyka
dtroyka@justice.com


Cross-Wari is a variant of the traditional Mancala game Wari, which 
is also available on Zillions.  Cross-Wari follows all the rules of 
Wari except that holes with an odd number of beans sow clockwise, 
whereas holes with an even number continue to sow counterclockwise.  
This results in new tactics that permit you to keep beans on your 
side of the board or to control the direction of sowing.  If the 
flow of beans in Wari can be described as a direct current, the 
flow in Cross-Wari is an alternating current. 

For a complete statement of the rules, please read the "Game 
Description" in the Help menu.  Cross-Wari comes with four 
variants.

NOTE:  Wari has been substantially revised to include three new 
variants, to increase hole capacity from 24 beans to 36 beans, and 
to optimize the code.  If you previously downloaded the game, I 
recommend that you download the new version.

Please send any comments or bug reports to dtroyka@justice.com.

You should extract the game from the downloaded zip file preserving 
path names. 

----------------------------------------------------------------
To play:

Double click the Cross-Wari icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Cross-Wari.zrf" in the Open dialog and click "Open"

Cross-Wari.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 