------------------------------------------------
*** MoonShot Chinese Checkers v1.0           ***
* *                                          * *
* *                                          * *
* * created by K. Franklin, April 2026       * *
* * e-mail address: kenf@yahoo.ca            * *
------------------------------------------------
Copyright 1998-2000 Zillions Development (v1.31)
*** Built upon Zillions' Checkers.zrf v1.2

You need to purchase Zillions of Games to load this rules file
Visit the Zillions web site at http://www.zillions-of-games.com
---------------------------------------------------------------

Inspired by the continuing contributions of Zillions' community as well as NASA's Artemis II space mission towards the Moon and Back.


Object:
-------
Move your Checker Marbles into the Top row then return the Return Checkers anywhere into the starting two rows' Home zone to win.

Players take turns, moving a single Checker Marble at a time.  A Checker Marble may move in one of two ways.  It may shift to any adjacent position or it may leap over an adjacent piece (of either color) to the opposite, unoccupied position.
A leaping Checker Marble may continue to leap over other pieces until there are no more pieces to leap over or the player decides to stop.  To stop leaping prematurely, select `Pass Move` from the menus or the toolbar.
There are no captures in Chinese Checkers.

To earn the win-condition, when Return Checkers land back into the two rows' Home zone, these pieces are switched into identical Win Checkers.  If a Win Checker leaves the Home zone, it is restored back to a Return Checker.  Eight 'Win' Checkers must be within the Home zone to win.
3-time repetition is also a loss-condition.


Move Priority Note:
-------------------
Normal Chinese Checkers is a simple draw, since neither side is forced to move all its marbles out of its starting position.  In this version, Beginning Marbles are not forced to move from their starting zone (there are enough positions for both sides), however Return Checkers in the Top row do need to immediately move by jumping any piece or making a single step.



Strategy:
---------
My limited testing indicated that Zillions doesn't play this game as I expected.  Marbles should chase towards the top row and dash back in order for the WIN eligible Return Checkers to appear.  Instead, it is reluctant to land on or leap towards the top row.

---------------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "MoonShotChineseCheckers.zrf" in the Open dialog and click "Open"

MoonShotChineseCheckers.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
