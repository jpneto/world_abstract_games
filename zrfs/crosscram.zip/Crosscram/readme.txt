CROSSCRAM
---------
Copyright (c) 1999 JP Ikaheimonen

Crosscram is a version of Cram, a game known since the 1950's.
Two players place domino-shaped pieces on a square board. Whoever
places the last piece, wins; in the mis�re (reverse) version the
player who plays last loses. In normal Cram players can put their
dominoes either way, vertically or horizontally, but in CrossCram
one player always plays horizontally whereas the other player
always plays vertically.

A note on the user interface: you place dominoes on the board
by clicking the board. A domino takes up two positions on the
board and you must make sure you click the correct one of
the two positions. If you play vertical pieces you must click at
the lower position; if you play horizontal pieces click at the
left side. 

This rule file has three different board sizes: 4x4, 6x6 and 8x8.
With normal and mis�re play the number of variations is thus six.

----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Crosscram.zrf" in the Open dialog and click "Open"

Crosscram.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

