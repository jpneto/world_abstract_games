GESS
----
Invented by the Puzzles and Games Ring of the Archimedeans Mathematics
Society, which is the mathematical society of Cambridge University (UK).
Implemented by L. Lynn Smith, September 2001.

Updated February 22, 2003: major code revision, plays very well now.


This is a chess variant played with GO Stones on a 20x20 board.

The 3x3 pattern of Stones form the pieces within the game and the
pattern denotes the move direction and power of the piece.

A 3x3 pattern without a Stone in its center may only move up to
three spaces, a 3x3 pattern with a center Stone may slide across
the entire board.

Only Stones of a single color may form a 3x3 pattern and any Stones
which land on the outer ranks and files of the board are immediately
captured.

The movement of a 3x3 pattern is accomplished in two phases. First
by selecting the center of the pattern. The 3x3 pattern will then be
high-lighted. Next move its center the desired number of cells.

Captures are accomplished when the 3x3 pattern encounters any other
Stones, friend or foe.

Each player must maintain a King 3x3 pattern, an empty space surrounded
by 8 Stones.  A player may have more than one King.

The game is won when an opponent has no King pattern at the end of a
move. A player at the end of their turn who does not have a King pattern
automatically loses, regardless of the opponent's condition.



GESS was invented by the Puzzles and Games Ring of the Archimedeans Mathematics
Society, which is the mathematical society of Cambridge University (UK).

The rules were first published, together with a sample game, by Paul Bolchover in
Eureka, Vol. 53, the periodical of the Archimedeans.

Zillions implementation by L. Lynn Smith.


----------------------------------------------------------------
To play:

Double click the GESS icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "GESS.zrf" in the Open dialog and click "Open"

GESS.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
