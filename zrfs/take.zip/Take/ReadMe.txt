Take
---------
Implemented in Zillions by Jeremy Deane

Take is a hexagonal version of Hasami Shogi created by Mike Woods
in 1984.

You should have extracted this zip file preserving path names.

----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Take.zrf" in the Open dialog and click "Open"

Take.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

