"Based on the game KUBA  copyright 1997 by Serge Cahu and published by  Patch Products, Inc. 

Kubatoo copyright July 2003 by Keith Carter

Scripted by the brilliant Dan Troyka who graciously offered to share scripting credit but deserves all the credit.
Graphics, sounds, multiple AI playing styles, and presentation format by Keith Carter     
Playtesting by Keith Carter, Dan Troyka, and David E. Whitcher



The object of the game is to collect seven red neutral marbles by pushing them off the board.
1) Each player takes turns pushing one of their marbles (Black or White) horizontally or vertically one space. 
2) A marble must have an empty space behind it to push it (off the board counts.) 
3) Marbles ahead of a pushed marble are also moved regardless of their color or how many. 
4) A marble is captured if it is pushed off the board.   Captured enemy marbles are removed from the board.  
    Captured neutral red marbles are placed in the capturing player's storage area.
5) Players may not capture their own marbles. 
6) To win a player mush collect seven red marbles.  It is also possible to win by eliminating all of an opponent's moves. 
7) A player may not make a move that puts the board back to the position it was before the opponent's last move.
    The game is scripted to enforce this restriction.


"Kubatoo comes with four AI opponents tailored to produce four significantly different playing styles.  Each of the four is a viable opponent.  Click anywhere on the main game board to start a game against a randomly selected AI opponent.  Play a particular AI opponent by choosing the proper variant.  

Kubatoo differs substantially from KUBA by segmenting a player's attack on a line of marbles over multiple turns and adding the tactics of interception, capping, sacrifice, and counter-attack.  See the game strategy notes under the help menu.

