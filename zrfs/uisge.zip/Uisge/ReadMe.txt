Uisge

Invented by Roland Siegers in 1984
Rules file and graphics (c) 2002  W. D. Troyka
dtroyka@justice.com


The players start the game with six Stars each.  A Star jumps
orthogonally over an adjacent piece of either color to an empty 
square beyond.  It changes into a King when jumping.  A King jumps 
like a Star and changes back into a Star.  In addition, a King can 
step one space orthogonally or diagonally to an empty square.  A 
King does not change into a Star when stepping.  There is no 
capturing.

All twelve pieces must remain orthogonally connected throughout the 
game.  If a move would break the connection and create two or more 
disconnected groups, it cannot be made.

Win by converting all six of your pieces to Kings.


----------------------------------------------------------------

To play:

Double click the Uisgi game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Uisgi.zrf" in the Open dialog and click "Open"

Uisgi.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play 
any number of games against the computer or over the Internet. 
Zillions of Games can be purchased online.  For more information,
please visit the Zillions of Games website:

              <http://www.zillions-of-games.com> 
