\ Festival Climbers - Four player variant

{players
	{player}	Red
	{player}	Blue
	{player}	Brown
	{player}	Orange
players}


{turn-order
	{turn}		Red
	{turn}		Blue
	{turn}		Brown
	{turn}		Orange
turn-order}

\ Table - Returns the player when indexed by a player index.
CREATE PlayerTable
Red , Blue , Brown , Orange ,

6 CONSTANT #Climbers

LOAD Festival-Climbers-Common.4th

\ The evaluation is the current player's score minus the average of all opponent scores.
\   (a bit ugly, but fast)
: OnEvaluate ( -- score )
	current-player Red =
	IF
		0 Scores @ 1 Scores @ 2 Scores @ + 3 Scores @ + 4 / -
	ELSE
		current-player Blue =
		IF
			1 Scores @ 0 Scores @ 2 Scores @ + 3 Scores @ + 4 / -
		ELSE
			current-player Brown =
			IF
				2 Scores @ 0 Scores @ 1 Scores @ + 3 Scores @ + 4 / -
			ELSE	\ Orange
				3 Scores @ 0 Scores @ 1 Scores @ + 2 Scores @ + 4 / -
			ENDIF
		ENDIF
	ENDIF
	ScoreFactor *	\ Enhance the emoticon.
;
