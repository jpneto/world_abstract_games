\ Festival Climbers - 2 Player game

{players
	{player}	Red
	{player}	Blue
players}


{turn-order
	{turn}		Red
	{turn}		Blue
turn-order}

\ Table - Returns the player when indexed by a player index.
CREATE PlayerTable
Red , Blue ,

12 CONSTANT #Climbers

LOAD Festival-Climbers-Common.4th

\ The evaluation is the current player's score minus the opponent's score.
: OnEvaluate ( -- score )
	0 Scores @ 1 Scores @ -
	current-player Blue = IF NEGATE ENDIF
	ScoreFactor *	\ Enhance the emoticon.
;