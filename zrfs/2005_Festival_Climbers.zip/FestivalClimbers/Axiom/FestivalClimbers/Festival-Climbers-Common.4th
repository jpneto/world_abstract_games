(
 *****************************************
 * Festival Climbers                     *
 *                                       *
 * Uses the built-in Axiom search engine *
 *****************************************
)

$gameLog OFF
$passTurnForced ON

10 CONSTANT ScoreFactor	\ Amplifies the score (eval) to enhance the emoticon effect.

{board
	{position} h1
	{position} g1 {position} g2
	{position} f1 {position} f2 {position} f3
	{position} e1 {position} e2 {position} e3 {position} e4
	{position} d1 {position} d2 {position} d3 {position} d4 {position} d5
	{position} c1 {position} c2 {position} c3 {position} c4 {position} c5 {position} c6
	{position} b1 {position} b2 {position} b3 {position} b4 {position} b5 {position} b6 {position} b7
	{position} a1 {position} a2 {position} a3 {position} a4 {position} a5 {position} a6 {position} a7 {position} a8

	\ Scoring
	{position} Red_Tens	{position} Red_Ones
	{position} Blue_Tens	{position} Blue_Ones
	{position} Brown_Tens	{position} Brown_Ones
	{position} Orange_Tens	{position} Orange_Ones

	4 {array} Scores	\ Each player's score is accumulated here.
	4 {array} Climbers	\ Contains the number of remaining climbers for each player.
board}

{directions
	\ For a climber at a given position, these directions take us to the climbers that we support.
	                          {link} SupportsRight a1 b1
	{link} SupportsLeft a2 b1 {link} SupportsRight a2 b2
	{link} SupportsLeft a3 b2 {link} SupportsRight a3 b3
	{link} SupportsLeft a4 b3 {link} SupportsRight a4 b4
	{link} SupportsLeft a5 b4 {link} SupportsRight a5 b5
	{link} SupportsLeft a6 b5 {link} SupportsRight a6 b6
	{link} SupportsLeft a7 b6 {link} SupportsRight a7 b7
	{link} SupportsLeft a8 b7

	                          {link} SupportsRight b1 c1
	{link} SupportsLeft b2 c1 {link} SupportsRight b2 c2
	{link} SupportsLeft b3 c2 {link} SupportsRight b3 c3
	{link} SupportsLeft b4 c3 {link} SupportsRight b4 c4
	{link} SupportsLeft b5 c4 {link} SupportsRight b5 c5
	{link} SupportsLeft b6 c5 {link} SupportsRight b6 c6
	{link} SupportsLeft b7 c6

	                          {link} SupportsRight c1 d1
	{link} SupportsLeft c2 d1 {link} SupportsRight c2 d2
	{link} SupportsLeft c3 d2 {link} SupportsRight c3 d3
	{link} SupportsLeft c4 d3 {link} SupportsRight c4 d4
	{link} SupportsLeft c5 d4 {link} SupportsRight c5 d5
	{link} SupportsLeft c6 d5

	                          {link} SupportsRight d1 e1
	{link} SupportsLeft d2 e1 {link} SupportsRight d2 e2
	{link} SupportsLeft d3 e2 {link} SupportsRight d3 e3
	{link} SupportsLeft d4 e3 {link} SupportsRight d4 e4
	{link} SupportsLeft d5 e4

	                          {link} SupportsRight e1 f1
	{link} SupportsLeft e2 f1 {link} SupportsRight e2 f2
	{link} SupportsLeft e3 f2 {link} SupportsRight e3 f3
	{link} SupportsLeft e4 f3

	                          {link} SupportsRight f1 g1
	{link} SupportsLeft f2 g1 {link} SupportsRight f2 g2
	{link} SupportsLeft f3 g2

	                          {link} SupportsRight g1 h1
	{link} SupportsLeft g2 h1

	\ For a climber at a given position, these directions take us to the supporting climbers.
	{link} SupportedByLeft b1 a1 {link} SupportedByRight b1 a2
	{link} SupportedByLeft b2 a2 {link} SupportedByRight b2 a3
	{link} SupportedByLeft b3 a3 {link} SupportedByRight b3 a4
	{link} SupportedByLeft b4 a4 {link} SupportedByRight b4 a5
	{link} SupportedByLeft b5 a5 {link} SupportedByRight b5 a6
	{link} SupportedByLeft b6 a6 {link} SupportedByRight b6 a7
	{link} SupportedByLeft b7 a7 {link} SupportedByRight b7 a8

	{link} SupportedByLeft c1 b1 {link} SupportedByRight c1 b2
	{link} SupportedByLeft c2 b2 {link} SupportedByRight c2 b3
	{link} SupportedByLeft c3 b3 {link} SupportedByRight c3 b4
	{link} SupportedByLeft c4 b4 {link} SupportedByRight c4 b5
	{link} SupportedByLeft c5 b5 {link} SupportedByRight c5 b6
	{link} SupportedByLeft c6 b6 {link} SupportedByRight c6 b7

	{link} SupportedByLeft d1 c1 {link} SupportedByRight d1 c2
	{link} SupportedByLeft d2 c2 {link} SupportedByRight d2 c3
	{link} SupportedByLeft d3 c3 {link} SupportedByRight d3 c4
	{link} SupportedByLeft d4 c4 {link} SupportedByRight d4 c5
	{link} SupportedByLeft d5 c5 {link} SupportedByRight d5 c6

	{link} SupportedByLeft e1 d1 {link} SupportedByRight e1 d2
	{link} SupportedByLeft e2 d2 {link} SupportedByRight e2 d3
	{link} SupportedByLeft e3 d3 {link} SupportedByRight e3 d4
	{link} SupportedByLeft e4 d4 {link} SupportedByRight e4 d5

	{link} SupportedByLeft f1 e1 {link} SupportedByRight f1 e2
	{link} SupportedByLeft f2 e2 {link} SupportedByRight f2 e3
	{link} SupportedByLeft f3 e3 {link} SupportedByRight f3 e4

	{link} SupportedByLeft g1 f1 {link} SupportedByRight g1 f2
	{link} SupportedByLeft g2 f2 {link} SupportedByRight g2 f3

	{link} SupportedByLeft h1 g1 {link} SupportedByRight h1 g2
directions}

\ Scoring.

\ Compile this to add points to a player's score.
: UpdateScore, ( points 0basedPlayerIndex -- )
	Scores +!
;

\ Generate the update to the current player's score indicator.
\   Compiles the score update and creates the score digits.
: UpdateScore ( points -- )
	DUP	\ Skip if no score addition.
	IF
		DUP COMPILE-LITERAL	\ Points
		current-player player-index DUP COMPILE-LITERAL \ 0basedPlayerIndex
		COMPILE UpdateScore,

		SWAP \ 0basedPlayerIndex points
		OVER Scores @ + \ Total points for this player.
		10 /MOD
		1+ Red_Tens 3 PICK 2* + change-type-at
		1+ Red_Ones 2 PICK 2* + change-type-at
	ENDIF
	DROP
;

\ Move generation.

\ Is pos a base level position?
: BaseLevel? ( pos -- ? )
	DUP a1 >= SWAP a8 <= AND
;

\ Compile this to reduce a player's remaining climbers.
: Climber--, ( 0basedPlayerIndex -- )
	Climbers --	
;

\ Compiles the code to reduce a player's remaining climbers.
: Climber-- ( -- )
	current-player player-index COMPILE-LITERAL
	COMPILE Climber--,
;

\ Generate climber drops.
: DropClimber
	here BaseLevel? verify	\ Climber may only be introduced at the base level.
	empty? verify
	current-player player-index Climbers @ 0> verify	\ Verify that there is an unplayed climber.
	drop			\ Drop the climber.
	Climber--		\ Reduce this player's remaining climbers.
	1 UpdateScore		\ Dropping a climber increments the player's score.
	add-move
;

\ Table - When indexed by position, returns the rightmost position within the level
\   immediately above it.
CREATE UpLimits
	               h1 C,
	             h1 C, h1 C,
	           g2 C, g2 C, g2 C,
	         f3 C, f3 C, f3 C, f3 C,
	       e4 C, e4 C, e4 C, e4 C, e4 C,
	     d5 C, d5 C, d5 C, d5 C, d5 C, d5 C,
	   c6 C, c6 C, c6 C, c6 C, c6 C, c6 C, c6 C,
	b7 C, b7 C, b7 C, b7 C, b7 C, b7 C, b7 C, b7 C,

\ Returns the last position that is above the current position.
: UpLimit ( -- upLimit )
	here UpLimits + C@
;

\ Table - When indexed by position, returns the number of points a climber is worth at this position.
CREATE LevelNumber
	               8 C,
	             7 C, 7 C,
	          6 C, 6 C, 6 C,
	         5 C, 5 C, 5 C, 5 C,
	       4 C, 4 C, 4 C, 4 C, 4 C,
	     3 C, 3 C, 3 C, 3 C, 3 C, 3 C,
	   2 C, 2 C, 2 C, 2 C, 2 C, 2 C, 2 C,
	1 C, 1 C, 1 C, 1 C, 1 C, 1 C, 1 C, 1 C,

\ Indicates if the current climber is supporting another climber that is above and left.
: SupportsLeft? ( -- ? )
	SupportsLeft		\ Go to the climber that is above and left.
	IF
		empty?
		IF
			FALSE	\ There's not a left climber to be supported.
		ELSE
			SupportedByLeft	DROP	\ Move to the other supporting climber's position.
			empty?			\ If no other supporting climber,
						\   then the original climber is a supporting climber.
		ENDIF
	ELSE
		FALSE	\ Must be at left edge of board as there's no left position.
	ENDIF
	back
;

\ Indicates if the current climber is supporting another climber that is above and right/
: SupportsRight? ( -- ? )
	SupportsRight		\ Go to the climber that is above and right.
	IF
		empty?
		IF
			FALSE	\ There's not a right climber to be supported.
		ELSE
			SupportedByRight DROP	\ Move to the other supporting climber's position.
			empty?			\ If no other supporting climber,
						\   then the original climber is a supporting climber.
		ENDIF
	ELSE
		FALSE	\ Must be at right edge of board as there's no right position.
	ENDIF
	back
;

\ Is the climber at the current position required in order to support another climber?
: SupportsClimber? ( -- ? )
	SupportsLeft?		\ Is the climber required to support the above left climber?
	IF
		TRUE		\ Required.
	ELSE
		SupportsRight?	\ Not required for above left climber, required for above right climber?
	ENDIF
;

\ Is the climber at pos supported by two climbers?
: SupportedByTwoClimbers? ( pos -- ? )
	here	\ Save position.

	SWAP DUP to	\ Make pos our new position and keep an extra copy around.
	SupportedByLeft DROP	\ Go to left supporting position.
	empty?
	IF
		DROP	\ pos
		FALSE	\ Not supported by 1, therefore not supported by 2.
	ELSE
		here from =
		IF
			DROP FALSE
		ELSE
			to	\ Go back to pos.
			SupportedByRight DROP	\ Go to right supporting position.
			here from =	\ Is supporting climber the climber that will move?
			IF
				FALSE	\ Yes, so it can't be moved.
			ELSE
				not-empty?	\ If not empty, this returns TRUE
			ENDIF
		ENDIF
	ENDIF

	SWAP to	\ Restore position.
;

\ Generate all climber moves.
: MoveClimber
	here a8 <= verify
	SupportsClimber? NOT verify
	UpLimit 1+ 0
	DO
		I empty-at?
		IF
			I SupportedByTwoClimbers?
			IF
				here I 2DUP move \ Move must precede score update to generate a proper move string!
				LevelNumber + C@ SWAP LevelNumber + C@ -	\ Compute point difference.
				UpdateScore	\ Generate the score update.
				add-move
			ENDIF
		ENDIF
	LOOP
;

{moves ClimberDrops {move} DropClimber moves}
{moves ClimberMoves {move} MoveClimber moves}


{pieces
	{piece}		D0
	{piece}		D1
	{piece}		D2
	{piece}		D3
	{piece}		D4
	{piece}		D5
	{piece}		D6
	{piece}		D7
	{piece}		D8
	{piece}		D9
	{piece}		Climber		{drops}  ClimberDrops
					{moves}  ClimberMoves
pieces}

(
**********
* Events *
**********
)

\ Resets the game.
: OnNewGame ( -- )
	4 0
	DO
		0 I Scores !
		#Climbers I Climbers !
	LOOP
;

(
  *************************************************************************************
  * End of game checks - These are substantial and more complex than the game itself! *
  *************************************************************************************
 
  The game can end in two ways.  The first and most likely is a player reaches the 8th level.  The second is if all players in
  a turn are unable to make a legal move.

  Once the game has ended a player receives points for each climber they have on the board equal to the level they are on.
  The player who has scored the most points wins.  In the case of a tie the player that has reached the highest level wins.
  If that does not break the tie the player that moved last wins.
)

\ These strings will be used as part of the comment in the end of game dialog.
: RedString    ^" Red"    ;
: BlueString   ^" Blue"   ;
: BrownString  ^" Brown"  ;
: OrangeString ^" Orange" ;

\ Table - List of all player names.  Indexed by player index.
CREATE PlayerStrings
' RedString , ' BlueString , ' BrownString , ' OrangeString ,

\ Workaround - Output a number of linefeeds in order to force the Zillions end of game text off dialog box.
: OverwriteZillionsText
	5 0 DO LF ^char LOOP
;

\ Displays the winner in the end of game dialog.  The winner must be explicitly displayed this way for
\   multi-player games where the winner is not determined immediately after the winning player's move.
: DisplayWinner ( winningPlayer -- )
	13 ^char player-index CELLS PlayerStrings + @ EXECUTE	\ Output winning player's name.
	^"  Wins!" 9 ^char 9 ^char OverwriteZillionsText
;

\ Obtain the score for the given player.
: PlayerToScore ( player - score )
	player-index Scores @
;

\ End of game check - Find the player with the most points.
\   The score must be unique across all players.

VARIABLE WinningPlayerIndex	\ Index into scores corresponding to the winning player.
VARIABLE WinningScore		\ The winning player's score.

: PointWin? ( -- FALSE or winningPlayer TRUE )
	\ Pass 1 - Examine all scores to find maximum score.
	0	\ Initial maximum score.
	$playerCount @ 0
	DO
		I Scores @ MAX	\ Track the maximum score.
	LOOP

	\ Pass 2 - Determine if maximum score is unique across all players.
	0	\ Occurrences counter.
	$playerCount @ 0
	DO
		OVER I Scores @ = \ High score match?
		IF
			1+			\ Count the occurrence.
			I WinningPlayerIndex !	\ Track the corresponding winner.
		ENDIF
	LOOP
	SWAP WinningScore !	\ Save the winning score.

	1 =	\ Is maximum score unique?
	IF
		WinningPlayerIndex @ CELLS PlayerTable + @	\ Yes, return winning player.
		TRUE
	ELSE
		FALSE	\ No, indicate winner not decided.
	ENDIF
;

\ End of game check - Scan the board looking for the highest level containing a climber with a winning score
\   unique to that player.

VARIABLE WinnerFound		\ TRUE if a winner was decided.
VARIABLE WinningLevel		\ Level at which the winning player was found.
VARIABLE WinningPosition	\ Position a which the winning player was found.

: HighestLevelWin? ( -- FALSE or winningPosition TRUE )
	WinnerFound ON	\ Assume a winner will be found this way.

	\ Find a climber on the highest occupied level.  Scan from top down.
	a8 1+ h1	\ Scan these positions.
	DO
		I not-empty-at?		\ Found a climber.
		IF
			I player-at PlayerToScore WinningScore @ = \ Climber has winning score.
			IF
				I LEAVE	\ Found a climber with a winning score.
			ENDIF
		ENDIF
	LOOP

	\ Track some information about this climber.
	DUP LevelNumber + C@ WinningLevel !
	DUP WinningPosition !

	\ Scan this level.  If no enemy climbers with a winning score, then we found our winner.
	BEGIN
		1+	\ Next position.
		DUP LevelNumber + C@ WinningLevel @ =	\ Same level?
		IF
			DUP not-empty-at?	\ Climber here?
			IF
				DUP player-at WinningPosition @ player-at <>	\ Is another player's climber here?
				IF
					DUP player-at PlayerToScore WinningScore @ =	\ Yes, does climber have a winning score?
					IF
						WinnerFound OFF		\ Yes, winner not decided.
						TRUE	\ Exit loop.
					ELSE
						FALSE			\ Another player found, but with losing score, continue scanning.
					ENDIF
				ELSE
					FALSE				\ Same player here, continue scanning.
				ENDIF
			ELSE
				FALSE	\ Empty position, continue scanning this level.
			ENDIF
		ELSE
			TRUE	\ New level - exit loop.
		ENDIF
	UNTIL
	DROP	\ Position.

	\ If a winner was found return it.
	WinnerFound @
	IF
		WinningPosition @ player-at
		TRUE	\ Indicate winner found.
	ELSE
		FALSE	\ Indicate winner not found.
	ENDIF
;

\ Given a turn offset, returns the previous turn offset.
: PreviousTurnOffset ( turnOffset -- previousTurnOffset )
	$playerCount @ 1- 0	\ Advance the turn by #Players-1 turns.
				\   This takes us to the previous player's turn.
	DO next-turn-offset LOOP
;

\ Return the player that most recently moved and has a winning score.
: LastMovedPlayer ( -- player )
	turn-offset		\ Current player's "turn"
	BEGIN
		PreviousTurnOffset			\ Previous player's "turn"
		DUP turn-offset-to-player PlayerToScore	\ Player's score.
		WinningScore @ =			\ Winning score?
	UNTIL
	turn-offset-to-player			\ Return prevous player with the winning score.
;

\ End of game check - Figures out who won.
: DetermineOutcome ( -- gameResult )
	PointWin?	\ Did one player have the most points?
	IF
		DUP DisplayWinner	\ Display winner in the end of game dialog.
		current-player =	\ Did we win?
		IF
			#WinScore		\ We won.
		ELSE
			#LossScore	\ Another player won.
					\ When replaying moves, this case is problematic.
		ENDIF
	ELSE	\ Tie - Check for highest level reached.
		HighestLevelWin?
		IF
 			DUP DisplayWinner	\ Display winner in the end of game dialog.
			current-player =	\ Did we win?
			IF
				#WinScore	\ We won.
			ELSE
				#LossScore	\ Another player won.
			ENDIF
		ELSE	\ Last resort if all other checks fail...
			LastMovedPlayer DisplayWinner	\ The player that last moved (with winning score) wins.
							\ Note: current player has not moved.
			#LossScore
		ENDIF
	ENDIF
;

\ Determine if the game is over or not.
: OnIsGameOver ( -- gameResult )
	#UnknownScore
	$passed @	\ Did current player pass?
	IF
		\ Generate moves for all opponents (forAllOpponents = TRUE)
		\   We only do this to establish "passed".
		current-player TRUE 0 $GenerateMoves $DeallocateMoves	\ Generate opponent moves.
		$passed @	\ If no moves are generated for all other players then $passed is TRUE.
		IF	\ All players pass?
			DROP DetermineOutcome
		ENDIF
	ELSE
		h1 not-empty-at?	\ Reached highest level?  If so end of game.
		IF
			DROP DetermineOutcome
		ENDIF
	ENDIF
;

\ Disallow board edits as it allows the game to get out of sync with scoring, etc.
: DisallowEdits
	TRUE ABORT" Sorry, board editing is not supported for this game."
;

: OnEditAdd  ( player pieceType position -- )
	DUP a8 <= IF DisallowEdits ENDIF
	OnEditAdd
;

: OnEditRemove ( position -- )
	DisallowEdits
;