************************************************************************
*** Festival Climbers V2.0                                           ***
***                                                                  ***
*** A PyroMyth Game for 2 to 4 Players.                              ***
*** Copyright (c) July 15th, 2005 PyroMyth Games - by David Whitcher ***
*** http://www.pyromythgames.com                                     ***
***                                                                  ***
*** Implementation by Greg Schmidt Copyright (c) 2009                ***
*** All rights reserved.                                             ***
*** Please send comments and suggestions to gschmidt958@yahoo.com    ***
************************************************************************

Festival Climbers uses the Axiom (c) Meta-game engine.
It is the season of celebration and it all starts when the young men of the village compete to ring the bell for the honor
of their families and to signal the start of the festival.  This ancient competition requires strength, stamina and teamwork.
Players will take the role of a team of climbers that must race to the top of the temple to start the celebration; they are
bound by strict rules and are rewarded for how high on the temple they are able to climb.

- Rules -

The number of climbers each player uses depends on the number of players.

2 players - 12 climbers each
3 players - 8 climbers each
4 players - 6 climbers each

On a players turn, they must do one and only one of two things if they are able:

The first is to introduce a climber onto any open space at the base level of the temple.

The second is to move a climber up the temple to any open space.  This requires that two conditions are met:

1. Moving the climber up will not leave any other climbers above it completely unsupported.  They must have at least one
climber below them.

2. The space that you are moving to is supported by two climbers below it.

- Ending the game and scoring -

The game can end in two ways.  The first and most likely is a player reaches the 8th level.  The second is if all players in
a turn are unable to make a legal move.

Once the game has ended, a player receives points for each climber they have on the board equal to the level they are on.
The player who has scored the most points wins.  In the case of a tie the player that has reached the highest level wins.
If that does not break the tie, the player that moved last wins.

For example, the blue team has ended the game by reaching the 8th level; they have 1 climber on 8, 2 on 6, and 3 on 5.  Blue
will score (8 x 1) + (2 x 6) + (3 x 5) = 35

Note:
When replaying a 3 or 4 player game by scrolling through the moves list window and the end of game is reached, the result
shown may be incorrect (this does not occur when loading a saved .zsg).  This is due to a bug in the way in which Zillions
handles plug-in engines.  One way to circumvent this is by scrolling down to the last computer move and then invoke "Start
Thinking".
