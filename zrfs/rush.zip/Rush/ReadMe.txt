*********************************************************************
***                                                               ***
*** Rush - by Mark Steere, 2007.                                  ***
***                                                               ***
*** Implemented by Greg Schmidt.                                  ***
*** Uses the Axiom (c) Universal Game Engine.                     ***
*** Copyright (c) 2009.  All rights reserved.                     ***
***                                                               ***
*** Please send comments and suggestions to gschmidt958@yahoo.com ***
***                                                               ***
*********************************************************************

Rush - Place the majority of stones on the board.

INTRODUCTION:
Rush is a territory game which is played on a Go board with an odd number of rows and columns.
Play begins on an empty board.  Each pllayer takes possession of all stones of one color.  Draws.
and ties cannot occur in Rush.

STONE PLACEMENT:
Players take turns placing their stones on unoccupied points.  A "connection" in Rush is formed when
a stone is placed horizontally or vertically adjacent to an on-board stone.  If a player adds a stone
which forms either no connections or only one connection (to either color stone), that player's turn
is concluded.

A player may place a stone on the board which forms two or more connections only if at least one of those
connections is made with an enemy stone.

A player may never, under any circumstances, place a stone which forms two or more connections with his
own stones and no connections with enemy stones.

If a player forms two or more connections with his newly added stone, he is required to add another stone
to the board while it is still his turn.  He must continue to add stones during his turn until his most
recently placed stone forms less than two connections, or until there are no more placements available
to him, at which time his turn is concluded.

Each player will always have at least one placement available at the outset of his turn and must make at
least one placement on his turn.

A player is never required to make a placement which forms two or more connections unless his only available
placements each form two or more connections.

OBJECT OF THE GAME:
When the board is completely filled with stones, the player with the majority of stones on the board wins.

Note: Refer to 'Rush_rules.pdf' for further details.


