Daedalus
-----------------
Created by Chris Huntoon, 2012
Please send any feedback to Hartunga66@yahoo.com

Hexagonal Go-Moku. 

The object is to get five of your stones in a row in any direction, straight or diagonally. The diagonals have been color coded on the hex grid so that they are easier to see.  Six or more stones (an 'overline') does not count for a win.

Black goes first.  On its first move, Black is forbidden from placing a stone on the central hex, marked with a delta. After that, players alternate placing stones on any open space.


----------------------------------------------------------------
To play:

Double click the Daedalus game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Daedalus.zrf" in the Open dialog and click 
   "Open"

Daedalus.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
