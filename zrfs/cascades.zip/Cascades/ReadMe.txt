Cascades
--------
Invented by William Chang,
implemented by L. Lynn Smith, February 2002.


Cascades is a two-player game, Black and White.

Each player introduces Stones onto the empty cells of the playing field 
which are both next to and below a Stone of their color.

Play begins with Black who drops one Stone, then each player may drop up 
to two Stones at a turn.

Players may pass.

The game is won by the player who occupies a majority of the cells on 
the bottom row.


This game was based upon the flow of water carving out a mountainside.


----------------------------------------------------------------
To play:

Double click the Cascades icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Cascades.zrf" in the Open dialog and click "Open"

Cascades.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
