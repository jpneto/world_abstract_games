Makyek
------

Makyek is a two-player board game from Brunei. It has an unusual method 
of capture called intervention in which a piece moved between two of 
the opponent's pieces captures both of them. In Malaysia it has 
the name Apit-sodok.

The goal of the game is to capture your opponent's pieces.

There two methods of capture. A piece may be captured if it is sandwiched 
between two of the opponent's pieces (this is called custodial capture). 
A piece may also capture two of the opponent's pieces if it is moved between 
those two pieces (this is called capture by intervention).
