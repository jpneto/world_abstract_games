; -------------------------------------------------------
; *** LINE4plus  v1.1                                 ***
; * * implemented by K. Franklin, Apr 2002, May 2008  * *
; * * e-mail address: kenf@ica.net                    * *
; * * based on Zilllions' Vertical_TicTacToe.zrf v1.2 * *
; -------------------------------------------------------

; You need to purchase Zillions of Games to load this rules file
; Visit the Zillions web site at http://www.zillions-of-games.com
;----------------------------------------------------------------


Line4plus - a familiar drop checker game featuring neutral checkers  

Object: Be the first player to get 4 of your pieces in a row,
horizontally, vertically, or diagonally.  Moves are made by
dropping pieces to the lowest unoccupied space in any column.

Original 4-state modification:
Upon each checker drop, all adjacent pieces are flipped.
- Red - hollowBlk - Black - hollowRed - Red -
hollowBlk and hollowRed checkers are neutral.

v1.1 Update, added subvariant:
A 3-state checker flip variant is now implemented.
Only vertical and horizontally adjacent pieces upon each drop are flipped.
Both sides' pieces will be changed to a 50/50 neutral piece.  Adjacent
Neutral pieces are changed to the current player's side.  
Piece Graphics updated as well.

-------------------------------------------------------------------

You should extract the game preserving path names. 

To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Line4plus.zrf" in the Open dialog and click "Open"

Line4plus.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 


 