Checker Games
-------------
Implemented by Uwe Wiedemann, June 2001.


This zrf includes a bunch of checker games and variants:


1) regional or historic checker games

- International Checkers (= International Draughts, Polish Draughts, French Draughts)
- Shashki (Russian Draughts)
- Dame (German Draughts)
- English Draughts (= Anglo-American Checkers)
- Pool Checker (= Spanish Pool Draughts)
- Dammspiel (Old German Draughts)
- Turkish Draughts
- Grand jeu de dames (= Canadian Draughts)
- Choko (a westafrican checker game)
- A Liberian checker variant

2) crossovers between chess and checkers

- Cheskers
- Byelorussian Cheskers
- Knightsbridge
- Schachdame (Chess Draughts)

3) The variants of checker games

- Crowed English Draughts
- Losing International Checkers
- Schlagdame (Losing German Checkers)
- Double-Back Checkers


See the description of each game within the program for detailed
rules.


----------------------------------------------------------------
To play:

Double click the Checker Games icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Checker Games.zrf" in the Open dialog and click "Open"

Checker Games.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
