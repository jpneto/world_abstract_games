Pikkpakk v2.2
-------------
Invented by L�szl� Nagy, 1977,
originally implemented by Karl Scherer, November 2000.
Updated February 2001 by L�szl� Nagy
Updated March 29, 2003: Graphics improved by Keith Carter. 
						Sound corrected by Karl Scherer.

Goal: surrounding the red ball with your own colours 
from the four touching sides.  
The blue player starts and he may push the whole row or column of balls 
in which his balls outnumber the other player�s.  
The white player may also move 7 balls but he must outnumber the other 
player to be allowed to do so.  
They move alternately until the red ball is sandwiched by one of them 
from four sides.

Variants:
2. Variant - just like the basic game but the winning move may be pushed 
   even if the number of balls is equal.
3. Variant - captured version, you may push a row of any length.
4. Variant - square version, the protruding ball is rolled over to finish a move.
5. Variant - just like the square version but the winning move may be pushed 
   even if the number of balls is equal.


The developer was impressed by the Rubik�s Cube at the time and looked 
for a playable competition goal for the collective movement of balls 
(virtually for rotation around field points or the shifting of rows)


More freeware as well as real puzzles and games under 
http://karl.kiwi.gen.nz.


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Pikkpakk.zrf" in the Open dialog and click "Open"

Pikkpakk.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

