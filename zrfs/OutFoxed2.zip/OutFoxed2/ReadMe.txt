OutFoxed2 by Bob Henderson

Versions of this game date back to the medieval Vikings. Can your
Geese surround the Fox before he jumps over one and escapes? This
new version includes five increasing board sizes that never seem
to have enough Geese to block the Fox from reaching the top row!

----------------------------------------------------------------
To play:

Double click the OutFoxed2 icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "OutFoxed2.zrf" in the Open dialog and click "Open"

OutFoxed2.zrf is a rules file used by the Windows program
"Zillions of Games."  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website at
              <http://www.zillions-of-games.com> 
