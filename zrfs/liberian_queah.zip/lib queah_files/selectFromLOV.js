//	required Javascript functions 
//	to be included in any page utilising the generic List-Of-Values 'dialog'
//
//	the page must href to javascript:selectFromLOV() or javascript:selectFromLOV_proc(), 
//	giving	a url that will (indirectly) call ZilliGames::display_lov( ...) to show the lov contents
//			and the field (on that url's page) spec that will receive the selected item value
//				field spec param_fld is typically of the form "formname.fieldname"
		
       
var my_LOV_window = null;		//	global LOV window
var my_param_fld = null;		//	remember param_fld; the selected value will be put into this

//	doesn't return anything
//	use this whithin href="javascript:selectFromLOV_proc( ...)"
function selectFromLOV_proc( lovURL, param_fld) 
{
	selectFromLOV( lovURL, param_fld);
}

//	returns the lov window object
function selectFromLOV( lovURL, param_fld)
{

	if(my_LOV_window != null) 
		if(!my_LOV_window.closed) 
			my_LOV_window.close();
	
	my_param_fld = param_fld;
	
	lovURL = lovURL + "&lovrcvr=" + escape( param_fld);
	
	if (param_fld != "")	//	if field has a chance to be valid
	{	var param_val = eval( param_fld + ".value");	//	get current value
	
		if (param_val.charAt( 0) != "<" || param_val.charAt( param_val.length - 1) != ">")
		{	//	add the selected text as a search argument to lovURL, if it's one that doesn't look like '<...>'
			lovURL = lovURL + "&search=" + escape( param_val);
		}
	}
	
	my_LOV_window = window.open(lovURL, 'lov', 'height=500,width=400,top=84,left=188,status=no,toolbar=no,resizable=no,scrollbars=no,location=no', true); 
	my_LOV_window.focus();
	
	setTimeout( "selectFromLOV_finish()", 1000);	//	now wait for the LOV to finish
	
	return my_LOV_window;
}

function selectFromLOV_finish() 
{
	//	here we would like to have the LOV behave like a modal dialog
	//	it can't technically be one, since the LOV must be able to retrieve new content by itself.
	if (my_LOV_window != null && !my_LOV_window.closed)
	{	//	the LOV is still open
		if (document.hasFocus())	//	if I have focus
			my_LOV_window.focus();		//	return focus to the LOV
			
		setTimeout( "selectFromLOV_finish()", 500);	//	wait some more (in milliseconds)
	}
	else
	{	//	the LOV is closed
		my_LOV_window = null;		//	I must forget about it
		
		if (my_param_fld != null && eval( my_param_fld + '.type') != "hidden")
			eval( my_param_fld + ".focus()");	//	focus on field receiving the result
	}
}
