Vanakriget
---------------
Implemented by Markus Salo, November 2002.
Updated August 23, 2003: improved graphics


Vanakriget is a variant of Brandon Burkholder's great game Five Field Kono.  

The name "Vanakriget"
is the name of the battle between the two families of Gods, the Asar and the Vaner in
Norse mythology.

Pieces move one point straight or diagonally forward. There is no backward moves. 
Enemy pieces are captured by jumping like in Alquerque.  The captures are obligatory and
one must continue the jump, if another capture is possible.  The player whose pieces are captured
can however place the captured pieces back on the board on any empty space.

The object is to place your pieces
on the points of your opponenets starting position.

