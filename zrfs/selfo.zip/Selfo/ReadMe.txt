Selfo
-----

Implemented by D.D. Albarrac�n. October, 2009.


Contact
ddam.perquisitore@gmail.com

The goal is to get arranged all your pieces into a single connected group.


----------------------------------------------------------------
To play:

Double click the Selfo icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Selfo.zrf" in the Open dialog and click "Open"

Selfo.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
