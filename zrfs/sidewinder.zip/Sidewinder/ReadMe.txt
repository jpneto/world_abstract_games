Sidewinder

(c) 2001  W. D. Troyka
dtroyka@justice.com

Win by moving a snake to the opposite corner.  Snakes move any 
number of spaces along the forward diagonals and capture by 
replacement.

The principal game strategy consists of getting under your opponent's 
defenses.  This happens when you move a snake onto a diagonal that is 
behind most of your opponent's snakes.  The opponent can defend only 
by moving snakes out from the snakepit area (the home corner), which 
substantially weakens the opponent's defense.  The converse of this 
strategy is that you should try to keep a snake in your snakepit, 
with other snakes close by, as long as possible.

As in the games Breakthrough and Ugly Duck, also available on 
Zillions, the forward orientation of the pieces means that games 
develop quickly and draws are impossible.

Sidewinder comes in two board sizes, one with four hexes to a side, 
the other with five.

You should extract the game from the downloaded zip file 
preserving path names. 

----------------------------------------------------------------
To play:

Double click the Sidewinder icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Sidewinder.zrf" in the Open dialog and click "Open"

Sidewinder.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 