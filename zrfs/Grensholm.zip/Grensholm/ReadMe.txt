Grensholm
---------
Created by Markus Salo, August 2004.


Grensholm is played on a 4 x 6 board.  Both players have six pieces 
that move and capture like knights in chess. However the pieces move 
and capture only towards the enemy end of the board.
Captures are mandatory.  
The goal is to reach the enemy end of the board to be promoted and then to
reach the home end with the promoted piece.


Grensholm is the home of Magnus Stensson Gren (lived 1425-1472), the famous 
and infamous warlord and Kings councilman turned into a pirate. Grensholm is 
located on the Northern shore of lake Roxen, 15 miles East of Norrk�ping. 
On the site, there is a now ruined castle, Borgen �l, the home of 
Sten Haraldsson Gren, the father of Magnus, and a more modern Manor House, 
the actual Grensholm.

Please send your comments to msalo71@yahoo.com


----------------------------------------------------------------
To play:

Double click the Grensholm icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Grensholm.zrf" in the Open dialog and click "Open"

Grensholm.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

