Congklak

(c) 2001  W. D. Troyka
dtroyka@justice.com

Congklak is a Mancala game played in Indonesia, Malaysia, and 
the Phillipines.  It is known by a variety of regional names, 
including Sungka and Dakon.  The game is essentially a hybrid 
of Kalah and Endodoi, also available on Zillions.  It employs 
the capturing method of Kalah with the multi-lap sowing of 
Endodoi.  

Congklak was featured on the cover page of the second edition 
of Abstract Games Magazine.  Unlike Kalah, Congklak is an 
indigenous game with a long history of local play.  As 
explained in more detail in the "History" section to Kalah, 
the game Kalah was likely derived from Congklak by an American 
game enthusiast in the early 20th century.

Congklak is traditionally played on 2x5 and 2x7 boards with 
cowrie shells or similar counters.  This version is played 
with rubies.  (You must pre-apply with our credit department 
before playing.)  The number of rubies in each hole at the 
start of a game corresponds to the number of holes on each 
side of the board.   Unlike most Mancala games, sowing takes 
place in the clockwise direction.  Rubies are sown into a 
player's store -- but not the enemy store -- and into the 
lift hole on subsequent laps.  

A turn consists of sowing the rubies from a hole on the player's 
side of the board.  In the 2x7 version (the default), if the last 
ruby is dropped in the store, the player gets another turn starting 
from any friendly occupied hole.  If the last ruby is dropped in an 
occupied hole, the rubies in that hole, including the last ruby 
dropped, are picked up and a new sowing begins as part of the 
same turn.  You can make up to twenty moves in a single turn in 
this implementation.  If the last ruby drops in an empty hole on 
the player's side of the board, any rubies in the enemy hole 
directly opposite are captured along with the last ruby dropped, 
and the turn ends.  If the last ruby drops in an empty enemy hole 
or in an empty friendly hole opposite an empty enemy hole, the 
turn ends without any captures. 

In the 2x5 version, if the last ruby from a sowing lands in the 
player's store, the turn ends without further moves.  I have 
adopted this rule from the Abstract Games Magazine article.  
Although most descriptions of Congklak provide that sowing 
into the store gives you an extra turn, in the 2x5 version 
the bottom player can win the game on the first turn -- without 
the top player ever making a move! -- if such moves are 
permitted.

For the complete rule set, please read the "Game Description"
that comes with the game.

Please send any comments or bug reports to dtroyka@justice.com.  
For other Mancala games available on Zillions, check Wari, 
Kalah, Endodoi, Cross-Wari, and Cross-Kalah.


----------------------------------------------------------------
To play:

Double click the Congklak icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Congklak.zrf" in the Open dialog and click "Open"

Congklak.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 