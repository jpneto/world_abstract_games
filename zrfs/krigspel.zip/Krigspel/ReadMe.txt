Krigspel
--------
Invented and implemented by Markus Salo, June 2005.


Krigspel is a simple wargame played on a 7x7 square board.

Both players have three kinds of pieces, 5 infantry pieces, 2 cavalry pieces and
one head quarters piece.
      
The game starts with both players taking turns placing their pieces on the board. The
infantry pieces are placed first, then the cavalry pieces and the head quarters pieces last. After all pieces are on the
board, infantry pieces move and capture like king in chess, cavalry pieces like
knight in chess. The head quarters piece moves one space at the time orthogonally only. Head quarters piece cannot capture.

The player who captures enemy head quarters wins.
      

----------------------------------------------------------------
To play:

Double click the Krigspel icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Krigspel.zrf" in the Open dialog and click "Open"

Krigspel.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
