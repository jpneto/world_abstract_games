Ring Board Checkers
-------------------------------------------------------------
Designed and Implemented by Peter Aronson, October 2002.
-------------------------------------------------------------
This game is Anglo-American Checkers (Draughts) with a special board
and somewhat more powerful Kings.  The edge squares of the board --
marked with diagonal lines -- are special.  They may only be landed in
as the result of a capturing move.  King can move and capture
diagonally forward and backwards, and capture (but not move without
capturing) up, down, left and right by a jump of four squares, landing
on a dark square. 

The ring board was inspired by the rule found in some of V.R. Parton's
Checkers variants, such as Kinger and Dragon, that some pieces may
only land on edge squares if that is the only way to make a capture.
The King's orthogonal capture was inspired by Frisian or Babylonian
Draughts, which allows such captures.
-------------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "RingBoardCheckers.zrf" in the Open dialog and click "Open"
-------------------------------------------------------------------
"RingBoardCheckers.zrf" is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
-------------------------------------------------------------------
Contact: peter@chessvariants.com
