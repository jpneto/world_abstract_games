Whiz-Bang
---------
Created by Chris Huntoon, June 2009

Rapid advancements in artillery during the late 19th and early 20th century meant that 
when Word War I broke out, the nature of war would be changed forever.  That war marked a 
shift from the infantry charge of old to the modern artillery barrage.  Pieces ranged from
small mortars to powerful Howitzers.  The larger, more complex the ordnance the more 
soldiers it required in the gun crews to properly fire it.  These pieces usually shot 
expoling shells - called 'Whiz-Bangs' by the troops.

This game recreates the trench warfare of the first World War.  The grey  field in the 
middle is 'No Man's Land' - the deadly wasteland that existed between the two sides 
trenches.  The first player to safely get a Soldier across No Man's Land and into enemy 
territory wins.

Soldiers attack by firing shells.  The direction and range is determined by how many 
Soldiers are working together.  Two Soldiers connected in a line can attack up to two 
spaces away in the direction that their line is aimed at.  Three Soldiers in a line can 
attack up to three spaces away, and so on.  A lone Soldier can attack any neighboring 
space.  When an attack is made, none of the attacking Soldiers are moved.  The opponent's
captured Soldier is removed from the board.

A Soldier can move one step in any direction.  A line of Soldiers can be shifted one space
in the direction of their line.

----------------------------------------------------------------
To play:

Double click the Whiz-Bang game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Whiz-Bang.zrf" in the Open dialog and click 
   "Open"

Whiz-Bang.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 