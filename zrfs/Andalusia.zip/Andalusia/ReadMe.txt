Andalusia
---------
Created by Chris Huntoon, June 2009

The game of Checkers was created when someone tried playing Alquerque on a Chess board.
The game of Andalusia supposes that the reversed had happened.  It is Chess played on an 
Alquerque board. Pieces move along lines on the board.  It uses a slightly modified 
quadruple Alquerque board, with every other horizontal and vertical line removed.  This 
type of board is found in some African games. Object:  checkmate the opponent's King.

King - a King can move one step along a line in any direction. Like Chinese Chess, it has
the special power to threaten the enemy King across the board along an empty line. For 
this reason, it is not permitted to make a move that leaves the two Kings facing each 
other with nothing in between.  Unlike Chinese Chess, the King is not restricted to a 
particular area of the board.  So it can threaten the enemy King along any line and in any
direction.

Chariot - a Chariot can slide any number of spaces along a line in any direction.

Soldier - a Soldier can move one step along a line in any non-retreating direction. It can
move two spaces from it's starting position, as long as it is not a capturing move.  A 
Soldier promotes to a Chariot on the second to last rank.

----------------------------------------------------------------
To play:

Double click the Andalusia game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Andalusia.zrf" in the Open dialog and click 
   "Open"

Andalusia.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 