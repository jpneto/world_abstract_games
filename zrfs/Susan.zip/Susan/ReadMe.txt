Susan v1.1

Game (c) 1991 Stephen Linhart
Graphics and rules file (c) 2001 W. D. Troyka

Updated August 25, 2001

Susan is an elegant game of placement and movement played on a 
symmetrical hex board.  The game was invented by Stephen Linhart 
in 1991.  A detailed description of the game can be found at 
www.stephen.com.  Stephen's site offers a Macintosh computer 
player that learns as you play.  (My advice:  play badly at 
first!)  The site also provides an answer to the question, why 
name a boardgame Susan?  For convenience, a strategy manual 
available at the site has been included with the Zillions 
download package.

The rules are as follows:

The object is to surround an opponent piece on all sides with 
pieces of either color.  A turn consists of dropping a piece onto 
the board or sliding a piece that is already on the board one space 
in any direction.

If a move causes both an opponent piece and a friendly piece to be 
surrounded on all sides, the moving player loses.  Suicide is 
possible and may even be compelled in the endgame.

A draw is declared if each player slides a piece for three 
successive turns without any intervening drops.

In the illustration below blue has won because the purple piece 
on the bottom right (position f1) is surrounded on all sides.

Susan comes in two board sizes, one with five hexes to a side, 
the other with six. 

You should extract the game from the downloaded zip file 
preserving path names. 

----------------------------------------------------------------
To play:

Double click the Susan icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Susan.zrf" in the Open dialog and click "Open"

Susan.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
