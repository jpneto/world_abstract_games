Squaredance
-----------
Invented and implemented by Karl Scherer, April 2004.
Updated April 10, 2004: corrected text and names of variants


Object: Stalemate your opponent.
(Version 1.1; 6 variants)

A move consists of rotating a (orthogonal or diagonal) line of consecutive coins 
by a multiple of 45 degrees.
The pivot (turning point) is the first coin of your series of coins.
An isolated coin cannot move. 

Click a coin to mark the beginning of the line of (consecutive) coins
you want to rotate. The beginning of the line is also the hub of the rotation.
Then move the end of the line of coin around this pivot by a multiple of 
45 degrees. Green dots will show you where you can go.

You win when you have stalemated your opponent.
The other variants with different starting setups.

Despite its simplicity (one movement) the game has sufficient depth 
and caters for some tricky end games.
Warning: The Zillions AI is devilish good at playing this game against humans!

Note that there is an alternative piece set.
This game needs Zillions V2.0 (or higher) to run. 


I chose the name 'Squaredance' for this game because the movement of the
pieces reminded me of some of the movements in square dancing. 
     

----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Squaredance.zrf" in the Open dialog and click "Open"

Squaredance.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

