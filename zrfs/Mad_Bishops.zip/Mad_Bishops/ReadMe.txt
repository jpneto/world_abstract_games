************************************************
*** Mad Bishops - Kill All Enemy Checkers    ***
***                                          ***
*** Designed by Mark Steere.                 ***
*** Computer implementation by Greg Schmidt. ***
*** gschmidt958@yahoo.com                    ***
***                                          ***
*** Utilizes the Axiom Meta-Game System.     ***
*** Copyright 2010.  All rights reserved.    ***
************************************************

OBJECT: To win, you must kill all enemy checkers.  Passing is not allowed.

MOVE: The checkers move something like Chess bishops.  In particular, if your checker is on
the same diagonal as an enemy checker, either adjacent to it or separated by one or more
contiguous empty squares, you can remove the enemy checker and replace it with your own
said checker.

KILL: If your checker is in position to kill, you can only use it to kill.  You can't move it somewhere
without making a kill.

ENGAGE: If your checker is not in position to kill, you can only move it to engage the enemy.
I.e., you must move it (along a diagonal series of one or more empty squares) to an empty square
that's on the same diagonal as an enemy checker, with none of your own checkers in between
the two.

Killing is not mandatory.  If you can move an unengaged checker to engage the enemy, you can
do that instead.

If a checker can't be moved to kill or to engage, then it can't be move.  As long as you have
checkers on the board though, you will have a move available.

- Refer to the game rules PDF file for additional details.

- A free stand-alone version of Jostle may be downloaded from:
http://www.boardgamegeek.com/filepage/54513/mad-bishops-axiom-pc-game