SanQi
-----
Invented and implemented by L. Lynn Smith, June 2003.


SanQi is played upon an hexagonal field of equal sides between two opponents 
with a generous quantity of stones of three different colors.

All the stones are considered neutral, and may be used by either player.

On each turn a player must perform one of the following actions:
PLACE a stone of any color on any empty cell.
REPLACE a stone of one color with a stone of another color, if the replaced 
stone is directly adjacent at least two more stones of the replacing color 
than stones of its own color.  A player may not immediately replace a stone 
played by an opponent for at least one turn, but the player of that stone may 
replace it on the next turn.

Turns are mandatory, there is no passing.

Each player has different goals within the game.  The First player wins if 
there is a complete CIRCLE of six stones of one color, regardless of the 
condition of its center cell, at the end of that player's move.  The Second 
player wins if there is an orthogonal LINE of six or more stones of one color 
at the end of that player's turn.  Either player wins if there is a simple 
TRIANGLE of six stones of one color at the end their particular move.


----------------------------------------------------------------
To play:

Double click the SanQi game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "SanQi.zrf" in the Open dialog and click "Open"

SanQi.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

