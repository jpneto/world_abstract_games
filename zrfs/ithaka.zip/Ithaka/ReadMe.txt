Ithaka
------
Invented and implemented by L. Lynn Smith, January 2002.


Ithaka is a two-player game.  The pieces are neutral and can be moved 
by either player.

A piece may be moved any number of empty spaces in a direct orthogonal 
or diagonal line.  A player may not move a piece which was last moved 
by the opponent OR which is not adjacent to one of its own color..

The object is to form a directly adjacent orthgonal or diagonal line of 
three pieces of the same color or to NOT leave your opponent a move.  
The game is lost with third move repetition.


Looks easy, well go for it.


----------------------------------------------------------------
To play:

Double click the Ithaka icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Ithaka.zrf" in the Open dialog and click "Open"

Ithaka.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
