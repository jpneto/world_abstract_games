Splotch
-------
Invented and implemented by L. Lynn Smith, December 2003.
Updated March 27, 2004: improved naming of the board cells.
Updated January 17, 2009: corrected syntax error.


Splotch is played upon an equal hexagonal field of four cell sides.  
The pieces consist of three different token, Red, Yellow and Blue.  
The pieces are the mutual property of both players, and there is a 
generous quantity of each.

Each player, in turn, introduces a token of one type upon the playing 
field under the following conditions:
1.  The player cannot play a type which was last played by the opponent.
2.  The target cell cannot contain a token of the type being played.

After placing this token, the player then adjusts the condition of the 
surrounding cells adjacent to this placement.  If the adjacent cell has 
a token of this type, it is removed but any other token in the cell remains.  
If the adjacent cell does not contain a token of this type, a token is 
placed in the cell.

Any cell which contains one of each of the three types of tokens is 
captured by that player.

The game is won by the first player to capture ten tri-color stacks.

The stack of tokens located in the upper left-hand corner of the diagram 
will note which tokens are available for play at a turn.  Captures will 
be recorded in the bar graphs to the right, white for the First player 
and black for the Second.


----------------------------------------------------------------
To play:

Double click the Splotch game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Splotch.zrf" in the Open dialog and click "Open"

Splotch.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

