Fortress
--------
Implemented by Karl Scherer, December 2000.


Object: The Attacker wins if he can occupy the 15 places of the 
'Fortress'. The Defender wins if he reduces the attacking army 
to less than 15 pieces. 

The Attacker moves only sideays or forward (orthogonally or 
diagonally) one step at a time.
The Defender can move one step into all directions and captures 
by jumping. Jumps are forced. The Defender may jump several times 
in a row with one piece.

 
Fortress is a historic relative of the game 'Fox and Geese'.
Source: Book 'Unsere Spiele' by Werner Hirte.


More freeware as well as real puzzles and games at 
http://karl.kiwi.gen.nz.


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Fortress.zrf" in the Open dialog and click "Open"

Fortress.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

