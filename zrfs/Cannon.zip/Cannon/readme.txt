Cannon
------
Invented and implemented by David E Whitcher, January 2003.
Graphics created by Keith Carter.


Object: Capture your opponents Town ( Checkmate ) or destroy it by cannon 
fire. You may also win if your opponent can't move.

Soldiers have three basic moves:
Advance: Moves forward orthogonally or diagonally.
Attack: Captures opponent forward and sideways orthogonally or forward diagonally.
Retreat: Soldiers adjacent to an enemy may move backwards two positions without capturing.

and two special moves:
Three soldiers in a row make a cannon allowing a non-move capture ( cannon shot ) two or three
positions in line with the group as long as the position immediately in front of the cannon is not
occupied. The cannon formation may shift along it's length in any direction without capturing.


----------------------------------------------------------------------
To play:

Double-click the Cannon icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Cannon.zrf" in the Open dialog and click "Open"
----------------------------------------------------------------------
"Cannon.zrf" is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
-------------------------------------------------------------------

