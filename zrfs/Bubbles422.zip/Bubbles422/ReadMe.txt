Bubbles for Two II
------------------
Invented and implemented by Karl Scherer, February 2003.


Object: Pop all your opponent's bubbles.
(40 variants)

You play White against Black.
First both players drop their two queens anywhere on the board.

Then you move a queen to a free square or onto a bubble.
A queen cannot jump over another queen.
The queen's attack lines, however, go all the way to the 
border of the board (not so in variants 21 thru 40, however). 

If you move onto a bubble, this bubble will be deleted.
Furthermore, any bubbles, friendly or not,
will be deleted that are attacked by BOTH of your queens!  

The player who pops all of the opponent's bubbles wins.

Variants  1 - 20: different setups for bubbles.
Variants 21 - 40: Queen's attack lines only go up to next queen.


More free games software as well as real puzzles and games at my 
homepage: http://karl.kiwi.gen.nz.


----------------------------------------------------------------
To play:

Double click the Bubbles422 icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Bubbles422.zrf" in the Open dialog and click "Open"

Bubbles422.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
