Jumping Beans
-------------
Created by Chris Huntoon, August 2001.


The objective is to either eliminate all of the opponent's Beans 
or move one's last remaining Bean to the center square. 
�
A Bean may move in any direction, either by sliding to an adjacent 
empty square or by jumping over an enemy piece to a vacant square 
on the other side. Jumping over a piece captures it. Capturing is 
mandatory, and you must keep jumping and capturing as long as it 
is possible.


----------------------------------------------------------------
To play:

Double click the JumpingBeans icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "JumpingBeans.zrf" in the Open dialog and click "Open"

JumpingBeans.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
