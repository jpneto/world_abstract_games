L-Game v2.1
-----------
Invented by Edward de Bono 
Implemented by Karl Scherer, April, May 2000.
Updated December 26, 2004: Board-flipping now prevented.


Object:  Stalemate your opponent.

You move your L and then (optionally) one of the two 
neutral squares. 

To make your move in this Zillions implementation:  
First you select one of the 8 L-icons from the border, then 
click a place where to put it. The hand icon will show where 
the corner of the L will be situated. The L has to be placed 
on four empty squares.
Next, you move the neutral squares in the usual way: just 
drag it to the target place. If you do not want to move a 
neutral square, just click it.


The L-Game was invented by Edward de Bono and published in one 
of his books on lateral thinking (at around 1977).
For two years several people had tried in vain to figure out a 
winning strategy, using computers. Then in 1979 Karl Scherer 
proved by hand that this game is a draw. (The proof was published 
in the Journal of Recreational Mathematics.)


Included is a variant in which moving a neutral square is
mandatory, one in which you're allowed to move both squares
(optionally) and one in which moving both squares is mandatory.


For more free software and (real) puzzles and games see Karl 
Schrerer's web pages at karl.kiwi.gen.nz .
You can also find there how to create these beautiful fractal 
designs which are used for this game.


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Lgame.zrf" in the Open dialog and click "Open"

Lgame.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

