Five field Kono
---------------
Implemented by Brandon Burkholder, November 2002.


Pieces move one point diagonally forward or backward. 
There is no capture. The object is to place your pieces
on the points of your opponenets starting position.

Five Field Kono is a replacement game of Korean
origin. A description of the game was originally published in
Korean Games by S. Culin in 1895.


----------------------------------------------------------------
To play:

Double click the FivefieldKono game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "FivefieldKono.zrf" in the Open dialog and click "Open"

FivefieldKono.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

