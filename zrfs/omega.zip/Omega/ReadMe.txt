************************************************
*** Omega - Outgroup Your Opponent           ***
***                                          ***
*** Designed by N�stor Romeral Andr�s.       ***
*** http://www.nestorgames.com/              ***
*** Computer implementation by Greg Schmidt. ***
*** gschmidt958@yahoo.com                    ***
***                                          ***
*** Utilizes the Axiom Meta-Game System.     ***
*** Copyright 2010.  All rights reserved.    ***
************************************************

Omega - Outgroup Your Opponent

Please visit http://www.nestorgames.com/ for further information and for purchasing the game.


Players compete by forming isolated groups of pieces of their color.

The first player is assigned to diamond and thus forms diamond groups.  The second player is assigned to onyx and thus forms onyx groups.
Players alternate turns during the game.  On their turn, a player must place two stones, one diamond and one onyx, on any two free spaces
on the board.  A round consists of both players playing out their turn.  If at the beginning of a round, there are not enough empty spaces on
the board to complete the round, the game ends.

Scoring:

At the end of the game, several groups of connected stones of the same color have been created. The value of a group is the number of
stones of that group.  To calculate your score, MULTIPLY the values of all of the groups of your color.  The scores can end up being
large numbers.

The player with the maximum score wins the game. In case of a tie, the last player to place a stone, wins.

Pie Rule Variants:

This rule applies to those variants labeled "With Pie Rule".  Immediately after the first player has placed the first two stones, the second
player has the option of either placing another pair of stones as usual, or invoking the "pie rule" (also known as the "swap rule").  To invoke
the pie rule, the second player clicks on either stone.  Afterwards, it is now as if the second player had switched places with the first player
and played the first two stones (however the names of the players do not change).  The first player is now assigned to onyx and forms groups
of onyx stones, whereas the second player is now assigned to diamond and forms groups of diamond stones.  After making this special move,
the second player's turn ends.  This rule helps normalize a potential first player advantage.

Note: A free stand-alone version of Omega may be downloaded from:
http://www.boardgamegeek.com/filepage/58795/omega-axiom-pc-game