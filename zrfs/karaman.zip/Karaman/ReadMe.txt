Karaman
-------
Invented and implemented by Markus Salo, July 2002.


Karaman is a two player game on an 5x5 field.

Each player must move their King one orthogonal or diagonal vacant point, 
then must drop one Soldier onto any vacant point of the field. 

The soldiers can capture enemy soldiers by jumping over enemies, not Kings.  
Multiple capture jumps are obligatory if possible.  The soldiers can move 
only by jumping. There is no blocking move after a jump.

The game is lost by the first player who is unable to preform his move.


Karaman is a variant of Bernd Kienitz's game Isola with 5x5 board.  
In Isola, the soldiers were unable to move, in Karaman, they can capture 
enemy soldiers, not Kings. Multiple capture jumps are obligatory if possible.  
The soldiers can move only by jumping.


----------------------------------------------------------------
To play:

Double click the Karaman game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Karaman.zrf" in the Open dialog and click "Open"

Karaman.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

