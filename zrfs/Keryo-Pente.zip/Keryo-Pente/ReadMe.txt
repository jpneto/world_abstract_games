
Keryo-Pente
-----------
by Robert Lozyniak
modified from Mats Winther's Z-Pente
January 2009


Goal: get five or more of your pieces in a row in any direction to
win.  If you place a piece so it sandwiches two or three opponent pieces with two
of your pieces, the sandwiched opponent pieces are captured.  If you capture
fifteen or more of your opponent's stones, you also win.

White plays first. White's first move must be on the center point, and his
second must be at least three spaces away from the center. 

---

The file Keryo-Pente.zrf is a rules file for use with the software Zillions of Games. If you have a registered version of Zillions of Games, you will be able to use this file, together with the associated images, to play the game Keryo-Pente and two variants of Pente.

To get the relevant software, go to: www.zillions-of-games.com

Please report any bugs to: r07271368@hotmail.com