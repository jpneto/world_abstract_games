AYU
---

Ayu was designed by Luis Bola�os Mures in December, 2011.

Zillions implementation by Luis Bola�os Mures.

--------------------------------------------------------
To play:

Double click the Ayu game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "All Queen's Chess.zrf" in the Open dialog and click "Open"

Ayu.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com>

--------------------------------------------------------
In these rules, "adjacent" always means "orthogonally adjacent". A unit is a singleton or group. A singleton is a piece with no adjacencies to like-colored pieces. A group is a set of like-colored, mutually adjacent pieces. A portion of a larger group is not a group.

On your turn, you must either move a friendly singleton to an adjacent empty point or move a piece from a friendly group to a different empty point adjacent to the same group. All pieces which were part of the same group before the move must be part of the same group after the move, and every move must reduce the distance between the moved unit and the closest friendly unit. The distance between two units is the shortest path of adjacent empty points between them, i.e. the number of consecutive moves you would need to join them.

If you can't make a move on your turn, you win. If a board position is repeated with the same player to move (which is believed to require cooperating players), the game ends in a draw.

The pie rule (not implemented here) can be used in order to make the game fair.

To make a move, first click on a valid empty point and then on the piece you want to move there.