Jul-Gonu
--------
Implemented by Seo SangHyeon, October 2001.


Zillions-of-games does offer Kono, which certainly belongs to Korean Gonu
category. But there are more Gonu-s other than Four-field Kono you offer.
Indeed, there is more common Gonu played in a 4x4 board. And it is called
Jul-Gonu(line-Gonu).

Stones move one square orthogonally, and make
interception captures. Multiple captures are allowed. If one player
has stones less than two, he cannot capture, so it is a loss.
A stalemate is a loss, too. Repeating moves back and forth three
times is a loss.


Remember captures are made only when an interception
is caused by your opponent's move. A stone intercepted voluntarily
is not captured. Since players cannot pass their turn, it is a good
idea to make all stones 'stuck', so that your opponent must retreat.
In this way you can usually win by stalemates.


Jul-Gonu is a type of Gonu, which is one category of
Korean traditional board games, usually played on a board hand-drawn
on the ground and with distinguishable stones, so it can be easily
played without any equipments. The name of this game 'Jul' means
'line', for the board is drawn with lines. There are many variants
due to regions. They differ in the size of the board, the number of
stones, the initial position, etc.


----------------------------------------------------------------
To play:

Double click the Jul-Gonu icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Jul-Gonu.zrf" in the Open dialog and click "Open"

Jul-Gonu.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
         <http://www.zillions-of-games.com> 

 
