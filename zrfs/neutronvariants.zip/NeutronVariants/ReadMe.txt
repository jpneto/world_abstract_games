Neutron Variants (ver. 2.0)
----------------
Implemented by Robert A. Kraus, April 2001.
Updated January 15, 2005: changed graphics


Standard Neutron Rules for All Variants:

Each player has a home-row filled with pawns of his color. 
There is also a neutral piece in the center of the board called the 
Neutron; neither player owns it. The object of the game is to move 
the Neutron to a square in your own home-row, or to force your opponent 
to move the Neutron to your home-row, or to stalemate the opponent so 
he can't complete part of his turn.

All pieces move in the same way, in a straight line in any direction, 
orthogonally or diagonally. A piece must move as far as it can in one 
direction; it continues until it is blocked by a wall or another piece. 
There is no capturing.  Each turn consists of two parts: moving the 
Neutron and then moving a friendly Pawn. White goes first. In order to 
compensate for the advantage of going first, White doesn't move the 
Neutron on the very first turn.


Restricted Variants:
A player's pawns may not move onto his opponent's home-row.


Doubly-Restricted Variants:
A player's pawns may not move onto either his opponent's 
home-row, or his own home-row.


Neutron was originally invented by Robert A. Kraus in 1978.
(See the original Zillions game for more information.)
The new variants were made in 2001. The restricted 
versions are based on an idea of David Ploog.


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "NeutronVariants.zrf" in the Open dialog and click "Open"

NeutronVariants.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

