Hodge-Podge
-----------
Invented and implemented by Chris Huntoon, September 2003.

Whereas most games usually have one or two goals, Hodge-Podge has multiple goals.  
The game has a simple set-up.  All pieces move and capture the same.  There are 
only two types of pieces:  1 King and the rest are Soldiers. What makes the game 
complex is that it has several different winning conditions. 
�
You may win by either 
1. capturing your opponent's King; 
2. Getting your own King safely to the far side of the board; 
3. Get 5 pieces in a line in any direction, not counting any pieces in your first 
   two rows.  The line of 5 must include the King anywhere within the line.; or 
4. Reduce your opponent to less then 5 pieces. 
�
All pieces slide like rooks in Chess, i.e. any number of empty spaces up, down, 
left, or right.  A piece can also make a single jump over another piece of either 
color that is adjacent to it horizontally or vertically.  The jumping piece lands
on the other side.  This is not a capture.  The only capturing is achieved by 
sandwiching your opponent's pieces between yours along a row or column.  
This is similar to Reversi, except that the pieces are removed from the board 
instead of flipped.  A sandwich capture along an edge may wrap around the corner. 


----------------------------------------------------------------
To play:

Double click the Hodge-Podge icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Hodge-Podge.zrf" in the Open dialog and click "Open"

Hodge-Podge.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
