Hexxagon

Description  
Capture all or as many as possible of your opponents pieces .  
You can drop a new piece on any position next to one of your pieces, 
or you can `jump` an existing piece by moving it two squares in any 
direction(s).  
All opposing pieces in the six squares adjacent to where your piece 
lands change color to become your pieces.

The game is a distant relative of reversi.
   
Zillions lets you play with several different boards, including boards
with blocks you cannot move onto.

history:
Hexxagon is Attaxx/Blobs in a hexagonal form.

strategy 
Try not to leave any holes in your positions, 
since they can be easily occupied, capturing many pieces.   
Jump moves are especially vulnerable to leaving dangerous holes.   
Early in the game, make drop moves and try to move towards the center.

this zrf has some different setups to start with and also
a 3 player variant
