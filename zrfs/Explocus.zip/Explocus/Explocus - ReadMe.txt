Explocus v1.0
-------------
Invented by Martin Medema, 1980-ish
Implemented by Ed van Zon, October 2007

Graphics by Christian Freeling
Evaluation function by Christian Freeling and Anneke Treep


Object: eliminate your opponent

Pieces in the game consists of stacks of stones (a single stone being a stack of 1). All stones in a stack belong to the same player.
Player take turns in moving one of his stacks. A stack moves exactly as far as it's high in a horizontal or vertical direction. 
It is allowed, however, to split the stack in accordance with the move distance. E.g. if the piece to move is a stack of 3 and you want to move 2 squares, the top 2 stones will be taken to the destination cell and 1 stone will remain on the old position.

A stack may land on top of another stack, friend or foe, creating a larger stack (the sum of both). All stones in the resulting stack are then owned by the moving player.

The capacity of a board position is defined as the total number of horizontally or vertically adjacent positions. So, the corners have a capacity of 2, the remaining border positions have a capacity of 3 and the rest have a capacity of 4.
When a stack's height is at or over the capacity of the position it stands on, it'll 'explode' (hence the game's name). I.e. each orthogonal neighbour receives 1 additional stone on top of the stack standing there and the exploding stack is reduced by the position's capacity.
Explosions will cascade until all stacks are below capacity.


Strategy: 
Growing stacks makes you stronger, deploying/exploding them makes you weaker. So, try to trigger an explosion only when there are neigbouring enemy pieces you'll capture. In general, high stacks in the center of the board are strong. 
In defense, one sometimes has to decrease a stack's size. 


The name Explocus is a contraction of 'explosion' and 'Focus', the latter being a game by Sid Sackson (see http://en.wikipedia.org/wiki/Focus_(board_game) ) that provided the basic stack movement rules (stack height = move distance). The same stack movement is used in Dipole by Mark Steere.
Explocus was the precursor to Atlantis, a multi-player game on a hexagonal board of arbitrary size and shape (see http://www.spelmagazijn.nl/nl/intvw16.html), which has become popular among the students of the Dutch "University Twente" in particular the members of board game club "Fanaat" (see http://www.fanaat.utwente.nl/) of which I once was a member.

This implementation deploys the (very simple!) evaluation function that Christian Freeling and Anneke Treep developed a long time ago, partly to demonstrate that complex movements (explosions) don't bother a computer player but is very difficult to envision by humans. Being able to look ahead a couple of ply makes the computer virtually unbeatable in this game. This in contrast to a game like Havannah, which has very simple movement rules yet deemed unprogrammable by the inventor.


Please note:
When a game has ended, ZoG will display a dialog that announces the correct 
outcome of a game.  However, after that dialog is dismissed, another extraneous 
dialog pops up that always calls it a stalemate. 
This dialog is not a serious problem, it's just an annoyance - simply ignore it.


----------------------------------------------------------------
To play:

Double-click the Explocus icon, or:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Explocus.zrf" in the Open dialog and click "Open"

Explocus.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 


This game uses the "Axiom" Meta-game engine, available at the
Zillions "Free Downloads" section: http://www.zillions-of-games.com/games/.
