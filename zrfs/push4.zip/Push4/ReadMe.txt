Push 4
------
Invented (1994) and implemented by Nagy L�szl�, February 11, 2001.

Shuffle CONNECT4:
The player placing four own balls in a row will win.  
You can place your ball only on the edges of the board and the ball 
so placed should be immediately rolled one position onto the board 
to push the existing balls before itself.

So, you will have to click twice to make a move: 
one click to put your ball down and another to push it in.

Note: 
You can win in an action only:
You will also win if your winning move forms your opponent�s four 
at the same time.
(This latter will count only if you don�t have a four yourself.)

 
The board of PIKK-PAKK naturally offers a row shuffle version of 
CONNECT 4. Astonishingly, it can also be played as five in a row...

It's a popular game in Hungary for approx. five years.

----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Push4.zrf" in the Open dialog and click "Open"

Push4.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

