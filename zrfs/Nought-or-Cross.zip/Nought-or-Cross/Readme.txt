Nought-or-Cross
-----------------
Created by Karl Scherer, April 2014. 


Nought-or-Cross is Tic-Tac-Toe played on a three by three
board with the twist that we specify whether the opponent is to next place a nought or a cross;
the first to get three in a line of the same symbol wins.

In this version of Tic-Tac-Toe you do NOT own the tokens 'X' or 'O';
either player can play both types of tokens.
The first player places a cross on the main board (by clicking it), 
then clicks the small 'x' or the small 'o' on the right border.
Then the second player first clicks a free position on the left board and thereby creates
the type of token prescribed by the first player and so on.


-----------------------------------------------------------------------
To play:

Double-click the Nought-or-Cross.zrf file,
or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Nought-or-Cross.zrf" in the Open dialog and click "Open"

Nought-or-Cross.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

