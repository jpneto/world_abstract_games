************************************************
*** Limit - Limit your opponent's freedom    ***
***                                          ***
*** Designed by Cameron Browne.              ***
*** Marketed by N�stor Romeral Andr�s.       ***
*** http://www.nestorgames.com/              ***
*** Computer implementation by Greg Schmidt. ***
*** gschmidt958@yahoo.com                    ***
***                                          ***
*** Utilizes the Axiom Meta-Game System.     ***
*** Copyright 2010.  All rights reserved.    ***
************************************************

After an initial placement phase, each player must move a piece, then remove a tile.

Placement Phase: The computer initially produces a random group of 32 connected tiles.
Then each player's 8 pawns are placed on the tiles. All pawns will start with at least
one freedom and no pawn groups of size two or more will initially exist.

Movement Phase: Play alternates with each turn consisting of:
1) moving a pawn, -and-
2) removing a tile.
Both actions must be performed each move (if possible).

1) Pawn Move: The current player must move a pawn of their color to any empty tile that
can be reached by a series of steps through adjacent empty tiles (i.e. pawns block other pawns).
Groups of enemy pawns with no freedom are then captured and removed; a group has freedom if it is
adjacent to at least one empty tile.

2) Tile Removal: The current player must then remove a tile, provided that it has at least one free edge.
Any subsets of empty tiles isolated by the removal are themselves removed from the game; it is not permitted
to isolate tile subsets containing pawns. Enemy pawn groups with no freedom are then captured and removed,
then friendly pawn groups with no freedom are captured and removed (self-capture is possible).

First Move Equalizer: The opening player cannot capture any pawns on their first turn.

Aim: The last player with pawns in play wins.

Suicide by pawn move is not possible. Suicide by tile removal is possible and allowed (although not advised).

The fact that players must move a pawn and remove a tile each turn means the current player may be forced to
remove a tile that they don't necessarily want to, or even move a pawn in order to free up its tile for removal.

Situations may arise in which no combination of moves provides the current player with a free tile to remove,
in which case the player is eliminated.  It will always be possible to move a pawn.

Additional:
o Refer to `LIMIT_EN.pdf` for the official rule sheet.
o If turned on, the 'Highlight Movable` option may cause the screen to flash during a move.
o A free stand-alone version of Limit with improved graphics may be downloaded from:
http://www.boardgamegeek.com/filepage/52316/limit-axiom-pc-game")