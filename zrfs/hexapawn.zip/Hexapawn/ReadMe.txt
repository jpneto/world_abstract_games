Hexapawn
--------
Invented by Martin Gardner, March 1962
Implemented by Robert Price, October 2001

2 Players
33 Variants

Hexapawn is played on a 3x3 board as pictured below.  Pawns move as in 
Chess, except there is no double step.  You win if you "promote" one of 
your Pawns (that is, get it to the final rank).  You lose if it is your 
turn and you cannot move.

The variants are versions of the game on larger boards, and with Berolina 
or Berolina Plus Pawns.  A Berolina Pawn moves diagonally forward without 
capturing, and captures straight ahead.  A Berolina Plus Pawn moves as a 
Berolina pawn, but can also capture to the side.


----------------------------------------------------------------
To play:

Double click the Hexapawn icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Hexapawn.zrf" in the Open dialog and click "Open"

Hexapawn.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
