Photonic Attack
---------------
Invented and implemented by L. Lynn Smith, August 2001.


A two-player placement game.

The board is surrounded by arrows which denote the
direction in which Photons may be fired.

The player places a Photon atop one of these arrows
and the Photon then fires across the board until it
either encounters the opposite edge of the board or
another Photon of either color.  Where they change
any adjacent enemy Photons and all that are directly
adjacent in an orthogonal line, each into one of its
own color.

In order to place a Photon on the board there must
be a clear path from one of the arrows which surround
the field.

A player wins by having the most Photons on the board
at the end of the game.


Special Thanks to CrystalVision Software, the makers of MILO.
Photonic Attack resembles one of the game's challenges.


----------------------------------------------------------------
To play:

Double click the PhotonicAttack icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "PhotonicAttack.zrf" in the Open dialog and click "Open"

PhotonicAttack.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
