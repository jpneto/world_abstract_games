Queen's Guard
-------------
Implemented by Karl Scherer, December 2000.


Object: Place your Queen in the centre, surrounded by the six Guards.

Moves are one step onto any empty adjacent hexagon.
Moves are either sideways in the same ring around the centre 
or into the next inner ring.
 
There is no capturing. 
However, a piece can be 'trapped': when there are enemy pieces 
left and right of a piece, it has to move to the next outer ring.  

A piece placed at the centre is trapped when two enemy pieces
are placed on two opposing sides.

If the Queen and a Guard are trapped at the same time, then the 
Queen must be moved first. 

A Guard may never enter the centre.
If your Guards are positioned immediately around the centre with 
the centre being empty, you lose.
 
In variant 2 you start by placing your pieces on the board.


Queen's Guard is an old board game.
Source: Waddingtons Illustrated Encyclopedia Of Games.

The rules have been slightly simplified for Zillions:
In the original game you must place a trapped Queen where your 
opponent wishes.


For more free software and (real) puzzles and games see  
http://karl.kiwi.gen.nz .


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Queensguard.zrf" in the Open dialog and click "Open"

Queensguard.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

