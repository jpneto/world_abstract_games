Aries
-----
Created by Chris Huntoon, February 2003.


Rams move like Rooks.  When a Ram lands on an enemy Ram, it butts it, 
pushing it one space farther in the same direction.  This may set off 
a chain reaction of pushes if additional enemy Rams lie in the same 
direction.  Friendly Rams stay in place.  Captures are made by either 
butting an enemy Ram off the board or by butting an enemy Ram into a 
friendly Ram. 
�
The object is to be the first to move one of your Rams into your 
opponent's corner square.  If a player loses all his Rams, he 
automatically forfeits the game.  Repetition is a loss. 


----------------------------------------------------------------
To play:

Double click the Aries game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Aries.zrf" in the Open dialog and click "Open"

Aries.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

