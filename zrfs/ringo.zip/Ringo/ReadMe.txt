Ringo
-----
Implemented by Karl Scherer, December 2000.


The Attacker has to get two Men into the fortress (centre).
The Defender wins if the Attacker has only one Man left 
or by threefold repetition. 
You start as the Attacker.

The Attacker has seven Men, the Defender four Men.
The Attacker may only move sideways or forward.
The Defender may move sideways, forward or backwards.
The Defender may not enter the fortress. 
However, he can capture a Man inside the fortress by jumping
over it to the opposite side. 

Both players capture by jumping over an adjacent enemy Man.

One eighth of the board is especially marked as the NEUTRAL ZONE.
Men positioned in the neutral zone cannot be captured.


Ringo was invented in Germany.
Source: Waddingtons Illustrated Encyclopaedia of Games.


More freeware as well as real puzzles and games at 
http://karl.kiwi.gen.nz.


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Ringo.zrf" in the Open dialog and click "Open"

Ringo.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

