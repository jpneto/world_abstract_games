Cleave
------
Created by Chris Huntoon, December 2001.


Cleave is a variant of the Thai game of Mak-yek. 
 
All pieces move like a Rook in Chess, that is, any number of squares 
horizontally or vertically in an unobstructed straight line. 
 
The game uses the complementary methods of capture known as `custodianship` 
and `intervention.` If a Pawn moves orthogonally next to an enemy piece and 
there is another friendly piece directly beyond that, the enemy piece is 
squeezed between the two pieces and captured. This effects a capture by 
custodianship. 
 
Capture by intervention is its reverse. If a Pawn steps between two 
orthogonally placed enemy pieces, it captures them both. 
 
The edge of the board may be used to form any line of three to complete 
a capture. So a Pawn may capture an enemy piece by sandwiching the enemy 
piece between the Pawn and the edge of the board or by stepping between 
the enemy piece and the edge of the board. It is possible to move so as 
to capture in more than one direction at a time. 
 
A player wins when he is able to reduce his opponent to two pieces or less 
or by blockading his opponent so he is unable to move. 


----------------------------------------------------------------
To play:

Double click the Cleave icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Cleave.zrf" in the Open dialog and click "Open"

Cleave.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
