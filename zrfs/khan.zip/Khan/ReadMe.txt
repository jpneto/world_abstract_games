Khan

Game (c) 2002  Joao Pedro Neto
www.di.fc.ul.pt/~jpn/gv
Rules file and graphics (c) 2002  W. D. Troyka
dtroyka@justice.com


Khan is a new game invented by Joao Pedro Neto.  The game is profiled at Neto's World of Abstract Games web site at www.di.fc.ul.pt/~jpn/gv.

Khan is played on a 10x10 square board.  Each player starts the game with twenty Soldiers and six Khans.  The different types of motion are:

Step:  Any piece can move one space orthogonally or diagonally to an empty adjacent square.

Jump:  A Khan can jump an adjacent piece of either color and land in the empty square beyond.  Jumping can take place along an orthogonal or diagonal line.  A Khan can continue to jump as long as jumps are available but is not required to.  To pass on further jumps, click the pass button.

Push:  A Khan can push a straight line of friendly Soldiers (called a "phalanx") one space orthogonally or diagonally.  If the lead Soldier is pushed onto an enemy piece, the enemy piece is captured.

Capture:  A Khan captures an enemy piece by custodian capture, i.e., by sandwiching an enemy between the moving Khan and another friendly Khan.  The capturing Khans and the captured piece must lie along an orthogonal or diagonal line.  A Khan can make multiple captures when jumping.

Support:  A Khan supports a special move by a Soldier.  If a Soldier is adjacent to a friendly Khan, the Soldier can move to any empty square also adjacent to the Khan.  The Soldier can continue to make support moves if available but is not required to.

Win by moving a Soldier to the opposite row or by capturing all enemy Soldiers.


----------------------------------------------------------------

To play:

Double click the Khan game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Khan.zrf" in the Open dialog and click "Open"

Khan.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play 
any number of games against the computer or over the Internet. 
Zillions of Games can be purchased online.  For more information,
please visit the Zillions of Games website:

              <http://www.zillions-of-games.com> 
