Tyr
---
Created by Chris Huntoon, March 2009

Tyr is a variant of Hasami-Shogi. Object: Be the first to establish a Phalanx inside enemy
territory.  A Phalanx consists of 5 pieces in a line in any direction and is made up of 1
Lord and 4 Warriors.  Enemy territory corresponds to the 5 rows on the opponents side of 
the board.  The middle row, marked with the criss-crosses, is considered the frontline of
the battle and therefore mutually shared by both sides.

A player may also win by making it impossible for their opponent to create a Phalanx, 
either by capturing all four of their opponent's Lords or reducing their opponent's 
Warriors to three or less.

Warriors slide like rooks in Chess, i.e. any number of empty spaces up, down, left,or 
right.  It can also make a single jump over another piece of either color that is adjacent
to it horizontally or vertically.  The jumping piece lands on the other side.  This is not
a capture.  The only capturing is achieved by sandwiching your opponent's pieces between
yours along a row or column.  This is similar to Reversi, except that the pieces are 
removed from the board instead of flipped. A sandwich capture along an edge may wrap around
the corner.

Lords have the additonal power of moving and capturing diagonally.  So they slide like 
Queens in Chess, i.e. any number of empty spaces up, down, left, right or diagonally. They
may jump over another piece in any direction.  Also they can make captures diagonally in 
coordination with another friendly piece.

----------------------------------------------------------------
To play:

Double click the Tyr game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Tyr.zrf" in the Open dialog and click "Open"

Tyr.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 