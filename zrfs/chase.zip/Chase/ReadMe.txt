Chase
-----
Invented and implemented by Karl Scherer, June 2000.

Object: Stalemate the king.

Firstly each player drops a king.
Then each player has a double move:
First you move your king, then drop a square. 

In the variants another piece is used instead of the king.
Note that King and Bishop move differently from the way they 
move in chess.


More freeware as well as real puzzles and games under 
http://karl.kiwi.gen.nz.


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Chase.zrf" in the Open dialog and click "Open"

Chase.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

