Hnefatafl v1.1
--------------
Implemented (and 3 variants invented) by Karl Scherer December 2000.
Updated July 7, 2001: improved board colors.
Source: Book 'Board & Table Games I' by R.C. Bell.


Object: White wins if four of his men (Hunns) surround the king (Hnefi) 
orthogonally.
Black wins if the Hnefi reaches the border of the board.

All pieces move like chess rooks, but the Hnefi only one square.
Enemy Hunns are captured by trapping a Hunn between two of the 
player's pieces on rank or file.
A piece may move between two enemy pieces without being captured.

Variant 2 : the Hnefi may move up to two squares at a time.
Variant 3 : the Hnefi moves like a chess rook.
            This is the version I found in a book, but I suspect 
            it to be wrong, since it makes the king too mobile and 
            (imho) gives Black an easy win. 
Variant 4 : the Hnefi moves like a chess rook, but is immobilised 
            as long as it is trapped between to enemy pieces on 
            rank or file.


Hnefatafl was played in the Middle Ages.
It originated from the game Tafl, of which no description has survived.


More freeware as well as real puzzles and games at my homepage 
http://karl.kiwi.gen.nz.


----------------------------------------------------------------
To play:

Double click the Hnefatafl icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Hnefatafl.zrf" in the Open dialog and click "Open"

Hnefatafl.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

