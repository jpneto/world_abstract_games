Kerfuffle
---------------
Created by Chris Huntoon, 2011
Please send any feedback to Hartunga66@yahoo.com


Checkers played on a 9x9 board.  This effects play in a number of ways:
*The layout is completly symmetrical.
*Pieces can move and bank in all four corners.
*A piece can no longer be blockaded in two of the corners.
*Beginning the game with three rows separating the two sides gives players more opportunity to develop their pieces before coming in contact.
*The slightly larger play area allows pieces more space to maneuver in. 

To decrease the likelihood of draws, the 'one or none' rule is used - a player loses if he is reduced to either a single piece or no pieces at all.

Other than this, the game follows the basic rules of Checkers.  Promoted pieces are 'flying Kings' and are able to slide and jump over any number of empty spaces

----------------------------------------------------------------
To play:

Double click the Kerfuffle game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Kerfuffle.zrf" in the Open dialog and click 
   "Open"

Kerfuffle.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 