Ecke
----
Invented and Implemented by Charlie Foxtrot, January 2004.



Ecke is a game for any number of players (though different tactics hold for different numbers of players) who take turns moving. Play is on a two-dimensional board of any size on which are disks of different colors (standard Ecke uses four colors).

Moves consist either of slides or spawns.
Slides: Move a disk any number of spaces along one of two possible directions, which depend upon color.
Spawns: Add a new disk of some color to the board on the possible sliding path of a disk (the color dropped depends upon the color of the disk who's path it's placed in, who is said to 'spawn' the new disk).

In standard play:
White can move up or right and spawns Black
Blue can move right or down and spawns Red
Black can move left or down and spawns White
Red can move up or left and spawns Blue

The player to stalemate is the winner.


Zillions typically does not play well until the endgame, then makes a fair opponent.


----------------------------------------------------------------
To play:

Double click the Ecke game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Ecke.zrf" in the Open dialog and click "Open"

Ecke.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com>