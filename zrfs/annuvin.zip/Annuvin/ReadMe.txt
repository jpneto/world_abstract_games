Annuvin
-------
Invented and implemented by Jeff Roy, November 2001.


In this game, capturing your opponent's pieces makes their remaining 
pieces more powerful.

Each player begins with six pieces.  On his move, a player may move 
one of his pieces up to n spaces in any combination of directions, 
where n varies depending on the number of pieces he has remaining:

Six pieces remaining:  one space per turn
Five pieces remaining:  two spaces per turn
Four pieces remaining:  three spaces per turn
Three pieces remaining:  four spaces per turn
Two pieces remaining:  five spaces per turn
One piece remaining:  six spaces per turn.

A piece may move over intervening pieces. A piece may capture an 
opposing piece by moving onto it.  If a piece makes a capture before 
it has used all of the spaces available to it that move, it may continue 
to make additional captures until it has moved its limit. 
The player who captures all of his opponent's pieces wins.

Under the official rules, a player also wins if he reduces his opponent 
to one piece without losing any of his own pieces (this addresses the fact 
that six pieces cannot quite cover the entire board).  I couldn't figure 
out how to implement this, so the Zillions version doesn't include this rule.


----------------------------------------------------------------
To play:

Double click the Annuvin icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Annuvin.zrf" in the Open dialog and click "Open"

Annuvin.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
