Petteia
-------
Implemented by Uwe Wiedemann, June 2001.


The objective is to either capture or immobilize all the enemies 
stones. The principle of play is to surround an enemy on two sides, 
in a horizontal or vertical line. Black plays first. Dogs move as 
rooks in chess; orthogonally (horizontal or vertical, but not diagonal).  
A Dog  is captured when it is surrounded on two orthogonal sides. 
Multiple stones can be captured when surrounded on two orthogonal sides. 
A stone can be played inside two enemy stones without being captured. 
The outside walls cannot be used to capture Dogs. First player to kill 
all his opponents Dogs wins. A player can also win by blocking up the 
enemy Dogs such that they cannot move.


Petteia is an ancient greek game. The Greeks played this game by 
at least the 5th century BCE. Plato tells us that Petteia originally 
came from Egypt. Obviously the game is very similar to the Egypt game Siga. 
All properties we know about the ancient Petteia are fullfilled by Siga. 
Unfortunately it is not possible to create a Zillions variant of the 
Siga game. Because there is a move order which can't implemented in a 
ZRF-file with an acceptable result.


----------------------------------------------------------------
To play:

Double click the Petteia icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Petteia.zrf" in the Open dialog and click "Open"

Petteia.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
