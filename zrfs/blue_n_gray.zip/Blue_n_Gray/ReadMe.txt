Blue & Gray
-----------
Invented by Henry Busch & Arthur Jaeger, 
Implemented by Roger Cooper, December 2000.


The captain moves 1 position forward along the heavy line towards 
the red dot in the middle of the board. If the next position is 
occupied, the captain cannot move. 
The guards move 1 position in any direction along any line 
including heavy line. They can't enter the red dot. Guards capture 
by jumping like in checkers. Multiple jumps are allowed. Capturing 
is mandatory.

Victory is achieved by moving the Captain to the red dot. 
You also can win by moving 3 spaces further along the track than 
your opponent. (The original rule was whichever player was furthest 
advanced wins, but I have been unable to implement in Zillions).


The game is described in Sid Sackson's book, a Gamut of Games. 
It states that the game was designed by Henry Busch & Arthur Jaeger. 
No further details are given. I have also seen the same game under 
the name of Cats & Dogs and Wild West.


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Blue & Gray.zrf" in the Open dialog and click "Open"

Blue & Gray.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

