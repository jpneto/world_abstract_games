Eximo
-----
Created by Matteo Perlini, February 2013.


OBJECT: Capture all your opponent's pieces by jumping over them, or
stalemate the opponent so he has no moves.

Checkers can move or capture.

A checker can move forward or diagonally forward.
There are two type of move: ordinary move and jumping move.

- ORDINARY MOVE: a checker moves to a (forward or diagonally forward) adjacent and empty square.
- JUMPING MOVE: a checker jumps over a (forward or diagonally forward) adjacent friendly piece if the next square in the same direction is empty, placing the jumping checker on the next empty square. If the same player's
checker can continue moving by jumping another friendly piece then it must do so. (No need to choose the longest path.)

A checker can capture forward, diagonally forward, right or left. 

- CAPTURE: a checker jumps over a (forward, diagonally forward, right or left) adjacent opponent's piece if the next square in the same direction is empty,
placing the jumping checker on the next empty square. The opponent's piece is removed from the board immediately.
If the same player's checker can continue capturing by jumping another opponent's piece then it must do so.
Capturing is mandatory, and you must keep capturing as long as it is possible.
(No need to choose the longest path.)

When a checker reachs the other end of the board, it is removed from the board immediately and the player gets two extra-moves to make
instantly: dropping two new checkers in any empty square in his own first two rows, except in the four squares on the sides.
(Drop zone for Black: b1, c1, d1, e1, f1, g1, b2, c2, d2, e2, f2, g2;
for White: b8, c8, d8, e8, f8, g8, b7, c7, d7, e7, f7, g7).

If a checker reaches the other end of the board and there isn't any empty square in the drop zone, the player loses that piece.
If there are just one empty square in the drop zone, the player gets only one drop.
    

----------------------------------------------------------------
To play:

Double click the Eximo icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Eximo.zrf" in the Open dialog and click "Open"

Eximo.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
