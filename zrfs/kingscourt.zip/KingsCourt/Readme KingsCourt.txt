 ----------------------------------------------------
 *** King's Court v 2.0 Readme.txt file           ***
 * *    ( The Original Game of Supercheckers )    * *
 * *                                              * *
 * * implemented by K. Franklin, June, 2002       * *
 * * e-mail address: kenf@ica.net                 * *
 ----------------------------------------------------

built upon Zillions Development's own Checkers.zrf v1.2 (and images)

v2.0: fixed Define errors (centre-shift-grn-...)


Display Note:  The Board (15x15) grid requires a minimum screen resolution of 1024x768 to be viewable.

Object:
Stay in the court.
After the first move, each side must maintain at least one King within the Center Court at all times.
In this game, a player may jump over any playing piece(s), capturing only the opponent's checkers.
Jumping doesn't have priority over Moving.

Orange plays first; moving a King into the Center Court.  Green's first move must be from the opposite
side.  Jumping isn't allowed until each side has played two moves.  The game table's PASS Button is
available to Orange only (Human player) assuming Green is played by the computer.  Passing is only
allowed when faced with subsequent jumps during a single turn.


The game is won when the opposing side no longer has any kings in the center court or has lost every
playing piece.


History:
King's Court, (The Original Game of Supercheckers) was released by Western Publishing Company Inc.
in 1989 as a traditional board game.  



--------------------------------------------------------------------------------------------------

You should extract the game preserving path names. 

To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "KingsCourt.zrf" in the Open dialog and click "Open"

KingsCourt.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 


 