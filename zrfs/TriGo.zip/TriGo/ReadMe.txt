TriGo is a two-player territorial game using black and white pieces
placed by each player in turn on the intersections of lines making
up a hexagonal grid. The Zillions game rules file TriGo.zrf includes
6 variants with board sizes ranging fron 3 to 13 cells across. Game
logic is similar to traditional Go: previously-played pieces are
removed from the board when the last empty point that they connect
to is taken by an opponent's piece. When the last piece is played,
or there are no legal moves, or both players pass in turn, the game
ends. The winner is the player with more pieces left on the board.
	
Try to play each piece so that it not only expands your territory
but can also easily connect to unoccupied points, usually via your
other pieces. Although TriGo is based on traditional Go, most of
the points on the board have 3 neighbors rather than 4, making
connecting to empty points harder and captures easier than in Go.

Based on Go.zrf written by L. Lynn Smith (permissions requested)

TriGo mods by Bob Henderson

-------------------------------------------------------------------

The downloaded file "TriGo.zip" should be unzipped in the directory
where you keep your other Zillions game rule files. This will add a
"TriGo" directory with the game rules file "TriGo.zrf," this ReadMe
file, and subdirectories containing the graphics files, etc. used
by the rules file.

To play:

Double click the TriGo icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "TriGo.zrf" in the Open dialog and click "Open"

TriGo.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
