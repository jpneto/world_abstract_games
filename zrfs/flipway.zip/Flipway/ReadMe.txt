FLIPWAY
-------

Flipway was designed by Luis Bola�os Mures in July, 2020.

Zillions implementation by Luis Bola�os Mures.

--------------------------------------------------------
To play:

Double click the Flipway game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Flipway.zrf" in the Open dialog and click "Open"

Flipway.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com>

--------------------------------------------------------
To start, Black places a black stone on an empty point. From then on, starting with White, the players take turns. On your turn, you must perform exactly one of these actions:

- DROP: Select a 2x2 area including one or more empty points, such that no other 2x2 areas include all those empty points as well as at least another empty point. Then place a stone of your color on each empty point in the selected area.

- FLIP: Replace the two enemy stones in a crosscut with stones of your color. A crosscut is a 2x2 area of the board containing two diagonally adjacent black stones and two diagonally adjacent white stones.

You win by completing a chain of orthogonally adjacent stones of your color touching the two opposite board edges of your color. Draws are not possible.

In this implementation, the program only checks the winning condition on the 3x3, 4x4 and 5x5 boards. 60 variants are included.