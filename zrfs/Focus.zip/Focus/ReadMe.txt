Focus v1.0
----------
Invented by Sid Sackson
Implemented by Karl Scherer, December 2007.


Object: capture all your opponent's pieces.
(4 variants)

The Focus board is a checkerboard with the three squares in each corner removed,
thus forming a 6�6 board with 1�4 extensions on each side.

Two players move stacks of one to five pieces orthogonally.
Stacks may move as many spaces as there are pieces in the stack. 
Players may only move a stack if the topmost piece in the stack is one of their pieces. 
When a stack lands on another stack, the two stacks merge; 
if the new stack contains more than five pieces, then pieces are removed from the 
bottom to bring it down to five. 

If by this removal process a player's own piece is removed, they are kept. 
The system displays these stores pieces at the top and bottom border.
A stored piece may be placed on an empty or occupied position of the main board
later in lieu of moving a stack.
Note that only the rightmost stored piece can be re-inserted to the board.
If an opponent's piece is removed, it is captured.

The last player who is able to move a stack wins.

Variant 2: slightly different board design.
Variants 3 and 4: like variants 1 and 2, but tokens from the reserve can
only reinserted to empty positions.

Please note: in variants 2 and 4 there is an alternative piece set available.

 
Focus is an abstract strategy board game, designed by Sid Sackson 
and first published in 1964 by Kosmos. 
The game has been re-published many times since, sometimes under the titles 
Domination or Dominio. Focus won the 1981 Spiel des Jahres and Essen Feather awards. 
The game appears in Sackson's A Gamut of Games in the section New Battles 
on an Old Battlefield.


----------------------------------------------------------------
To play:

Double-click the Focus icon, or...

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Focus.zrf" in the Open dialog and click "Open"

Focus.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

