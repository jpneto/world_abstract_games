Bombardment
-----------
Created by Chris Huntoon, February 2003.


Object:  Be the first to hit the enemy's coast with a Missle while 
defending your own coastline from attack.  If you manage to destroy 
all your enemy's Missles and so leave their coast completely undefended, 
you automatically win the game. 
�
A Missle can move ahead one square, either diagonally or straight ahead. 
It may not land on a space already occupied by another missle.  A Missle 
may detonate, removing all Missles on the eight surrounding squares and itself. 


----------------------------------------------------------------
To play:

Double click the Bombardment game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Bombardment.zrf" in the Open dialog and click "Open"

Bombardment.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

