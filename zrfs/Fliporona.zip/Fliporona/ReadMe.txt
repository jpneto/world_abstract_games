Fliporona
---------
by Vincent Everaert, april 2006.
vincent.everaert@club-internet.fr
---------
Fliparona is a Fanorona/Reversi variant.

Usual rules of Fanorona are used but :
- one must flip the opponent's pieces instead of removing it ;
- the capturing piece is removed after it's movement.

It's a hard job to beat Zillions!!
----------------------------------------------------------------
To play:

Double click the Fliporona icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Fliporona.zrf" in the Open dialog and click "Open"

Area.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
