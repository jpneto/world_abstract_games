QUERY
-----

Query was invented by Christian Freeling in 2010. It's based on a general idea which was first stated by Torben �gidius Mortensen.

Zillions implementation by Luis Bola�os Mures.

--------------------------------------------------------
To play:

Double click the Query game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Query.zrf" in the Open dialog and click "Open"

Query.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com>