Super Blue & Gray
-----------------

Background:
Invented by Henry Busch & Arthur Jaeger. 
Super Blue and Gray is based on Blue and Gray implemented by Roger Cooper, December 2000.
Modified to include multiple new variants by Richard Hutnik, January 2003.

This games is based on the original Blue and Gray by Busch & Jaeger, 
but goes beyond the original game to address some of the gameplay problems
that occured in the original game, plus include other variants to speed things up.  
The original game is described in Sid Sackson's book, 
a Gamut of Games. It states that the game was designed by Henry Busch & Arthur Jaeger. 
No further details are given. I have also seen the same game under 
the name of Cats & Dogs and Wild West.


Object:
The object of the game is achieved by moving the Captain to the red dot, by moving it along
the black line that runs throughout the board.  Each player's Captain follows a different path
to reach the red dot.  This red dot space may only be occupied with a captain piece.  No
other piece may move onto it.

In some variants, you can also win the game, if you move your captain 3 
spaces further along the track than your opponent.  This variant is active whenever a regular
Captain is used, as opposed to the Turbo Captain.


Order of play:
Players alternate turns moving one of their pieces.  Pieces move as described in the
next section.  Capturing is manditory, and is done by jumping vertically and/or horizontally.  
Multiple jumps are possible.
  

Pieces (names and how they move):
- Captain (a circle with a + on it):  This is the main piece of the player.  It may not capture 
or be captured. It moves along the heavy black line one space towards the red dot in the middle 
of the board. The captain can't be capture or captured.  If the next space is occupied by a piece, 
the captain can't move.
- Turbo Captain (a circle with a star on it):  This is similar to a regular captain but has extra
mobility.  This piece moves along the black line until it it can't move due to a piece blocking a space
or it reaches the red spot (and wins the game).
- Private (plain circle):  This piece is similar to a non-king Turkish checker.  It may move one space left or 
right or one space forward, but not along the path the captain piece moves on.  When a Private reaches 
the back row  of the opponent, it is promoted (just like in regular checkers).  The Private piece is 
promoted to a Sargeant.
- Sargeant (a circle with a dot on it): This piece move 1 position in any direction along any line including 
heavy line. They can't enter the red dot. Guards capture by jumping like in checkers. Multiple jumps are allowed. 
Capturing is mandatory.


Description of variants:
In this game, there are multiple variants of different types:
- Turbo Captain variants: This variant starts the players with a turbo captian, rather
than a regular captain piece.
- Super variants:  This variant starts the players with Private pieces rather than
sargeant pieces.  
- Classic variants:  This variant starts the players with Sargeant pieces rather than
private pieces.
- 3 space difference = win variants:  This variant is only used in games where a regular Captain piece
is used.  If a player advances their Captain piece 3 spaces further along to the red spot in the center
of the board, that player wins.  This rule was originally in Roger Cooper's design and was kept to
assist the play of the AI in the game.  This rule was excluded from the Turbo Captain variants due to
game balancing issues.
- Light variants: The players play with half the normal pieces.  This makes for a shorter game.
- POW variants:  This variant starts the players with their king trapped behind enemy lines.  The objective
is the same as in regulard Blue and Gray, but the game plays out differently.


Designer Notes:
I had seen Blue and Gray in Sid Sackson's book and it piqued my interest.  When I had seen it, I had
thought mixing checkers in with it would be a nature.  I played it a few times and it worked.
When I adapted my version of the game to Zillions, the idea of the Turbo Captain came about.  With
this came the POW variant idea.  I also threw in a light variant, to make for a quicker game.


Closing Comments:
There is a graphics glitch that occurs when the board is flipped.  Please keep this
in mind.  If you have any questions, suggestions or comments on this file and game, feel free to contact me at:
richardhutnik@hotmail.com



----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "SuperBlueGray.zrf" in the Open dialog and click "Open"

SuperBlueGray.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

