Tanbo (version 1.0)
-------------------

Invented by Mark Steere
Implemented by Greg Schmidt (gschmidt958@yahoo.com)

OBJECT OF THE GAME:
During play, stones of both colors are added to and removed from the board.
Eventually, all stones of one color will be removed while at least one stone
of the opposite color remains.  The player who still has one or more stones
on the board after all opposing stones have been removed is the winner.

BASIC MOVES:
Players take turns adding their own stones to the board, one stone per turn,
starting with Black.  You must place your stone onto an unoccupied point which
is horizontally or vertically adjacent (hereafter "adjacent") to exactly one of
your on-board stones.  You cannot put your stone on a point which is not
adjacent to any of your stones, nor can you place your stone adjacent to two
or more of your stones.  It doesn't matter how many (if any) opposing stones
are adjacent to your newly added stone.

ROOTS:
Tanbo is a game of "roots", or groups of connected, like-colored stones.
Players start the game with a pre-defined number of single-stone roots each.
When placing a stone as described in the preceding section, you are connecting
your stone to, and expanding, exactly one of your other on-board stones.  The
basic move rule requires that your newly added stone must connect to exactly
one of your other on-board stones.  This precludes the formation of clumps and
closed loops in roots.  Also, it precludes the merger of roots.

ROOT REMOVAL:
The "current root" is the root you connect a stone to on your turn.  A "bounded
root" is a root which has no possibility of expansion.  If your move bounds one
or more roots, including the current root, you must immediately remove the current
root, and only the current root, while it is still your turn.  If your move bounds
one or more roots, not including the current root, then you must immediately remove
all of the roots which were so bounded while it is still your turn.  There should
not be any bounded roots on the board at the conclusion of your turn.

For additional information, see "Tanbo_rules.pdf".

Tanbo uses the "Axiom" Meta-game engine.

----------------------------------------------------------------
This game requires the "Zillions of Games" program.  Please
visit <http://www.zillions-of-games.com> for details.
----------------------------------------------------------------