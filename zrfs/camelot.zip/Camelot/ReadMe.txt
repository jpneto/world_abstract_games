Camelot
Game invented by George S. Parker in 1887
Rules file and graphics (c) 2002  W. D. Troyka
dtroyka@justice.com


(Requires ZoG version 1.2.3 or higher)

Camelot is one of the great boardgames of the nineteenth century, along 
with Reversi and Halma.  Invented in 1887 by George S. Parker, founder 
of Parker Brothers, it was originally marketed under the name Chivalry. 
The game achieved a substantial following after its re-release in 1930, 
with minor rule changes, under the name Camelot.  Its players included chess 
champion Jose Raoul Capablanca, also known as the inventor of Capablanca 
Chess.  In recent years the World Camelot Federation has rekindled interest 
in the game.  To learn more about the history of Camelot, and to join the 
Federation, visit http://communities.msn.com/worldcamelotfederation.  Camelot 
was featured in an article in the seventh edition (summer 2001) of Abstract 
Games Magazine. 

Camelot is played on a 12x16 board, with eight squares removed from each of 
the corners to give the board an oval shape.  Two spaces protrude from both 
the top and bottom of the board.  These are called the "castles."  The object 
of the game is to occupy the enemy castle by moving two of your pieces into it.  
You also win by capturing all opponent pieces, provided you have at least two 
pieces remaining.  A draw is declared if both players are reduced to a single 
piece.  Stalemate is a loss.

Each player starts the game with 14 pieces, consisting of ten Men and four 
Knights.  A Man has three basic moves.  It may move one space in any direction, 
orthogonal or diagonal.  This is called a "plain" move.  It may jump over a 
friendly adjacent piece and continue jumping, at its option, as long as friendly 
pieces remain to be jumped.  This move is called "cantering."  And it may jump 
over an enemy piece, thereby capturing it, in which case it must continue jumping 
as long as captures are available.  A Man may not canter and capture in the same 
move. 

The Knight has all the moves of the Man plus one important addition, called the 
Knight's "charge."  A charge consists of a cantering move (or series) followed by 
capturing.  Once a Knight makes a capture, it must continue making captures if 
available and may not return to cantering.

Circular canters, i.e., canters that return to an already visited square, are not 
permitted.  Visited squares are indicated by flags.  To make the flags invisible, 
select `switch piece set` from the View menu.  The flags are cleared at the end 
of the cantering sequence.  To pass on further canters, move the piece to the 
Knight graphic of your color in the lower left or upper right corner of the 
board.  The piece will not actually change location.

Capturing is compulsory but there is no requirement of choosing a path of maximal 
captures.  A player is not required to make a Knight's charge, with the exception 
that when a capture is directly available, the player may satisfy the compulsory 
capture rule through a Knight's charge.  When cantering a Knight must make a 
capture if one becomes directly available but may do so through a charge.

Special rules govern the castle.  Once a piece enters the enemy castle, it may 
never leave.  A piece in the enemy castle is permitted to move laterally twice 
during the game.  You may never enter your own castle except through a capture, 
in which case the piece must be moved out as soon as possible.  If the piece 
cannot move out through another capture on the same turn, then it must be moved 
out on the next turn (even if this means declining a capture elsewhere on the 
board).  When moving out of the castle, priority is given to capturing or charge 
moves.

In the All Knighter variant each player starts with 14 Knights.  The Notation 
variant consists of regular Camelot with a notation key.

Special thanks to Michael W. Nolan for his help in developing this script.  
Please send any comments or bug reports to dtroyka@justice.com. 


----------------------------------------------------------------

To play:

Double click the Camelot game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Camelot.zrf" in the Open dialog and click "Open"

Camelot.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play 
any number of games against the computer or over the Internet. 
Zillions of Games can be purchased online.  For more information,
please visit the Zillions of Games website:

              <http://www.zillions-of-games.com> 


 