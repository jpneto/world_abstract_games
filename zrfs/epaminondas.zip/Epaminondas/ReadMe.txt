Epaminondas 

Epaminondas (c) 1975 Robert Abbott 
Crossings (c) 1969 Robert Abbott 
www.logicmazes.com

Rules file and graphics (c) 2002  W. D. Troyka
dtroyka@justice.com


Epaminondas, invented by Robert Abbott, is often described as a modern 
classic.  The game is named after a Theban general credited with innovations 
to the phalanx which led to the Theban victory over Sparta in 371 B.C.  
Epaminondas was originally published in 1969 under the name Crossings 
in Sid Sackson's A Gamut of Games.  In 1975 Abbott released a revised 
version of the game, now called Epaminondas, played on a larger board and 
with a modified capturing rule.  The original Crossings is included as a 
variant in this package.  Both Epaminondas and Crossings are described in 
Wayne Schmittberger's New Rules for Classic Games (1992).  Epaminondas was 
featured in the third issue of Abstract Games Magazine (Autumn 2000) and 
favorably reviewed in David Parlett's Oxford History of Boardgames (1999). 
The game is profiled at Joao Pedro Neto's World of Abstract Games website at www.di.fc.ul.pt/~jpn/gv and is available for play at Richard's play-by-email 
server at www.gamerz.net/pbmserv.  To learn more about the game, and to check 
out Robert Abbott's collection of mazes, puzzles, and games, visit his website 
at www.logicmazes.com.

Epaminondas is played on a 14x12 board.  Each player begins with 28 pieces 
occupying two rows on opposite sides of the board.  Motion in the game is 
performed by phalanx.  A phalanx in the game consists of a line of adjacent 
pieces (diagonal or orthogonal).  A single piece can be considered a 
phalanx of one.  A phalanx moves along the line on which it is situated, 
forward or backward, any number of spaces up unto the number of pieces 
contained in the phalanx.  For example, four adjacent friendly pieces on a 
common diagonal can move from one to four spaces, as a group, along the 
diagonal in either direction.  Spaces moved through must be empty and the 
lead piece in the phalanx must come to rest on an empty space or a space 
occupied by an enemy.  In the latter case, the enemy piece and all enemy 
pieces forming a phalanx behind it in the direction of motion will be 
captured, but only if the moving phalanx is longer than the attacked 
phalanx.  If the moving phalanx is shorter than or equal in length to the 
attacked phalanx, the move cannot be made.

A part of a phalanx can be moved provided the part is itself a phalanx.  
For example, if there are five adjacent friendly pieces in a row, two 
pieces at one end can move forward one or two spaces as a phalanx of two, 
or three pieces can move forward up to three spaces, and so on.  Pieces can 
be part of multiple phalanxes.  A single piece moves like a King in chess, 
one step to any adjacent empty square, but it can never capture.

The object of the game is to move a piece onto the far row (row 12 for 
White, row 1 for Black).  When a player moves a piece onto the far row, the 
opponent is given a grace move to equalize the situation by capturing the 
piece just moved or by moving a piece itself onto its far row.  A win is 
declared when a player has a piece on the far row (or one more piece than 
the opponent has on its far row) and the opponent has completed the grace 
move without equalizing the situation.  Repetition is a loss.

The Epaminondas 8x8 variant is, naturally, played on an 8x8 board.  The 
game Crossings follows the original 1969 rules contained in A Gamut of 
Games.  These rules are the same as for Epaminondas except that the board 
is 8x8, a moving phalanx captures only the first enemy piece in the 
attacked phalanx, and a piece that reaches the far row is frozen and can 
neither move nor be captured.

Please send any comments or bug reports to dtroyka@justice.com.


----------------------------------------------------------------
To play:

Double click the Epaminondas game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Epaminondas.zrf" in the Open dialog and click "Open"

Epaminondas.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play 
any number of games against the computer or over the Internet. 
Zillions of Games can be purchased online.  For more information,
please visit the Zillions of Games website:

              <http://www.zillions-of-games.com> 


 