Coronet
-----------------
Created 2012, Impelemented 2013
Copyright (c) 2013, Chris Huntoon
Please send any feedback to Hartunga66@yahoo.com

Coronet is a new member of the Checkers family.  I refer to it as Omni-directional Checkers because it is the first type of Checkers to fully combine, in equal measure, both diagonal and orthogonal movements and captures, and makes use of all eight directions.  Other versions of Checkers have mixed diagonal and orthogonal movements and/or captures before, but only under limited circumstances.  For example, in Frisian Checkers, orthogonal directions can only be used when jumping the opponent's pieces and pieces must always stick to same color of the checkerboard.

The two diagonally opposite corners are specially marked.  These spaces are referred to as "Coronation Squares."

A Pawn can move horizontally, vertically, or diagonally, but only forward - that is in the direction of the opposite corner.   When a pawn reaches the opposite Coronation Square, it promotes to a Queen.  The promotion zone in Coronet consists of a single space.

Captures:  Captures are made by jumping over an enemy piece to a vacant square on the other side.  Jumps can be performed in all eight directions.  Capturing is mandatory, and you must keep jumping and capturing as long as it is possible, taking the maximum number of pieces.  Captured pieces are left on the board until the chain of jumps is completed and the same piece may not be jumped twice.  A Pawn that lands on the Coronation Square in the middle of a series of jumps does not promote.  To promote, it must finish its turn on the Coronation Square.

A Queen can slide any number of open spaces in any direction, like a Chess Queen.  When jumping, it need not end in the square immediately behind the taken piece, but may continue any unobstructed distance along the same path (AKA a "flying King").  Unless there is no alternative, a Queen may not end its move on the Coronation Square on its own side of the board.  This is known as the "Queen's Courtesy."

First player unable to make a move on his turn, either by having all his pieces captured or immobilized, loses.  Draws are virtually impossible.  Two Queens will inevitably defeat a lone Queen.

----------------------------------------------------------------
To play:

Double click the Coronet game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Coronet.zrf" in the Open dialog and click 
   "Open"

Coronet.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
