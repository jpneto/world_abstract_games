Polarity
--------
Created by Chris Huntoon, January 2001.

Updated Januari 27, 2001: fixed draw rule omission.


Half of the pieces are designated as Positive, the other half 
Negative. If you capture all your opponent's Positive pieces, 
you win. However, if you are forced into capturing all your 
opponent's Negative pieces, you lose.

Other than this, the game follows the rules of Spanish Checkers. 
This is played very much like Anglo-American Checkers, the main 
difference is that the Doubleton has a more substantial move 
along any number of vacant squares, including ones beyond a 
captured piece. Captures are mandatory. If a player has a choice 
of captures he must take the greater number of pieces.


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Polarity.zrf" in the Open dialog and click "Open"

Polarity.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

