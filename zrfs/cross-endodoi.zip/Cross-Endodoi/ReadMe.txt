Cross-Endodoi

(c) 2002  W. D. Troyka
dtroyka@justice.com


Cross-Endodoi is a variant of the game Endodoi, also available on 
Zillions.  Cross-Endodoi follows all the rules of Endodoi except that
holes with an odd number of beans sow clockwise, whereas holes with an
even number continue to sow counterclockwise.  As in Cross-Wari and
Cross-Kalah, the effect of this rule change is to create new tactics 
for keeping pieces on your side of the board and for controlling the 
direction of sowing.  Sowing occurs in a whipsaw fashion, with beans
sowed in one direction only to have the beans in the drop hole picked
up and sowed in the reverse direction.  By toggling holes from even-
flowing to odd-flowing, the opportunities for sowing into an empty 
hole on your side (and thus threatening capture) are substantially 
increased.

For a complete statement of the rules, please read the "Game 
Description" in the Help menu.  Cross-Endodoi comes with four 
variants.

Please send any comments or bug reports to dtroyka@justice.com.  
For a list of other Mancala games available on Zillions, check out 
the Mancala download page.

You should extract the game from the downloaded zip file 
preserving path names. 


----------------------------------------------------------------
To play:

Double click the Cross-Endodoi icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Cross-Endodoi.zrf" in the Open dialog and click "Open"

Cross-Endodoi.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 