Gauntlet
--------
Invented and implemented by Phillip L. Leduc, December 2000.

Gauntlet is a fast and furious game of unequal forces that 
challenges players to take on the role of underdog. Can you win 
against overwhelming odds? 

Players have mutually exclusive goals. The object of the game 
for the runner player is to survive a gauntlet of blockers and 
reach the last rank with just one piece. For the blocking player, 
the object is to capture or block the other player's runners. 

Pieces move in one direction only. Runners move up either 
shifting into an empty space or by jumping and capturing. 
Blockers move in a similar manner except that they move either 
left or right. In standard Gauntlet, captures are mandetory, with 
the moving player choosing between multiple opportunities. 

In additiion to the standard version of Gauntlet, there are five 
variants. Three with smaller, tighter set-ups, one with a shorter 
gauntlet for the runner player and the Artful Dodger variant which 
gives the runner player optional captures.

A Gauntlet match consists of an even number of games with players 
alternating as the runner player. Points are awarded to the runner 
player, two points for reaching the last rank or one point if 
stalemated. Otherwise, no points are scored. 
The winner of the match is the player with the highest point total 
after an even number of games are played.


----------------------------------------------------------------

To play:

1. Run "Zillions of Games".
2. Choose "Open Game Rules..." from the File menu.
3. In the Open dialog box, select "Gauntlet.zrf" then click "Open".

Gauntlet.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games is a game engine that allows 
you to play any number of games against the computer or over the 
Internet and can be purchased on-line. 
For more information and games, visit the Zillions of Games website

              <http://www.zillions-of-games.com> 

