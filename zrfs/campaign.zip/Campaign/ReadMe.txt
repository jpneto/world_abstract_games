Campaign
--------
Created by Chris Huntoon, December 2001.


The board begins empty. The players each drop a knight anywhere 
on the board. After that, the players alternate moving their knight. 
When a knight moves from a square he leaves behind his banner to 
show he's already claimed that space. The object is to get five of 
your banners in a row in any direction. 
�
To move, click on the square you want to move to, not the knight. 
A knight may not land on the other knight or a space marked with 
a banner. If a knight becomes trapped and unable to make a move, 
the player automatically forfeits the game. 


----------------------------------------------------------------
To play:

Double click the Campaign icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Campaign.zrf" in the Open dialog and click "Open"

Campaign.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
