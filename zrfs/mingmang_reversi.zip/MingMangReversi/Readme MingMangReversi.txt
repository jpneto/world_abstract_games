-----------------------------------------------
*** Ming Mang Reversi (v1.1)                *** 
* *                                         * *
* * implemented by K. Franklin, Dec. 2015   * *
* * updated, Jan. 2016                      * *
* * e-mail address: frnklnk@yahoo.ca        * *
-----------------------------------------------
Copyright 1998-2000 Zillions Development (v1.31)
*** modified from Dominion.zrf, that in turn was developed from Blobs.zrf & Reversi.zrf v.1.2

You need to purchase Zillions of Games to load this rules file
Visit the Zillions web site at http://www.zillions-of-games.com
---------------------------------------------------------------

V1.1: two background boards are included, One is aligned to it's
intersecting lines - per this game's originating design, the other
is more familiarly aligned to the spaces.


Ming Mang is a Reversi style game from Tibet (now a part of China).
Originally configured with a 17x17 board layout, more common 8x8 boards have
been substituted.  A 12x12 variant is also included here.
Starting positions have each player's pieces filling an outside 
row and adjoining column.
The total number of on-board pieces doesn't change during gameplay.  
Note: Only the 8x8 variant operates correctly under Zillions v1.31.

Object:
Win by capturing all of your opponent's disks or forcing a stalemate.  Moves are 
comprised of two parts:
1)  Slide one of your side's pieces orthogonally across any number of adjacent empty squares.
2)  Additionally, all enemy pieces orthogonally sandwiched between the newly placed disk and 
	another friendly piece will be flipped.
(Diagonal directions are NOT included within this game.)


You should have extracted this zip file preserving path names.
--------------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "MingMangReversi.zrf" in the Open dialog and click "Open"

MingMangReversi.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 



