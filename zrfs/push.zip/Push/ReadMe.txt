Push
----
Invented and implemented by Karl Scherer, August 2001.


Object: Move all your pieces to the last two ranks of the board.
(8 variants)

Push Moves:
By moving the last Token in a row you can push one or more of your Tokens
as far as empty spaces are available, but not more than 3 steps.
The pushing Token is called the 'Pusher'.
Push moves are either orthogonally or diagonally.

Forward moves (Push Moves or Jumps, see variants 3 and 4) 
have priority over sideways or backward moves.

The first player to fill the opposite two ranks wins.
There are no captures in this game.

Variant 2: If you pushed more than one Token, you may execute another 
           forward (!) Push Move using the same Pusher.
           These additional partial moves must always change direction 
           and must push more than one Token.
Variants 3, 4: Like variants 1, 2 with additional jumps:
           If your piece is on rank 1 or 2 you may jump over an enemy piece.
Variants 5, 6, 7, 8: Like variants 1, 2, 3, 4,
           but you may push your Tokens only up to two steps per move. 

Recommended: Switch Move Animation on!


The game Push introduces a new type of moves, the Push Moves, 
to the area of classic Chinese Checkers-type board games.


More freeware and real puzzles and games at my homepage: karl.kiwi.gen.nz .


----------------------------------------------------------------
To play:

Double click the Push icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Push.zrf" in the Open dialog and click "Open"

Push.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
