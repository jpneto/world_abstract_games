Cross-Kalah

(c) 2001  W. D. Troyka
dtroyka@justice.com


Cross-Kalah is a variant of the Mancala game Kalah, also available on 
Zillions.  Cross-Kalah follows all the rules of Kalah except that holes 
with an odd number of beans sow clockwise, whereas holes with an even 
number continue to sow counterclockwise.  As in Cross-Wari, the effect 
of this rule change is to create new tactics for keeping pieces on your 
side of the board and for controlling the direction of sowing.  These 
tactics are more pronounced in Cross-Kalah because of the nature of 
capturing.  By toggling holes from even-flowing to odd-flowing, the 
opportunities for sowing into an empty hole on your side (and thus 
threatening capture) are substantially increased.

For a complete statement of the rules, please read the "Game 
Description" in the Help menu.  Cross-Wari comes with four variants.

NOTE:  Kalah has been substantially updated.  A few bugs in the 
capturing rules have been fixed, hole capacity has been increased 
from 24 to 36 beans, and the code has been optimized in order to 
avoid loading problems that some users experienced.  

Wari and Cross-Wari have also been updated (again!) to take 
advantage of ZoG v.1.3, to resolve a compatibility issue, and to 
correct a minor bug in the capturing logic.  

If you have already downloaded these games, I recommend that you 
download the new versions:  Kalah v.2.0, Wari v.3.0, and 
Cross-Wari v.1.1 (look in the "History" section to see what 
version you are playing).

Please note that if you are using a "p" version of ZoG, you must 
upgrade to v.1.3p to play any of these Mancala games.

Please send any comments or bug reports to dtroyka@justice.com.  

You should extract the game from the downloaded zip file 
preserving path names. 

----------------------------------------------------------------
To play:

Double click the Cross-Kalah icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Cross-Kalah.zrf" in the Open dialog and click "Open"

Cross-Kalah.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 