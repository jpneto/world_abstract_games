Holmen
------
Created by Markus Salo, July 2003.


Win by moving a stone to the opposite home space to be promoted to a king 
and then move the king back to your home space. Both players have six pieces.
The White player starts from the left end of the board and can move his stones 
east, northeast and southeast and capture by replacement northeast and southeast.
A king moves to the opposite directions.
The Black player starts from the right end of the board and can move stones west, 
northwest and southwest and capture northwest and southwest and kings to the 
opposite directions. 
Captures are not mandatory. 
The player can either move a piece or drop a new one on his own home space.

This game is a variant of Tyska Torget on Hageby board and was
was inspired by W.D.Troyka's outstanding games Ugly Duck, Breakthrough and Zonesh.

Holmen is an island in the Motala River where the old and beautiful factories 
from the early industrial era were build in my beloved Norrk�ping, Sweden.


----------------------------------------------------------------
To play:

Double click the Holmen icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Holmen.zrf" in the Open dialog and click "Open"

Holmen.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

