Snailtrail v2.1
---------------
Invented and implemented by Don Green, June 2001.


Object: Be the last player to be able to complete a turn.

On each turn, players move a snail as far as it will go.  The trail 
of squares left by snails becomes unusuable for the rest of the game.  

The first player moves one square; the second moves two squares; and so on.  

Play continues until one player cannot complete a move. 


An original game by Don Green, reflecting his experience as a gardener.
Send comments and questions to octimon@yahoo.com


----------------------------------------------------------------
To play:

Double click the Snailtrail icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Snailtrail.zrf" in the Open dialog and click "Open"

Snailtrail.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
