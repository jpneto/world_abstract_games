Bivouac
-------
Invented and implemented by L. Lynn Smith, October 2002.
Updated October 12, 2002: added variant; squashed a few bugs.


Bivouac is played upon a 6x11 field.  The field is divided into three 
group of cells.  Two 4x4 groups of red cells called Encampments are 
seperated and surrounded by single ranks and files of green cells called 
the Run.  At the center of the Encampments are four marked cells called 
Goals, one set for White and the other Black.  Each player begins the 
game with their twelve tokens on the outer cells of the Encampment of 
the opponent's Goals.

Tokens enter and exit the Encampment by stepping to a vacant cell.

On the Run, Tokens may slide to any direct orthogonally adjacent cell 
which is vacant. They can jump any and all pieces on the Run.  No captures 
are performed on the Run.

In the Encampment, Tokens step to orthogonal or diagonal adjacent vacant 
cells.  Tokens may also capture within the Encampment by jumping an enemy 
Token, such jumps must be performed completely within the Encampment.  
A Token may perform multiple capture moves within a single turn.  Captures 
are not mandatory.

The game is won by the player who completely occupies his Goal cells, or 
reduces the opponent to three Tokens.


In the variant "Hostile Bivouac" the rules are the same except with mandatory 
and maximum captures.


----------------------------------------------------------------
To play:

Double click the Bivouac game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Bivouac.zrf" in the Open dialog and click "Open"

Bivouac.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

