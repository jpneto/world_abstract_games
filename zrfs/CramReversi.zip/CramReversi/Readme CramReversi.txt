----------------------------------------------
*** CramReversi v1.0                       ***
* *                                        * *
* * implemented by K. Franklin, July 2015  * *
* * e-mail address: frnklnk@yahoo.ca       * *
----------------------------------------------
*** Copyright 1998-2000 Zillions Development (v1.31)

You need to purchase Zillions of Games to load this rules file
Visit the Zillions web site at http://www.zillions-of-games.com
---------------------------------------------------------------

built upon Zillion v1.3's Reversi.zrf
SPECIAL NOTE: the Jello.dll engine has been left out. 

Object:
Standard Reversi, except that each cram square (i.e; a1/A1 to h8/H8) accepts two playing pieces.
When single disks are to be placed, they must initially form a sandwich in accordance with 
their side of the 'cram' squares.  All enemy disks that co-exist within those in-between 
cram squares will then be switched over.
Black and White alternate dropping single disks.  Each disk must be placed (directly aligned) 
so that it sandwiches one or more enemy pieces between itself and another friendly piece, with 
no empty half-squares intervening.  The sandwiched enemy pieces are flipped, changing colour.
If one player can't move, he must pass his turn.
The game ends when neither side can move, usually when the whole board
is filled.  The winner is the player with the most on-board pieces
of his colour.


You should have extracted this zip file preserving path names.
--------------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "CramReversi.zrf" in the Open dialog and click "Open"

CramReversi.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 



