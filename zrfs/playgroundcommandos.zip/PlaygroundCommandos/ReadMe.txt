Playground Commandos
--------------------
Invented and implemented by L. Lynn Smith, November 2001.


The local playground has become a warzone.  Those showy skateboarders 
have taken control of the central concrete square, forcing all the 
pogo-ers onto the grassy field.  Not the area of choice for quality pogo-ing.

As leader of the pogo-ers, the Attacker, you must 'Take Back The Quad' by 
occupying its four spaces with pogosticks.  As leader of the skateboarders, 
the Defender, you must 'Stomp the Hoppers' by keeping them off the Quad.

Trashcans are placed by each of the players at the start of play on any 
empty space.  There are six to be placed, the Attacker places one first 
then the Defender, in turns.  Trashcan cannot be moved or captured.

Pogosticks step to any adjacent orthogonal or diagonal space.  They also 
may jump over an adjacent orthogonal or diagonal occupied space.

Skateboards slide through any directly adjacent orthogonal space or steps 
to adjacent diagonal spaces.

The Attacker wins by either placing four Pogosticks upon the Quad, the four 
central spaces, or reducing the Defender's Skateboards to zero.

The Defender wins by reducing the Attacker's Pogosticks to three, which would 
effectively prevent the full occupation of the Quad.


Playground Commandos was invented by L. Lynn Smith for Abstract Games magazine's 
Second Game Design Competition.  The parameters of the contest was to construct 
a game of unequal forces on an 8x8 board.


----------------------------------------------------------------
To play:

Double click the PGC icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "PGC.zrf" in the Open dialog and click "Open"

PGC.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
