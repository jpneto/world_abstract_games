Fandango
--------
Invented and implemented by Chris Huntoon, January 2003.


Fandango is a combination of Fanorona and Gothic Checkers.

Object: Capture all your opponent's pieces (`Checkers` or `Kings`) or
stalemate the opponent so he has no moves.

The game uses the complementary methods of capture known as approach and withdrawal.  A
piece may capture by approach: after it moves, an enemy piece (or an unbroken string of enemy
pieces) adjacent to it along its line of movement are taken.  It may
instead capture by withdrawal: if it begins its move adjacent to an enemy
piece (or unbroken string) and moves directly away, the enemy piece(s) are
taken.
A piece that just captured may make another capturing move, though
it must change directions with every capture and it
may not immediately return to the point it just occupied. Capturing is
mandatory, and you must keep moving and capturing as long as it is possible.  If a 
given move offers both types of capture simultaneoulsy, only one of them may be taken. 
   
Checkers can move diagonally forward to an adjacent empty square.  They may
also capture an enemy piece (or a line of them) by approach or withdrawal 
in any of the five non-retreating directions (vertically, diagonally forward, or sideways.)
When your Checker stops on the other end of the board, it becomes a King and can then
also move backwards.  Kings move one square diagonally in any direction, but may capture along 
any horizontal, vertical, or diagonal line (eight possible directions.)  Kings may not move or 
capture at a distance, however;  they may only attack adjacent pieces.


Please note Fandango requires Zillions of Games v2 or higher.

----------------------------------------------------------------
To play:

Double click the Fandango icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Fandango.zrf" in the Open dialog and click "Open"

Fandango.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
