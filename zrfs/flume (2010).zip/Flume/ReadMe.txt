Flume
-----
Invented by Mark Steere (www.marksteeregames.com) in 2010.
Implemented by Luis Bola�os Mures, January 2012.


Flume is a close relative of Dots-n-Boxes which can be played with a Go board and stones.

The odd-sized square board starts out empty. Two players, Black and White, take turns placing stones of their own color on empty points of the board. If the stone you placed is orthogonally adjacent to one or zero empty points, you must place another stone while it is still your turn, and so on.

When the board fills up, whoever has the most stones on the board wins.


--------------------------------------------------------
To play:

Double click the Flume game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Flume.zrf" in the Open dialog and click "Open"

Flume.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com>