Cowboys
-------
Amazons invented by Walter Zamkauskas 1988, Cowboys created by Chris Huntoon 2003 


Cowboys is a variant of the territorial game Amazons. Note: The game has been updated to use boards with an odd number of spaces.  This is so Black can't force a win by using a simple mirroring strategy.
�
Red and the Black are having a gunfight.  Each turn consists of two parts, and both parts are mandatory. First, a Cowboy 
must ride his horse, moving a piece like a Chess Knight.  Then, the Cowboy who just moved uses his pistol to shoot a Bullethole into the board.  The Bullethole must be exactly a Knight's move away from its present position.  This will not only limit his opponent's moves, but also his own.  Once a space has been shot with a Bullethole it can not be landed on for the remainder of the game. 
�
There are no captures. The first player that cannot finish his turn, looses. 


----------------------------------------------------------------
To play:

Double click the Cowboys game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Cowboys.zrf" in the Open dialog and click "Open"

Cowboys.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

