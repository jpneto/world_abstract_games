************************************************
*** Jostle - Stay on the move!               ***
***                                          ***
*** Designed by Mark Steere.                 ***
*** Computer implementation by Greg Schmidt. ***
*** gschmidt958@yahoo.com                    ***
***                                          ***
*** Utilizes the Axiom Meta-Game System.     ***
*** Copyright 2010.  All rights reserved.    ***
************************************************

OBJECT: The last player able to move wins.  The players Red and Blue take turns moving checkers of their own color,
one move per turn, starting with Red.  Passing is not allowed.

FRIENDLY AND ENEMY CONNECTIONS: A connection is an orthogonal adjacency between two checkers.
A connection is `friendly` if the two checkers are the same color, and `enemy` if the two checkers are of
different colors.

CHECKER VALUE: The value of a checker is its number of friendly connections minus its number of enemy connections.

MOVE TO INCREASE VALUE: You can move a checker to any unoccupied orthogonally adjacent square, provided
that the moved checker increases in value (other checker values don't matter - just the checker being moved).

- Refer to the game rules PDF file for additional details.

- A free stand-alone version of Jostle may be downloaded from:
http://www.boardgamegeek.com/filepage/54279/jostle-axiom-pc-game