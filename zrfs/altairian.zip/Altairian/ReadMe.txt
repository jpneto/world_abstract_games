Altairian Checkers

(c) 2002  W. D. Troyka
dtroyka@justice.com

Updated March 23, 2002: improved piece valuation; added sound effects.


Altairian Checkers, recently decoded from SETI transmissions, is a 
checkers/draughts type game played on a radial hex board with four 
hexes to a side.  Each player starts with ten pieces called Pods 
arranged on opposite sides of the board.  

A Pod moves by orbiting a neighboring piece of either color, called 
the pivot.  A Pod can orbit around a pivot through any number of empty 
spaces or through outer space (off the board) provided it comes to rest 
on an empty space on the board.  It must land in a space adjacent to 
the pivot in the forward direction.  A Pod cannot capture.  

When a Pod reaches the shaded area on the far side of the board, it 
promotes to a War Pod.  A War Pod moves like a regular Pod, with the 
exception that it can land on any orbital space (i.e., forward progress 
is not required), and it captures any enemy piece that it orbits around.  

When a War Pod returns to the shaded area on its own side of the board, 
it promotes to a Death Pod.  A Death Pod moves like a War Pod, with the 
added condition that it captures any enemy piece that it lands next to.

Because pieces must have pivots to move, an isolated piece is frozen. 
The game is won by scattering the enemy fleet and leaving it with no 
move.  A player who has no pieces or no moves at the start of a turn 
loses.

Two training variants are included.  In the first, the object is to 
promote a Pod into a War Pod.  This variant focuses attention on the 
"civilian phase" of Altairain Checkers in which Pods maneuver for 
position without overtly hostile intent.  This phase is characterized 
by the tactics of stalemate and zugzwang.  In the second training 
variant, the object is to promote a War Pod into a Death Pod.  This 
variant adds the "battle" phase to the "civilian" phase and focuses 
attention on gaining the edge in battle through construction of an 
ultimate weapon.

Both of the training variants are virtually draw-proof.  Full 
Altairian Checkers usually draws when both players have an equal 
number of Death Pods and no other pieces.  This is a draw by mutually 
assured destruction.


----------------------------------------------------------------

To play:

Double click the Altairian game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Altairian.zrf" in the Open dialog and click "Open"

Altairian.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play 
any number of games against the computer or over the Internet. 
Zillions of Games can be purchased online.  For more information,
please visit the Zillions of Games website:

              <http://www.zillions-of-games.com> 
