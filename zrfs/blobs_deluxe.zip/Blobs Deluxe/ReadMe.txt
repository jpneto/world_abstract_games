Blobs Deluxe
------------
Scripting and graphics by Keith Carter 
Scoring system based on the work of the innovative Karl Scherer 
with some advice from W.D. Troyka and code streamlining by Ed van Zon. 


This version of Blobs allows the player to select from seven color 
coordinated sets of playing pieces. � Click on a piece to choose that 
color combination. � The top row of pieces gives the first player the 
lighter pieces. � The bottom row of pieces gives the first player the 
darker pieces. � To return to the selection screen choose the variant 
Back to Selection Screen. 

The object of the game is to have the most pieces on the board when 
the board is full. � There are three types of moves: 
1) � A piece can grow a new piece in an adjacent empty square.
   � All enemy pieces next to the new piece are converted to friendly pieces. 
2) � A piece can jump move two squares jumping over the intervening space.
   � All enemy pieces next to the square moved to are converted to friendly pieces. 
3) � If move types 1 & 2 are unavailable a piece may be dropped onto any 
     square on the board. � No enemy pieces are converted. � This is an additional 
     move to classic Blobs that helps prevent stalemates. 

There are other games published for Zillions in the Blobs family. � 
Blobz uses a grid with seven directions. � 
Hexxagon uses a hex field for six directions. � 
More distantly related is QuadWrangle which uses a sliding move. 


Please send comments and feedback to keith@tsongas.com 


----------------------------------------------------------------
To play:

Double click the SelectSet icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "SelectSet.zrf" in the Open dialog and click "Open"

Next choose one of the checkered tiles to start the preferred
Blobs game.

SelectSet.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
