Moray Eels

Dedicated to Thomas Rolle


"Moray Eels" contains elements from both the classical game "Fox and Dogs" and from the Zillions Classic "Blobs". On a board of size 7x5 six Octopussies are fighting against two
Moray Eels. The Octopussies can move forward only, whereas the Morays can also sidestep
or even swim backwards. After a move of any piece all enemies in the 8-neighbourhood of the destination change side. The game ends when one side has lost all its pieces. In the rules one little present is included for the Octopussies: they are winners when stalemated with own pieces remaining on the opponent's back rank.

Moray Eels are very patient hunters, but when they start an infight there is no hesitation. In the game, humans have almost no chance against the Zillions engine with its strong tactical play. Nevertheless you should give it a try, simply to see (and enjoy ?!) the contrast between Morays patient lurking and his speedy biting. You may also let play Zillions against itself and watch the spectacle. At long thinking times both sides should have about equal chances.

Four variants with material handicap are included to give human players a chance against the machine.


"Moray Eels" was invented by Ingo Althofer in May 2003, and tuned with the help of Thomas Rolle's new game design program "Morphling". Contact: althofer@minet.uni-jena.de
