Killer Amazons

Amazons is a game of territory.

A turn consists of two parts which are both compulsory:
First, an Amazon must be moved like a Chess Queen. Then, 
this Amazon 'shoots an arrow' to a square another Queen's 
move away. The square chosen is thus blocked for the 
remainder of the game, meaning it can be crossed neither 
by Amazons nor Arrows.

There are no captures in Amazons. A player loses if he 
is unable to make a move.

Zillions is playing the game Amazons rather poorly. The 
current variant 'Killer Amazons' was designed to overcome 
this problem at least partially. In 'Killer Amazons' an 
Amazon is allowed to capture any other Amazon be it 
friendly or an enemy. The loss-condition remains the same 
as in Amazons.


Amazons was invented in 1988 by Walter Zamkauskas from Argentina.
Killer-Amazons is a variant by Ingo Althofer, January 2003.
This realisation for Zillions is based on the Amazons.zrf by Jens Markmann.

Contact: althofer@t-online.de
