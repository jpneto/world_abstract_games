Extreme Checkers
-------------------------------------------------------------
Invented and Implemented by Peter Aronson, April 2000.
-------------------------------------------------------------
Extreme Checkers is like playing two games of
Anglo-American Checkers (Draughts) at the same
time, with War Variant Hasami Shogi-style 
custodian capture in addition capture by jump.

Object: Capture all your opponent's men 
("Checkers") on either the black or the red 
squares by jumping over them or sandwiching 
them, or stalemate the opponent so they has no
moves.

Checkers can only move diagonally 
forward, either by sliding to an adjacent empty
square or by jumping over an enemy piece to a
vacant square on the other side.  Jumping over a
piece captures it.   Capturing by jump is
mandatory, and you must keep jumping and 
capturing as long as it is possible.  Capture by
sandwiching is automatic, but you are not 
required to move so as to capture this way.  
Men are captured by sandwiching when an opposing
piece moves to one end of a column or row of
opposing men, and a  friendly piece is at the
other end.  Sandwich captures at the edge of the
board may wrap around corners.

When your Checker reaches the other end of the
board, it becomes a King and can then also move
and capture diagonally backwards.
-------------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Extreme Checkers" folder in the Open dialog and click 
   "Open"
4. Select "Extreme Checkers.zrf" in the Open dialog and click "Open"
-------------------------------------------------------------------
"Extreme Checkers.zrf" is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
-------------------------------------------------------------------
