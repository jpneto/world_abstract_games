Latrunculi
----------
Implemented by L. Lynn Smith, July 2001.
Updated August 6, 2004: significant re-write; now honors the rules as proposed by Dr. Schaedler.


Latrunculi, or Ludus Latrunculorum, is an ancient board game of the Roman Empire.  There are few records with the rules of this game, most are scant references, such as in the poetry of Ovid.  This version attempts to utilize the rules as described by Dr. Ulrich Schaedler in Abstract Games Magazine #7.

The field is an 8x8 grid.  Each player start with 24 identical Ordinarii, or "regulars", Gold or Silver.

The game begins with each player placing all their Ordinarii, in alternating turns. The Gold player is the first to place.  Placements are to any vacant cell.  No Alligati or "slaves" may be formed on the playing field until after all Ordinarii have been placed.  Alligati are only created by a moving piece.  During this phase the Ordinarii are commonly referred to as Vagi, or "wanderers".

After all the Ordinarii are placed upon the field, the players take turns either moving an Ordinarius or capturing an Alligatus.

Ordinarii are moved orthogonally to any vacant adjacent cell or they may orthogonally jump any Ordinarius or Alligatus to a vacant cell.  Several jumps in a single turn are possible, like in Draughts or Checkers.

An Ordinarius which is subsequently 'trapped' between two opposing Ordinarii becomes an Alligatus.  Such Alligati cannot be moved.  An Alligatus may be captured, removed from play, as a turn.

An Alligatus can be freed, if one of its two opposing Ordinarii becomes an Alligatus or moves away.  As long as an Alligatus is flanked by two opposing Ordinarii, it will remain an Alligatus.

A player can only move an Ordinarius between two opposing Ordinarii if this move causes one of these to become an Alligatus.

The first player to be reduced to only one Ordinarius or Alligatus loses the game.  Since this would logically prevent the player from creating any further Alligatus.  When a stalemate occurs, the player with the most pieces on the field wins.  After the placing phase, if there are forty consecutive turns without the removal of any Alligati from the field the player with the most pieces on the field wins.  All of the player's pieces on the field, Ordinarii and Alligati, are considered in these counts.  Three-time repetition of position is considered a loss.

So, place your Legion carefully.

'Hail, Caesar.  We, who are to die, salute you'


Latrunculi is an ancient board game of the Roman Empire.  Special Thanks to Dr. Ulrich Schaedler for the interpretation of these rules.

This is a work in progress, please forgive any problems with the rules and their implementation within this program.  Constructive feedback desired.

Zillions implementation by L. Lynn Smith

----------------------------------------------------------------
To play:

Double click the Latrunculi icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Latrunculi.zrf" in the Open dialog and click "Open"

Latrunculi.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
