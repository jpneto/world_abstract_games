Sortie (version 1.0)
--------------------
A two player strategy game conceived of and implemented by Greg Schmidt, May 2005.
Please send comments and suggestions to gschmidt958@yahoo.com

Credits:
The crash image was derived, with permission, from an image provided by "InetDaemon".
<http://www.inetdaemon.com>

Mission Objective:

  Safely land one of your squadron's aircraft on the opposing airstrip
  after penetrating enemy forces.
  - or -
  Block all enemy planes from flying.


Mission Briefing:

  - Each plane can fly in one of three directions (north, northeast, northwest).

  - A plane can also crash into an enemy plane causing both aircraft to explode.
    The explosion produces a debris field which cannot be flown into."

The following variants change the aircraft formations.

Sortie #2
Sortie #3
Sortie #4

Try turning on the "sounds" option.
----------------------------------------------------------------
This game requires the "Zillions of Games" program.  Please
visit <http://www.zillions-of-games.com> for details.
----------------------------------------------------------------
