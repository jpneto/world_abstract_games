//	required Javascript functions 
//	to be included in any page who want to write_displaytoggle_button

//	unfortunately, it can't be in an included .js, because the page itself can't wait for that to load (it calls write_displaytoggle_button)
//	so I put this into the submissionsWrapper page

	// **** helpers to toggle the display of some <div id="..."> ****
	//	unfortunately, we can't put it in an included .js, because the page itself can't wait for that to load
	
	//	btw, it's coded here because part of it _must_ be JavaScript, and now it doesn't depend on the caller
	//	well, almost, we do rely on one environment var though
	var picslocation = '/zilligames/pics/system/';
	
	function view_buttonimages()
	{	//	constructor
		this.hidden = new Image();
		this.hidden.src = picslocation + "display_none.gif";	 	// visibility_hidden.gif doesn't exist yet
		this.hidden.alt = "Show ";
		this.hidden.title = this.hidden.alt;
		
		this.visible = new Image(); 
		this.visible.src = picslocation + "display_inline.gif";		// visibility_visible.gif doesn't exist yet
		this.visible.alt = "Hide ";
		this.visible.title = this.visible.alt;
	
		this.none = new Image(); 
		this.none.src = picslocation + "display_none.gif";
		this.none.alt = "Show ";
		this.none.title = this.none.alt;
		
		this.inline = new Image(); 
		this.inline.src = picslocation + "display_inline.gif";
		this.inline.alt = "Hide ";
		this.inline.title = this.inline.alt;
	}
	 
	//	create & preload visibility and display button images
	var view_buttonimgs = new view_buttonimages();
	
	function toggle_visibility( elemid)
	{	set_visibility( elemid, get_visibility_state( elemid) == 'hidden' ? 'visible' : 'hidden');
	}

	function set_visibility( elemid, state)		//	state must be 'hidden' or 'visible'
	{	document.getElementById(elemid).style.visibility = state;
		set_viewbutton( elemid, state);
	}
	
	function toggle_display( elemid)
	{	set_display( elemid, get_display_state( elemid) == 'none' ? 'inline' : 'none');
	}
	
	function set_display( elemid, state)		//	state must be 'none' or 'inline'
	{	document.getElementById(elemid).style.display = state;
		set_viewbutton( elemid, state);
	}
	
	//	let the button reflect the state
	function set_viewbutton( elemid, state)		//	state must be 'hidden', 'visible', 'none' or 'inline'
	{	document[ elemid + "_btnimg"].src = view_buttonimgs[ state].src;
		document[ elemid + "_btnimg"].alt = view_buttonimgs[ state].alt + firstpart( elemid);
		document[ elemid + "_btnimg"].title = view_buttonimgs[ state].title + firstpart( elemid);
	}
	
	
	//	expand/collapse all button
	//	elemid is for the 'all' button, that must be associated with a div element too (could be a dummy)
	//	id_list is a variable number of arguments specifying the div id's that belong to the 'all' collection
	function toggle_all_display( elemid /*, id_list */ )
	{	var new_state = get_display_state( elemid) == 'none' ? 'inline' : 'none';
		//	iterate through the argument list, skipping the first
		for (var i = 1 ; i < toggle_all_display.arguments.length ; i++)
		{	set_display( toggle_all_display.arguments[i], new_state);
		}
		set_display( elemid, new_state);		//	set the 'all' button and div
	}
	
	
	//	write the html to show the toggle button <a ...><img ...> tags
	//	'elemid' is (part of) img name and div id to toggle
	//		btw, it's coded here because part of it _must_ be JavaScript, and now it doesn't depend on the caller

	//	this is the easy to use display toggle, implemented in javascript
	function write_displaytoggle_button( elemid, initial_state)
	{	write_toggle_button( elemid, initial_state, "javascript:toggle_display( '" + elemid + "')");	// reverse quoting! ...
	}

	//	this allows for specifying a custom url to do the toggle
	function write_toggle_button( elemid, initial_state, url)
	{	document.writeln(	'<a href="' + url + '"'														// ... compared to this.
						,	' onMouseOver="return write_status(\'Toggle ' + firstpart( elemid) + ' display\')" onMouseOut="return blank_status()">'
						,	'<img name="' + elemid + '_btnimg" '
						,	' src="' + view_buttonimgs[ initial_state].src + '"'
						,	' alt="' + view_buttonimgs[ initial_state].alt + firstpart( elemid) + '"'
						,	' title="' + view_buttonimgs[ initial_state].title + firstpart( elemid) + '"'
						,	' border=0 width=16 height=16 align="absmiddle">'
						, '</a>'
						);
	}

	//	this is the easy to use display toggle all, implemented in javascript
	//	collection must be a comma-separated string of QUOTED (!) div id's, belonging to the 'all' set
	function write_displaytoggleall_button( elemid, initial_state, collection)
	{	write_toggle_button( elemid, initial_state, "javascript:toggle_all_display( '" + elemid + "', " + collection + ")");	// reverse quoting! ...
	}
	
	function write_nodisplaytoggle_img()
	{	document.writeln( '<img src="' + picslocation + 'display_leaf.gif"'
						, ' alt="No display toggle possible"'
						, ' title="No display toggle possible"'
						, ' border=0 width=16 height=16 align="absmiddle">'
						);
	}
	
	function write_spacer_img()
	{	document.writeln( '<img src="' + picslocation + 'display_spacer.gif"'
						, ' alt=""'
						, ' border=0 width=16 height=16 align="absmiddle">'
						);
	}
	
	//	removes the first part of str - parts are separated by ';;'
	//	this is to allow for a unique elemid, but the same helptip for different toggle buttons
	function firstpart( str)
	{	return str.split( ';;')[0];		//	strangely enough, even if a single ';' is used here, str must still contain ';;'
	}
	
	//	return the display state of elemid 
	function get_visibility_state( elemid)
	{	return document.getElementById(elemid).style.visibility;
	}
	
	//	return the display state of elemid 
	function get_display_state( elemid)
	{	return document.getElementById(elemid).style.display;
	}

	
	// **** end of helpers to toggle the display ****

	
	//	if extended search isn't displayed, set containing form elements to the default ''.
	//	elemid is the div that holds the extended search parts
	//	thisform is the form the fields belong to
	//	field_list is a variable number of arguments specifying the field names that are contained by the extended search
	function checkextendedsearch( elemid, thisform /*, field_list */ )
	{	var formelem;
	
		if (get_display_state( elemid) == 'none')	//	extended search is hidden
		{	//	iterate through the argument list, skipping the first two
			for (var i = 2 ; i < checkextendedsearch.arguments.length ; i++)
			{	formelem = thisform[ checkextendedsearch.arguments[i]];
				if (formelem.type == 'select-one')
					formelem.selectedIndex = 0;			//	setting the value doesn't work in Safari (!?), so we assume the top choice is the default
				else
					formelem.value = '';
			}
		}
		return false;	//	always return true - this could be called onSubmit
	}

	
	//	form.submit() won't call the form's onSubmit handler, so we need to call that ourselves
	//	use this instead of directly calling a form's submit() method, when it has an onSubmit handler
	function mysubmit( aform)
	{	var onsub = aform.onsubmit();		//	call onSubmit handler
		if (typeof( onsub) == "undefined"	//	no "show stopping" onSubmit handler present, e.g. it isn't "return ..."
			|| onsub)						//	"show stopping" handler returning true, so go ahead
			aform.submit();
	}


	// sets the status line
	function write_status( foo) 
	{	window.status = foo;
		return true;
	}
	
	// clears the status line -- leftover go away
	function blank_status() 
	{	return write_status( "");
	}


	function writeContact( niamod, eman, sserdda)
	//	writes out the obfuscated m-a-i-l-t-o tags; really usefull when niamod and sserdda are encoded
	{
		var driht = 'to:';
		var tsrif = 'ma';
		var dnoces = 'il';
		document.write('<a href="');
		document.write(tsrif+dnoces+driht);
		document.write(sserdda);
		document.write('&#64;');
		document.write(niamod);
		document.write('">');
		document.write(eman+'<\/a>');
	
	}	//	writeContact
