-----------------------------------------------
*** DOMINION  (v1.1)*                       ***
* *                                         * *
* * implemented by K. Franklin, Apr. 2004   * *
* * e-mail address: kenf@ica.net            * *
* *                                         * *
-----------------------------------------------
Copyright 1998-2000 Zillions Development (v1.31)

You need to purchase Zillions of Games to load this rules file
Visit the Zillions web site at http://www.zillions-of-games.com
---------------------------------------------------------------
*Upper Variant's layout, updated Jun 2004

A 'confederation' of Blobs with Reversi.
The variants have been co-named for some of the various regions of Canada.


Object: Capture all of your opponent's stones.

You can drop a new piece on any position next to one of your pieces, or you
can `jump` an existing piece by moving it two squares in any direction(s).

1)  All opposing pieces in the eight squares adjacent to where your stone
    lands change colour to become your pieces.
2)  Additionally, all enemy pieces sandwiched between the newly placed
    stone and another friendly stone will be flipped.

-------------------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Dominion.zrf" in the Open dialog and click "Open"

Dominion.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

