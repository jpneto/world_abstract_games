Hippolyta
---------
Created by Chris Huntoon, June 2009

Two tribes of Amazons are warring with each other.  An Amazon shoots her bow in a straight
line in any direction.  Captures are made at any distance, from point blank to across the
board. The piece making the capture does not move. Click on the target piece to capture.

On each turn, an enemy piece must be captured.  Shifting a piece to another space is not
allowed.  The last player able to shoot is the winner.

----------------------------------------------------------------
To play:

Double click the Hippolyta game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Hippolyta.zrf" in the Open dialog and click 
   "Open"

Hippolyta.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 