Cats & Dogs
-----------
Created by Chris Huntoon, December 2001.


One player represents the Cats, the other, the Dogs.
 
The board starts off empty and the two players take turns to place 
one of their pieces on an empty space on the board. Cats and Dogs 
are natural enemies and may not be placed next to one another, i.e. 
the may not be placed in adjacent squares that share the same edge. 
Diagonally adjacent is fine. 
�
In the regular game, the first play who can not make a move loses; 
in the losing game he wins. 

The Top Cat - Top Dog variant is a more challenging version of the regular game.  It is played on a slightly larger board, with an odd number of spaces.  It includes an additional rule that the first player may not start the game by placing a piece in the center square, marked with the tree. After the initial move, the center square can be claimed by either side.

----------------------------------------------------------------
To play:

Double click the Cats&Dogs icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Cats&Dogs.zrf" in the Open dialog and click "Open"

Cats&Dogs.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
