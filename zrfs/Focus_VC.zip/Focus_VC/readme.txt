Focus (c) 1963 Sid Sackson
--------------------------

Zillions og Games 2.0 required
4 variants

Object: The player that is unable to make a valid move, loses.

On each turn, each player must do one of the following actions: 

- Moves one of his stacks on any orthogonal direction, exactly the 
  same of cells as its size, possibly landing over another stack. 
  If, after landing, the final stack size is greater than 5, all 
  stones in excess of 5 are removed from the bottom of the stack. 
  Enemy stones are removed, while friendly stones go to the player's 
  reserve.

- Use one of his reserve stones and place it on any cell (occupied or not). 

See Also: http://www.di.fc.ul.pt/~jpn/gv/focus.htm
Video: http://www.youtube.com/watch?v=7cz8B2Zu-Qs
