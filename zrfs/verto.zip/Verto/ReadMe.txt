VERTO v1.2
----------
Updated January 7, 2012:
	- bug corrected
	- improved mechanism for entering capturing moves


Verto was invented by Dieter Stein (http://spielstein.com) in January, 2011. In December, 2010, a previous version of the game (Old Verto) was entered in a contest held at the abstract games group Recre.Games.Combinatorial.

Zillions implementation by Luis Bola�os Mures.


Objective

End up with the majority of stones on the filled board.

Preparation

The suggested board is an 8x8 or 9x9 square grid. In the beginning the board is empty and the stones are put in reach for both players. The players choose their colors. Light makes the first move, then players take turns.

Play

In each turn a player must try to enter a stone (with his own color facing up) on an empty space. If a stone is placed such that exactly one opponent stone is orthogonally or diagonally between the entered stone and another friendly stone, then this opponent stone is flipped and becomes a friendly stone. This is called a capture. Now the entered stone must be used as the starting point to capture another opponent stone and so on until no further capture is available. Capturing is not mandatory, but if a capture move is made, any capture moves which follow must be made, too. It is not necessary to always follow the path where a maximum of captures is possible. A capture move is similar to a capture move in Checkers. It is like jumping over one opponent stone, but here no stone is moved and a captured stone is not removed (it is flipped instead). Instead of capturing, a player can enter a single stone on an arbitrary empty space. However, it is not allowed to enter a stone (orthogonally or diagonally) next to a friendly stone if there isn�t also an opponent stone adjacent to that new stone. Lastly, stones may only be entered on corner spaces if there is another (opponent) stone (orthogonally or diagonally) adjacent. If a player cannot make a capture and cannot enter a stone, he must pass. The other player will always have a move available.

End of the Game

The game ends when the board is completely filled. The player with the majority of stones wins. The game on an 8�8 board may end in a draw. It can be played on a 9�9 board (with 81 stones) if players have an aversion to draws.

--------------------------------------------------------
To play:

Double click the Verto game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Verto.zrf" in the Open dialog and click "Open"

Verto.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com>