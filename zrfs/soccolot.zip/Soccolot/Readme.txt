
*** Speed Soccolot
-------------------------------------------------------------------
***** Requires Zillions version 1.3 or higher to play. *****
-------------------------------------------------------------------
Speed Soccolot is a variant of David Wilson's original Soccolot game of 1972.
Implemented by Bob Kraus for Zillions of Games in 2003
-------------------------------------------------------------------
Speed Soccolot differs from the original game only in board size and starting lineup, 
in an attempt to speed up the start and shorten the length of the game. 
David Wilson's original Soccolot game is included as a variant.
---------------------------------------------------------------------------------------------------------
Two players, White and Black, each have five Men which start on their respective 
second ranks of an 7x7 checkerboard. There is also one neutral Ball in the center of 
the board. Each turn a player may make one of three types of moves:  Run, Dribble, or Kick.
Run: player moves a Man to any empty adjacent square. (Adjacent means orthogonal or diagonal.)
Dribble: if player has a Man adjacent to the Ball, both the Man and Ball move one square 
in the same (parallel) direction, provided both squares are empty. (Move the Man and Zillions 
will give you the option of moving the Man only or the Man and the Ball together.)	 
Kick: if player has a Man adjacent to the Ball, he may move the Ball in the direction away from 
the Man, through any number of empty squares, stopping on any empty square. (Move the Ball.) 
A player wins the game when the Ball lands on any square in is opponent's home row (last rank)."
-------------------------------------------------------------------
You should have extracted this zip file preserving path names,
(Check "Use Folder Names" box in Win-Zip Extract Files Dialog Box);
and you should extract to your Zillions Rules folder.This will
create a Soccolot folder within the Rules folder.
-------------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Soccolot" folder in the Open dialog and click "Open"
4. Select "Soccolot.zrf" in the Open dialog and click "Open"
-------------------------------------------------------------------
Soccolot.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
-------------------------------------------------------------------
