Nubia
---
Created by Chris Huntoon, April 2009

A Counter can slide any number of squares along a row or column, like a Rook.  A Counter
captures by withdrawal.  That is, if the Counter begins adjacent to an enemy piece and 
then moves in a straight line directly away from it, the enemy piece is captured.

The object is to be the first to move a piece into the enemy's camp, located in your 
oppenent's corner square.

----------------------------------------------------------------
To play:

Double click the Nubia game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Nubia.zrf" in the Open dialog and click "Open"

Nubia.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 