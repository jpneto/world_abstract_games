Rotaryh
-------
Invented by Nagy L�szl�, 
implemented by Karl Scherer, November 2000.
Updated December 16, 2001: improved graphics.

Object: fill the centre with three of your marbles.
You start with Red.

First select one of the numbers 1 to 5.
These indicate how much you will rotate a hexagonal ring.
Now click any board position to rotate the surrounding marbles 
clockwise.
The position does not have to contain a marble, but you can only 
rotate rings where you have the MAJORITY of marbles, i.e. the 
ring must contain more of your marbles than of your opponent's.

You cannot move marbles outside the board.

SHORTCUT:
If you are happy with the selection, you may skip the selection 
of a number and just doubleclick a board position to execute the 
intended rotational move.


More related freeware as well as real puzzles and games see 
my home page  http://karl.kiwi.gen.nz .


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Rotaryh.zrf" in the Open dialog and click "Open"

Rotaryh.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

