Thataway v2.0

(c) 2000  W. D. Troyka

Updated October 6, 2001: v2.


Object:  Capture all three of your opponent's Pods.
	
Pods move one orthogonal space.  Alternatively, a Pod may
be exchanged for a previously captured Star.

Pointers move any number of empty spaces in the directions 
they point.  Alternatively, a Pointer may be rotated to point 
in two new directions.

Crosses move in the directions they point.  Alternatively, a 
Cross may be rotated to point in four new directions.  A Cross 
moves like a Bishop or Rook, depending on which way it is rotated.

A Star moves in all eight directions, exactly like a Queen.


You should extract the game from the downloaded zip file 
preserving path names. 


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Thataway.zrf" in the Open dialog and click "Open"

Thataway.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
