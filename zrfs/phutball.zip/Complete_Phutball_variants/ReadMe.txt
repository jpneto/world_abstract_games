Game
Complete Phutball(Philosopher's Football) variants
Implemented by Namik Zade, 2026-03-30
Matthew Burke implemented Phutball from which this zrf is derived.

•	description "OBJECT: Move the football to or past your goal line (the first player's goal is at the top). On each turn you may either place a man or move the football. The football jumps lines of adjacent men which are then removed from the board. If after jumping a line of men, the football lands next to another line of men, it may jump them as well, however this is not mandatory. Gameplay: Players (coaches) take turns placing black stones on intersections to represent players.
•	Movement: The ball moves by "jumping" over a line of adjacent black stones (similar to checkers).
•	Goal: Moving the ball into the opponent's "goal" (the end of the board).
•	Complexity: The game is complex enough that determining a winning move is NP-complete, according to researchers
" History: "Philosopher's Football (aka Phutball) was invented by John Conway and is described in 'Winning Ways for Your Mathematical Plays'. I wouldn't recommend playing against the computer (unless you're easily amused), but Zillions does make it easy to play against another person. This Zillions file was implemented by Matthew Burke. Adapted to the 19x19 hex board Namik Zade."
In these 5 variants are added.
1.	Phutball(Philosopher's Football)-15x21
2.	One-dimensional variant
3.	Win-zone reduced
4.	Restricted area
5.	Hex board 19x19(bag fixed)
6.	Hex board 19x19(win-zone reduced)

