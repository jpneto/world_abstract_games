HexGo is a two-player territorial game using black and white pieces
placed by each player in turn on the intersections of lines making
up a triangular grid. The Zillions game rules file HexGo.zrf
includes 8 variants with board sizes ranging fron 5 to 19 points
across. Game logic is similar to traditional Go: previously-played
pieces are removed from the board when the last empty point that
they connect to is taken by an opponent's piece. When the last
piece is played, or there are no legal moves, or both players
pass in turn, the game ends. The winner is the player with the
most pieces remaining on the board.
	
Try to play each piece so that it not only expands your territory
but can also easily connect to unoccupied points, usually via your
other pieces. Although HexGo is based on traditional Go, most of
the points on the board have 6 neighbors rather than 4, making
connections easier and captures harder than in traditional Go.

Based on Go.zrf written by L. Lynn Smith (permissions requested)

HexGo mods by Bob Henderson

-------------------------------------------------------------------

The downloaded file "HexGo.zip" should be unzipped in the directory
where you keep your other Zillions game rule files. This will add a
"HexGo" directory with the game rules file "HexGo.zrf," this ReadMe
file, and subdirectories containing the graphics files, etc. used
by the rules file.

To play:

Double click the HexGo icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "HexGo.zrf" in the Open dialog and click "Open"

HexGo.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
