-----------------------------------------------
*** SABOTAGE  (v1.0)                        ***
* *                                         * *
* * implemented by K. Franklin, Jun. 2004   * *
* * e-mail address: kenf@ica.net            * *
-----------------------------------------------
Copyright 1998-2000 Zillions Development (v1.31)

You need to purchase Zillions of Games to load this rules file
Visit the Zillions web site at http://www.zillions-of-games.com
---------------------------------------------------------------

SABOTAGE, 'the game where uncertainty reigns', was a classic Lakeside game
sold by Leisure Dynamics, Inc. in 1985.  The additional variants here are
newly supplied, along with identifying the majority of pieces as 'Subjects'. 


Object: Bring the Crown to your home square (B5 or L5 - as drawn).
------------------------------------------------------------------
1)  Playing pieces can be moved in a straight-line forward, backward,
sideways and/or diagonally, except (*) when a piece has captured the Crown
it doesn't move diagonally.

2)  When moving: the number of spaces a piece MUST move is equal to the total
number of Red AND Blue playing pieces residing on the vertical plane of the
piece to be moved.

3)  Number indicators are available just below the visible game board by
expanding the Zillions' window.  There is no jumping in Sabotage.

4) If a move lands on a square occupied by an opponent, the opponent's Subject
is captured and removed.  You capture the Crown by landing on it.  In the
opening it is a non-active neutral piece.  When an opponent owns it, the Crown
is taken over when captured; the opponent's Subject piece is still removed.

*) In the revised variants, the Crown's movements are unrestricted.
------------------------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Sabotage.zrf" in the Open dialog and click "Open"

Sabotage.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
