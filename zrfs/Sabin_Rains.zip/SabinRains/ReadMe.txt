Sabin Rains

(c) 2001  W. D. Troyka
dtroyka@justice.com


Sabin Rains is a flipping game played on a hex board, in which the 
flipping occurs along `hex rings.`  A hex ring is the ring of six 
spaces surrounding any one space on the board.  The specific rules 
are:
		
Take turns placing pieces on the board.  A piece may not be placed 
in a space that is surrounded on all sides (the "plug rule").  When 
a piece is placed, it flips all enemy pieces that are sandwiched 
between itself and a friendly piece along a hex ring.  When five 
enemy pieces are located on a hex ring, a single piece dropped in 
the remaining space will flip all five pieces.
	
The player with the most pieces on the board when there are no 
further moves is the winner.  In the illustration below, blue has 
won because there are no further moves and blue has the most pieces 
on the board. 

Sabin Rains comes in two board sizes, one with five hexes to a side, 
the other with six.

You should extract the game from the downloaded zip file 
preserving path names. 

----------------------------------------------------------------
To play:

Double click the Sabin Rains icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "SabinRains.zrf" in the Open dialog and click "Open"

SabinRains.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 