The Royal Game of Zonesh
(c) 2001  W. D. Troyka
dtroyka@justice.com


Win by moving a piece to the opposite corner.  Pieces move one 
space in any direction except that a piece in its home zone 
(shaded) cannot move diagonally.

Oddly enough, Zonesh was conceived as a 2D variant of the 5D 
game Skava.  The rules are the same except for the ability of 
pieces in Zonesh to move diagonally once outside of their home 
zones.  This rule compensates for the reduced freedom of a 2D
board and makes draws virtually impossible. 

Zonesh, along with Skava, Breakthrough, and Sidewinder, 
belongs to a limited class of attainment games characterized 
by undifferentiated pieces.  Declaring a win-zone on a board 
permits an extraordinary simplification of rules without loss 
of depth.  

Zonesh comes in 5x5 and 6x6 versions.

Please note that Heaven & Hell Chess has just been updated 
to add new variants, and a minor bug in Susan has been 
corrected.

----------------------------------------------------------------
To play:

Double click the Zonesh icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Zonesh.zrf" in the Open dialog and click "Open"

Zonesh.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 