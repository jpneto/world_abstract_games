Euclid
------
Created by Chris Huntoon, February 2003.


Object:  reduce your opponent to two or less pieces.  
Euclid uses the coordination method of capture from Ultima. 
�
A King moves like a Chess Queen, sliding any number of squares in 
any direction.  A King can not make any captures when it moves nor 
can a King be captured. 
�
A Man moves like a Rook,  sliding any number of squares in any 
orthogonal direction.  When it finishes a move, it captures any 
enemy Man on an intersection of the orthogonal lines that pass 
through the Man and through the friendly King.  Imagine the rectangle 
formed on the board by the Man and the King of the same side; the 
captured pieces are on the rectangle's other two corners.  It can 
therefore capture two at once. 


----------------------------------------------------------------
To play:

Double click the Euclid game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Euclid.zrf" in the Open dialog and click "Open"

Euclid.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

