Huntsmen
--------
Invented and implemented by Jeff Roy, July 2000.
Updated September 8, 2001: added variants; new graphics.


In this game, capturing your opponent's pieces makes their remaining 
pieces more powerful.

Each player begins with four pieces.  On his move, a player may move 
one of his pieces n spaces, where n varies depending on the number of 
pieces she has remaining:

Four pieces remaining:  one space per turn
Three pieces remaining:  two spaces per turn
Two pieces remaining:  three spaces per turn
One piece remaining:  four spaces per turn.

A piece may capture an opposing piece by moving onto it.  If a piece 
makes a capture before it has used all of the spaces available to it 
that move, it may continue to make additional captures until it has 
moved its limit.  A piece may move over intervening pieces.
The player who captures all of his opponent's pieces wins.


In the Ist variant, a piece may move n spaces in any combination of 
diagonal or orthogonal directions.

In the IInd variant, pieces may move n spaces in any combination of 
orthogonal directions.

In the hex variant, pieces may move n spaces in any combination of 
hexagonal directions.

The three variants above each have a 'free' variation, in which your 
pieces start off the board.  Each turn a player may either place a 
piece or move a piece that is already on the board.


Remember that when your opponent has been reduced to one piece 
that piece will be very powerful.  Therefore, it is safe to 
capture your opponent's last piece only in particular types of 
positions.  Learn to recognize and play for these positions.


This zip file must be extracted preserving path names.

----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Huntsmen.zrf" in the Open dialog and click "Open"

Huntsmen.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

