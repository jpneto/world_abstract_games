Domina v2.1
-----------
Invented and implemented by Karl Scherer, September 2001.
Updated August 11, 2007: 
		- game text corrected


Object: Reach the opposite border before your opponent does.
(8 variants)

Click a Domino to rotate it ninety degrees clockwise.
If this is not possible because the target square is not empty,
then the Domino will rotate 180 degrees.
If this is not possible because the target square is not empty,
then the Domino will rotate 270 degrees.

Note that these rules do not give you a choice how much the Domino will be rotated.
But you can steer it by choosing carefully which end of the Domino you click.

There is one exception (forward-rule) :
  - If your Domino is above the first three ranks and
  - if it would return to a lower rank after a rotation,
    then the Domino cannot be moved at all.

There is no capturing in this game.
You win if you reach the opposite border with one of your Dominoes
or if you stalemate your opponent.
Repetition is a loss.

Players usually play two games, alternating playing Gold and Turquoise.
If both players win one game each, then the player which used the least moves
to win his game is declared the winner.

If you play against the computer, try to win in as few moves as possible.

Variants 2,3 have different board setups.
Variants 4,5,6 : using the 8x8 board


More freeware and real puzzles and games at my homepage: karl.kiwi.gen.nz .


----------------------------------------------------------------
To play:

Double click the Domina icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Domina.zrf" in the Open dialog and click "Open"

Domina.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
