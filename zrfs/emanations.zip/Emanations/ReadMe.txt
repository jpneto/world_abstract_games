*********************************************************************
*** Emanations V1.1                                               ***
***                                                               ***
*** Implemented by Greg Schmidt, Copyright (c) 2008.              ***
*** All rights reserved.                                          ***
*** Please send comments and suggestions to gschmidt958@yahoo.com ***
*********************************************************************

Invented by Ludvig Schmidt, (Kisug�roz) circa 1864.
Modern interpretation and realization in the form of "Emanations" by Greg Schmidt.
Copyright 2008.  All rights reserved.

Emanations - Link your stones to gain points.

The object of the game is to gain the most points by forming links between your stones.
Players take turns placing a stone.  If the stone can be linked to any other friendly stone(s)
in one of the eight directions (north, south, east, west, northeast, northwest, southeast,
southwest), then a line of friendly pebbles is placed on all spaces along the paths connecting
the stones.  A connection cannot be made if an enemy stone lies along the path to the friendly
stone.

The score indicators display the number of pebbles owned by each player.  The game
ends when there are no remaining moves.  The player with the most pebbles wins.

HISTORY:
In 1892, my great grandfather Sandor Schmidt emigrated from Budapest to America.
The reason for his departure is unclear, although a family inheritance may have
played a role in his exile.  On his journey he brought with him nine steam trunks.
One of the trunks included posessions he had inherited from his father, Ludvig Schmidt.
Ludvig had been a Feldmarschall-Leutenant (Major General) in the Austro-Hungarian
army.  Among the possessions were many papers, most of which were written on official
government stationery.  Ludvig must have been an extraordinary man, judging by the
breadth of his knowledge and variety of interests clearly evident in his writing.

One of the papers dated 1864 bears the heading "Kisug�roz" in addition to what appears
to be a finely drawn sketch depicting an arrangement of small stones on a grid.  A
translation of the text reveals a simple game played with large and small musket balls.
The Hungarian word Kisug�roz means "to emanate".  The Doctrine of Kisug�roz refers to
the creation of the heavens and asserts that life originates from a spiritual potency
above the whole.  The Doctrine predates the spread of Calvinism in Hungary during the
16th century Reformation.

There is reason to believe that the game caught on with some of the infantrymen who
would have been able to play it with readily available materials.  However, further
research has yielded no references to this game, so I must sadly conclude that it has
long since been forgotten (if someone discovers further information, please contact me).

Therefore, it is with honor to my ancestors that I am now able to revive "Kisug�roz" in the
form of an Axiom game by the name of "Emanations".  I would like to mention that the game
board image was derived from an heirloom snuff box that had once belonged to Ludvig.

Emanations is dedicated to Ludvig Schmidt.

