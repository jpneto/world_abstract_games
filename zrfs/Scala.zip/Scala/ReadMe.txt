Scala v1.1
----------
Invented by Jose W. Diaz, Copyright (c) 1986.
Implemented by Karl Scherer, November 16, 2002.

Updated December 7, 2002: corrected specific win condition bug


Object: to advance a stone into the opposite goal. 

Blue (stones marked 'O') moves first with a goal square of f14.
Red (stones marked 'X') moves second with a goal square of f1.
Turns alternate.

A stone may either move to any adjacent (orthogonal or diagonal) empty space
or may make a jump or a series of jumps.

A jump is over any stone (friend or foe, orthogonal or diagonal) landing on the opposite 
empty space.
A player may make multiple jumps on the same turn,  may change direction after each jump,
and may mix jumping enemy and friendly stones but may not move or jump into the goal the 
player is defending. 

If after a move is completed the set of ALL stones consists of two or more disconnected 
groups then some stones will be eliminated as follows:
1 - First the monochrome groups will be eliminated; 
2 - If this leaves no stones on the board, then the moving player loses*;
3 - From the remaining (mixed) groups, all groups apart from the biggest group will be eliminated;
4 - If that leaves two or more biggest groups of same size the moving player loses*.

The Zillions version of Scala works best in a human vs human game.  Please see the Strategy notes.  

* This differs from the original board game which did not allow such moves.  It codes better 
in Zillions this way and effectively prevents such a move.


Graphics by Keith Carter.

This file was developed to help Keith track games being played in an email tournament
that used ascii board diagrams.
The scale of the graphics were designed to match the scale of the ascii diagrams.


----------------------------------------------------------------
To play:

Double click the Scala icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Scala.zrf" in the Open dialog and click "Open"

Scala.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
