Pompeii

(c) 2000  W. D. Troyka

(Updated 1/01:  Improved implementation.)

Pompeii is a game of pushing, swapping, and positional attainment 
played on a variety of board designs that emphasize corners and 
"choke points."  The object is to move all of your pieces into 
your opponent's starting positions (the "home zone").  

Pieces move horizontally or vertically any number of available spaces.  
A piece can push any number of pieces of either color until a wall is 
reached.  If the pieces being pushed are initially spaced out, they 
will be compressed together when pushed.  A piece can also swap with 
an adjacent enemy piece.  (Zillions will prompt you if a move could 
be either a push or a swap.)  You may not push or swap an enemy piece 
that moved on the previous turn or is in your home zone.  Such a piece
is considered "fixed."  There is no capturing.

You also win by trapping an opponent piece in its home zone.  This 
occurs when you place two of your pieces in your opponent's home zone 
on both sides of an opponent piece in a corner.  The trapped piece is 
completely immobilized.

The game presents many tactical choices.  You can: double up your 
pieces so that a single move pushes multiple friendly pieces; occupy 
corners and choke points that impede your opponent's progress; move a 
piece quickly into your opponent's home zone, where the fixity of the 
piece creates an obstacle; or quickly move all of your pieces out of 
your home zone, leaving occupation of your opponent's home zone for 
the endgame.  The appropriate tactics may vary according to the 
board design.

You should extract the game preserving path names. 


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Pompeii.zrf" in the Open dialog and click "Open"

Pompeii.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 


 
