Wild Goose Chase

(c) 2001  W. D. Troyka


Wild Goose Chase is a simple chase game in which the object 
is (surprise!) to capture the wild goose.  Unless you are 
the wild goose, in which case the object is not to get 
captured.

Tame geese move one orthogonal step.

The wild goose moves like a Queen except that it can fly off 
the board in any direction and reemerge on the other side of 
the board.

You have 15 moves to capture the wild goose.  The wild goose 
wins if it eludes capture.  The loser is supper.

In the variant, there is no move limit and the chase can 
continue indefinitely (hardly fair for the wild goose).

Wild Goose Chase is the latest in a series of 5x5 games 
centered around that great abstract concept - the duck (or 
permutations such as geese).  Other games in the series 
include Duck Pond, Ugly Duck, and Duck Solo.  Each game is 
intended to explore a different fundamental game type, such 
as alignment (Duck Pond), attainment (Ugly Duck), solitaire 
(Duck Solo), or chase (Wild Goose Chase).  With the rich vein 
that has been tapped here, other games are sure to follow.


----------------------------------------------------------------

To play:

Double click the WildGoose icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "WildGoose.zrf" in the Open dialog and click "Open"

WildGoose.zrf is a rules file used by the Windows program "Zillions 
of Games".  Zillions of Games allows you to play any number of games 
against the computer or over the Internet.  Zillions of Games can be 
purchased online.  For more information please visit the Zillions of 
Games website at http://www.zillions-of-games.com.