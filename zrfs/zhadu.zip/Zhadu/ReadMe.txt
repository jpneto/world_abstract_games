Zhadu - "the unofficial version"
--------------------------------
Invented by R.A. Frederickson,
implemented by L. Lynn Smith, January 2005.


Zhadu is played on a field of eight triangles arranged in a diamond pattern.  Each player has five stones, which can be referred to as: the [1 stone], [2 stone], [3 stone], [123 stone] and [4 stone].

Stones may occupy the center and corners of each triangle.  The movement of the stones consist of translation from center to corner of a triangle, corner to center of a triangle, corner to corner of a triangle, and corner to corner of orthogonally adjacent triangles.
Stones are initially placed onto the center and corners of triangles which form the opposite points of the board, and on the center of the next orthogonally adjacent triangle.
Players begin the game by placing all their stones on the playing field, one at a time, in turn.  Then play continues with movement of one piece by each player in turn.
The [1 Stone], the smallest stone, moves one space per turn.
The [2 Stone], the next to smallest stone, moves exactly two spaces per turn.
The [3 Stone], the medium stone, moves exactly three spaces per turn.
The [123 Stone], the marked medium stone, moves either one, two or three spaces per turn.
The [4 Stone], the largest stone, moves exactly four spaces per turn.

All stones must move through vacant spaces, and may capture an opponent stone on the last.
Your intention in Zhadu is to 'remember the Sharing'. This occurs when the sum value of the first and last captured stone by a player is equal to four. Any other stones captured beforehand are simply considered removed and the gameplay continues.
If the first stone captured is the...
[1 stone], the player must capture the [3 stone] or [123 stone] to win.
[2 stone], the player must capture the [123 stone] to win.
[3 stone], the player must capture the [1 stone] or [123 stone] to win.
[123 stone], the player must capture the [1 stone], [2 stone] or [3 stone] to win.
[4 stone], the player wins.
		

----------------------------------------------------------------
To play:

Double-click the Zhadu icon, or:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Zhadu.zrf" in the Open dialog and click "Open"

Zhadu.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

