
Reactor
-------------------------------------------------------------------
***** Requires Zillions version 1.3 or higher to play. *****
-------------------------------------------------------------------
Designed by Robert A. Kraus in 2000.
Implemented by Robert A. Kraus for Zillions of Games in 2002
E-mail:  BobKraus@csi.com
WebSite:   http://www.geocities.com/bob_kraus_2000
-------------------------------------------------------------------
The White and Black players each start with 13 Atoms of their color, 
and there are also 4 neutral pieces called Neutrons.
Click the green  'start thinking'  circle to automatically randomize the starting
position of the Atoms and Neutrons . 
The object of the game is to get rid of your opponent's Atoms.
Atoms cannot move.
Each player can move a Neutron in any direction, but it must keep moving through
all empty squares until it hits another piece or comes to rest against a wall.
It then explodes and destroys all atoms of both players which are adjacent to it.
Neutrons are never destroyed. 
A player cannot move a Neutron that his opponent last moved. 
If a move by either player leaves atoms belonging to only one player, that player wins.
If the last move leaves no Atoms of either player it is a draw. 
If a player has Atoms left but has no legal moves he is stalemated and it counts as a draw.
-------------------------------------------------------------------
You should have extracted this zip file preserving path names,
(Check "Use Folder Names" box in Win-Zip Extract Files Dialog Box);
and you should extract to your Zillions Rules folder.This will
create a Reactor folder within the Rules folder.
-------------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Reactor" folder in the Open dialog and click "Open"
4. Select "Reactor.zrf" in the Open dialog and click "Open"
-------------------------------------------------------------------
Reactor.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
-------------------------------------------------------------------
