Jackrabbits
-----------
Created by Chris Huntoon, August 2000,
Improved by Jens Markmann and Patrick S. Duff.

Updated October 2000: fixed image problem with Windows NT/2000.


Two players take turns placing rabbits on a board. 
The following round after a rabbit has been placed it will begin 
to reproduce itself. This means if there are any open spaces in 
any of the orthogonal directions surrounding a rabbit, they also 
will be filled with rabbits. These rabbits will also reproduce 
themselves on subsequent rounds. Each turn the board will become 
progressively more crowded. 
The player forced to fill in the last remaining space, loses.

Keep in mind that the edges and the corners are usually the last 
to be filled.  It is also beneficial sometimes to drop rabbits 
near others in order to impede growth.


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Jackrabbits.zrf" in the Open dialog and click "Open"

Jackrabbits.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

