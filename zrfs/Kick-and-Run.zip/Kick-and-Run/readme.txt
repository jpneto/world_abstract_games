Kick and Run

By Ingo Althofer and Peter Stahlhacke;
Copyright July 2003.

 
Two teams, Red and Orange, rush against each other.
To win you have to bring one of your Runners to the 
opposite back square - or you have to stalemate the opponent.
Pieces can move forward only. Runners run either vertically
or diagonally. Sidekickers make only single steps, and only 
diagonally forward. But in addition Sidekickers can capture 
the opponent's pieces by sidekicks.

"Kick and Run" was inspired by "BallaBalla" and by D.W. Troyka's 
games "Breakthrough" and "Sidewinder".

When you like to experiment try your own starting setups, for 
instance asymmetric ones where one side has only Runners and
the opponent only Sidekickers.
