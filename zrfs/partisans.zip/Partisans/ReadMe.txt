PARTISANS
---------

Partisans was designed by Luis Bola�os Mures in 2020. It is a simple variant of Amazons, a game designed by Walter Zamkauskas in 1992.

Zillions implementation by Luis Bola�os Mures.

--------------------------------------------------------
To play:

Double click the Partisans game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Partisans.zrf" in the Open dialog and click "Open"

Partisans.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com>

--------------------------------------------------------
At the start of the game, white partisans are placed on a4, g1, d10 and j7, and black partisans are placed on a7, g10, d1, j4.

On your turn, move a partisan of your color to an empty square in a straight orthogonal or diagonal line, without jumping over enemy pieces. Partisans can jump over friendly partisans and arrows.

Then, place an arrow on an empty square which is on the same straight orthogonal or diagonal line as the destination square of the partisan you just moved, with no enemy pieces in between along that line.

On their first turn, White must move a white partisan without shooting an arrow.

If you have no moves available on your turn, you lose.