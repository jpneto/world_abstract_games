Yot�
-------------------------------------------------------------
Invented and Implemented by Peter Aronson, February 2001.
-------------------------------------------------------------
Yot� (YOH-tay)is a traditional West African game resembling 
Checkers and the Morris family of games.  Each player starts with 
12 pieces (Stones) off board in their reserve.  Each turn they may 
either deploy a Stone from the reserve to any empty space on the 
board, or move a Stone on the board.  Stones move either by sliding 
one space up, down, left or right, or by jumping over and capturing 
an opposing Stone next to them in one of those directions.

When a Stone captures an opposing Stone, the player may then select
any opposing Stone on the board (but not in their opponent's reserve)
and capture it as well.  A player may continue to jump opposing 
Stones with the piece they have moved until they run out of Stones
to jump; however, captures are never required.

The object of the game is capture all of your opponents Stones.  If 
either player is unable to move, then the game ends and the player
with the most Stones remaining wins.  If both players are reduced to
three or less Stones, then the game is a draw.

This ZRF includes simple, regular, and advanced versions, with and
without enforcement of the three stones or less draw rule (Zillions
runs better without it).
-------------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Yote" folder in the Open dialog and click "Open"
4. Select "Yote.zrf" in the Open dialog and click "Open"
-------------------------------------------------------------------
"Yote.zrf" is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
-------------------------------------------------------------------
