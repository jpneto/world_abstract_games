Ellen's Checkers
----------------
Created by Roger Cooper. March 2003.


Object: Capture all your opponent's pieces ("Checkers" or "Kings") 
by jumping over them, or stalemate the opponent so he has no moves.

Checkers can only move diagonally forward, either by sliding to an 
adjacent empty square or by jumping over an enemy piece to a
vacant square on the other side.  Jumping over a piece captures 
it.   Capturing is mandatory, and you must keep jumping and capturing 
as long as it is possible.

When your Checker reaches the other end of the board, it becomes 
a King and can then also move diagonally backwards.

This version of checkers contains 12 variants, each with 1 more
checker, to be played progressively.


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Ellen's Checkers.zrf" in the Open dialog and click "Open"

Ellen's Checkers.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

