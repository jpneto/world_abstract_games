----------------------------------------------
*** CramCheckers v1.0                      ***
* *                                        * *
* * implemented by K. Franklin, July 2015  * *
* * e-mail address: frnklnk@yahoo.ca       * *
----------------------------------------------
*** Copyright 1998-2000 Zillions Development (v1.31)

You need to purchase Zillions of Games to load this rules file
Visit the Zillions web site at http://www.zillions-of-games.com
---------------------------------------------------------------
built upon Zillion v1.3's Checkers.zrf

Standard Checkers, except that each cram square (i.e; a1/A1 to h8/H8) accepts two playing pieces.
Checkers may move or jump, to or from, either side of their adjoining half-squares; 
capturing jumps are mandatory AND must [can only] be completed through each captured piece's 
vacant aligned side.  Checkers may not be moved only within a single cram square.


Object: Capture all your opponent's men (`Checkers`) by jumping over them, or 
stalemate the opponent so he has no moves.  Checkers can only move diagonally forward, 
either by sliding to an adjacent empty half-square or by jumping over an enemy piece to
a vacant (aligned) landing square on the other side.  Pieces from both players may co-occupy
any playable cram square location.
Jumping over an enemy piece captures it.
Capturing is mandatory, and you must keep jumping and capturing as long as it is possible.  
Maximal-captures (forcing the path with the most captures) is not applied here.
When your Checker reaches the other end of the board, it becomes a King and can
then also move diagonally backwards.

'Doubling back' is also allowed - where a King might jump one enemy piece then make a return capturing
jump to the starting position's OTHER 'half-square' - but not to its own starting half-square.
With the Chinese CramCheckers variants, a similar double-back duality can exist with non-captured 
friendly-side piece jumps.

- - - - - - - - - - -
Chinese* CramCheckers allows for the non-capture jumps of friendly-side pieces.  Initial 
'enemy piece' jumps continue as mandatory.  Follow-up jumps during combined turn sequences
may be taken over EITHER and/or both sides' pieces.  Friendly-side jumps may also begin
a turn sequence, when mandatory enemy-side jumps are non-existent.  Unlike Chinese Checkers, 
follow-up jumps cannot be declined.


A 6x8 board layout is provided as CramCheckers' default variant.

You should have extracted this zip file preserving path names.
--------------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "CramCheckers.zrf" in the Open dialog and click "Open"

CramCheckers.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 



