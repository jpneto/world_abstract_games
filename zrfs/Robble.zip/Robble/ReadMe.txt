ROBBLE
------

Robble was invented by Luis Bola�os Mures in December, 2020.

Zillions implementation by Luis Bola�os Mures.

--------------------------------------------------------
To play:

Double click the Robble game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Robble.zrf" in the Open dialog and click "Open"

Robble.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com>

--------------------------------------------------------
Robble is a territory game for two players: Black and White. It is played on the spaces (squares) of an initially empty square board. The recommended board sizes are between 5x5 and 9x9. Each player must have access to a sufficient number of stones of their own color.


DEFINITIONS

In these rules, "adjacent" always means "orthogonally adjacent".

A group is a stone along with all other like-colored stones one could reach from it through a series of steps between adjacent stones of its color. The size of a group is the number of stones in it.


PLAY

Black plays first, then turns alternate. On your turn, place a stone of your color on an empty square. Then,

- for every stone 'A' that is adjacent to your newly placed stone in one direction and to an empty square 'B' in the opposite direction, move stone 'A' to empty square 'B';

- for every stone 'A' that is adjacent to your newly placed stone in one direction and to the edge of the board in the opposite direction, remove stone 'A', and

- for every stone 'A' that is adjacent to your newly placed stone in one direction and to another stone in the opposite direction, replace stone 'A' with a stone of the opposite color.

The game ends when the board is full. Then, the players jointly remove pairs of opposite-colored groups of the same size from the board until there are no more such pairs to remove. The player with the biggest group left over wins. If the board is empty, whoever made the last move before the game's end loses.

If the same board position appears for the third time with the same player to move, the game ends in a draw.


PIE RULE

The pie rule is used in order to make the game fair. This means White will have the option, on their first turn only, to swap sides with their opponent instead of making a regular move.


NOTES

Repeating a position is very hard on a 5x5 board, and it is believed to be impossible on bigger boards.

Robble was inspired by Gekitai and Pathwayz.

The win condition and the pie rule are not enforced in this implementation.