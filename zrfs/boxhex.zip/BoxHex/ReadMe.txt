BoxHex for Zillions by Bob Henderson

BoxHex is a puzzle game similar to the old "Sokoban" warehouse puzzles, but in this warehouse you can only push the boxes from the inside!  In each puzzle your goal is to push the small red box into the large blue box using only the small black pusher hex and your own puzzling skills.  The Pusher moves alone without counting moves, but a move is counted each time it pushes a box.  Dark green and brown boxes may be used to help get the red and blue boxes together, but sometimes they just get in the way.  See how many of these 36 new variants you can solve without asking Zillions to play for you!  If you doubt that a puzzle can be solved, just click on menu items 'Help - Show solution' to load one of the shortest possible solutions.

36 HexBox puzzles are also available from Zillions, and you can play similar puzzles on a rectangular grid as Java appplets at Andrea Gilbert's Website, <http://www.clickmazes.com>.

BoxUp puzzle concept (c) Andrea Gilbert, used with permission

BoxHex adaptation and puzzle layouts (c) Bob Henderson
----------------------------------------------------------------
To play:

Double click the "BoxHex" icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "BoxHex.zrf" in the Open dialog and click "Open"

BoxHex.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
