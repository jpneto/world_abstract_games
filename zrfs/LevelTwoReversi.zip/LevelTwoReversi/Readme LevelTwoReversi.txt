-----------------------------------------------------------
*** LevelTwo Reversi v1.0                               ***
* *                                                     * *
* * created and implemented by K. Franklin, Jun. 2013   * *
* * e-mail address: kenf@ica.net (or frnklnk@yahoo.ca)  * *
-----------------------------------------------------------
Copyright 1998-2000 Zillions Development (v1.31)

based on Zillion's Reversi v1.2
SPECIAL NOTE: the Jello.dll engine has been left out. 

You need to purchase Zillions of Games to load this rules file
Visit the Zillions web site at http://www.zillions-of-games.com


Object:
Black and White alternate dropping pawn or king disks.  Pawns are placed on
vacant squares; kings are placed over pawns.  Each disk must be placed so
that it sandwiches one or more enemy pieces between itself and another friendly
piece, with no empty squares intervening.  The sandwiched enemy pieces are
flipped, changing colour.

If one player can't move, he must pass his turn.
The game ends when neither side can move, usually when the whole board
is filled.  The winner is the player with the most on-board pieces
(both king and pawn disks) of his colour.

-----------------------------------------------------------------------------

You should extract the game preserving path names. 

To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "LevelTwoReversi.zrf" in the Open dialog and click "Open"

LevelTwoReversi.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
