Foxhunt
-------
Implemented by Karl Scherer, December 2000.


Object: The Hunters have to capture the Fox.
You start as the Fox.

Moves are along the black lines. There are no captures.
The Fox may run one step into any direction.
The Hunters move inwards toward the centre, never outwards.
They win when the Fox has no place to go anymore.

In variant 2 the Hunters have only 7 men. 
In variants 3 to 6 the Fox is allowed to move inside a ring a 
few times. (i.e. to a neighboring place of same colour).

 
Foxhunt is a historic relative of the game 'Fox and Geese'.
Source: Book 'Unsere Spiele' by Werner Hirte.
 
To make the game more interesting, I have added a few variants 
which give the Fox some more freedom of movement.


More freeware as well as real puzzles and games at 
http://karl.kiwi.gen.nz.


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Foxhunt.zrf" in the Open dialog and click "Open"

Foxhunt.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

