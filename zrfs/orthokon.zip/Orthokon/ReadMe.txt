Orthokon
--------
Invented and implemented by L. Lynn Smith, August 2001.


Orthokon is a two-player game.  Each player has four pieces
at the start, arranged on opposite ranks of a 4x4 field.

A piece moves either diagonal or orthogonal through empty spaces,
stopping only when encountering another piece or an edge of the
playing field.  It then changes all pieces which are orthogonally
adjacent into pieces of its own color.

The game is won when the opponent no longer has any pieces or
possible move.


----------------------------------------------------------------
To play:

Double click the Orthokon icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Orthokon.zrf" in the Open dialog and click "Open"

Orthokon.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
