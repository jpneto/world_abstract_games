Mylaska v1.2
------------
Invented and implemented by Karl Scherer, December 2000.
Updated October 27, 2007: bug in variant 2 corrected.


Object: Stalemate your opponent or take all his pieces.
(2 variants)

You start with Blue.
Moves and jumps are diagonally.
Pieces either move one step forward or capture an enemy piece by 
jumping over it. Jumps are forced. 
The first piece captured is placed underneath the capturing piece.
When such a column is captured, the piece underneath is freed.

Once a piece reaches the other side of the board,
it can move and jump backwards and forward from then on.
As a mental hook its colour will change (from light blue to dark blue
and from orange to red).

Please note that there is an alternative piece set available.

  
Mylaska is a simplified version of the game 'Laska' 
which the world chess champion Emmanuel Lasker invented around 1900.
In the original version the column may grow higher than two tokens.


More freeware as well as real puzzles and games at 
http://karl.kiwi.gen.nz.


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Mylaska.zrf" in the Open dialog and click "Open"

Mylaska.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

