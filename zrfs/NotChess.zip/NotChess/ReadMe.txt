NotChess
--------
Created by Ronald Brierley, July 2003.


NotChess is a game for two to six players on a standard chess board 
but using only one type of piece, the Alternator. Any piece is able 
to be captured by an opponent whose piece moves onto the square of 
the piece being captured. 
The objective is to become the only player remaining on the board. 
A draw is a possibility. 

An Alternator moves as a chess knight when moving from a white square 
but it moves as a short range chess rook when moving from a black square. 

Several saved games illustrate the strength of the ZoG AI. 

NotChess requires ZoG version 2.0 or higher.


----------------------------------------------------------------
To play:

Double click the NotChess icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "NotChess.zrf" in the Open dialog and click "Open"

NotChess.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

