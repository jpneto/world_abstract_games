Three Crowns
------------
Designed by Larry Back,
implemented by L. Lynn Smith, August 2001.


Three Crowns is a game for two players.

The pieces are two types, Crowned and Uncrowned.  Initially, all pieces 
are Uncrowned.

White has the first turn and players alternate turns throughout the game.

On White's second turn, White must move the same piece that was moved 
on White's first turn.
On all other turns, for both White and Black, any piece may be moved.  
This rule is intended to offset White's advantage of the first move.

At each turn, a piece must be moved.  Players cannot pass their turn.

The non-jumping move consists of stepping a piece, Crowned or Uncrowned, 
in a orthogonal or diagonal direction to any vacant adjacent square.

A formation of three or more Uncrowned pieces in a row, all belonging to 
the same player, in an orthogonal or diagonal direction is called a 'Troika'.  
If an Uncrowned piece becomes part of a 'Troika' after moving, it becomes 
Crowned.

Instead of moving to an adjacent square a piece, Crowned or Uncrowned, 
can make a double jump over two opponent pieces.

Crowned pieces can only jump over opponent Uncrowned pieces.  Uncrowned 
pieces can only jump opponent Crowned pieces.

A jumping move consists of moving a piece two squares in an orthogonal 
or diagonal direction to a vacant square while passing directly over the 
opponent piece.  After making one jumping move, a piece must make a second.  
The second jumping move can be made in the same direction, or in a different 
direction.  A third jumping move is not permitted.  If no second jumping 
move is possible, then the first jumping move cannot be made.

Jumping moves are not compulsory.  All jumping moves must be double jumps.

When two Uncrowned pieces are jumped then the second jumped Uncrowned piece 
is captured and removed from the game.

When two Crowned pieces are jumped, as long as a it would not become part a 
'Troika', the second jumped Crowned piece becomes Uncrowned. If a 'Troika' 
would result from Uncrowning, the second Crowned piece is captured and 
removed from the game.

If an Uncrowned piece becomes part of a 'Troika' after making the double 
jump, it is Crowned.

A formation of three or more Crowned pieces in a row, all belonging to the 
same player, in an orthogonal or diagonal direction is called a 'Crowned Troika'.

The object of Three Crowns, to be the first player who captures three pieces 
or forms a 'Crowned Troika'.


----------------------------------------------------------------
To play:

Double click the Three_Crowns icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Three_Crowns.zrf" in the Open dialog and click "Open"

Three_Crowns.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
