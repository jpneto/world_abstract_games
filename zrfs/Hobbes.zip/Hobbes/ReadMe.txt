Hobbes
(c) 2002  W. D. Troyka
dtroyka@justice.com


Hobbes is a game with an unusual type of motion.  Each player has a single piece called the Monarch that can move to any square on the board that can be reached by a combination of orthogonal moves.  The move must end by pushing or pulling a Soldier in a straight line any number of vacant spaces.  Soldiers are neutral pieces that cannot move on their own.  Win by capturing the opposing Monarch or crushing it so that it cannot move.

The Monarchs are separated by a wall of Soldiers called the Front.  Behind the Front, the area through which the Monarch can move is called its Dominion.  The effect of the Monarch's motion is to push and pull the Front so that it forms an ever changing line separating the players.  Basic strategy consists of forcing the enemy Monarch to breach the Front so that it can be captured on the next turn, or collapsing the Front around the Monarch until it is crushed. 

Hobbes is named after Thomas Hobbes, a 17th-century British philosopher who argued that power naturally gravitates to a single absolute Monarch.  The game was invented in 1998 and inspired by Robert Kraus' Neutron.

Hobbes comes with 2-player and 4-player variants played on 5x5, 7x7, and 9x9 boards.  In the 4-player variants the game continues until a single Monarch remains.  Smart Moves must be selected in order to play the 4-player variants. You can design your own variants by right-clicking to place the pieces.

A Monarch move is normally accomplished by first moving the Monarch to a square adjacent to a Soldier, then pushing or pulling the Soldier.  If the Soldier is on the same rank or file as the Monarch, a push may be accomplished in one step.  If a move could be either a maneuver (push or pull) or a Dominion move to be followed by a maneuver, Zillions will offer you a selection box.

Hobbes was conceived as a 5x5 game and is most entertaining at that size.  The 5x5 version can almost certainly be solved and I would welcome any formal proof.  I have worked out an informal solution using Zillions that gives the first player a win in 19 moves.  The first player can be handicapped by prohibiting a forward opening move.
  
Please send any comments or bug reports to dtroyka@justice.com.

----------------------------------------------------------------
To play:

Double click the Hobbes icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Hobbes.zrf" in the Open dialog and click "Open"

Hobbes.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 