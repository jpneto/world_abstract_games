MuchAdo is a combination of Draughts and Reversi, much in the spirit of
Chips, BunnyWar, BlackWhite etc. (Check out these games on this site),
the main difference being that promotion depends on how many tokens
are left off-board.Require Zog 2.
MuchAdo.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com>

