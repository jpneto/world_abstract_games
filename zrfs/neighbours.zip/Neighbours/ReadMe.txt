Neighbours
----------
Implemented by Frank Riepenhausen, April 2003.

In the game of neighbours every piece gets movement "power" from its neighbours: It can move as many squares horizontally or diagonally as there are directly adjacent pieces (friend and foe). The last one who can still move wins! 

These simple rules make for a quite difficult game, especially in the middle game when the black and white lines get mixed. 

Feedback and suggestions to Frank.Riepenhausen@gmx.net


----------------------------------------------------------------
To play:

Double click the Neighbours icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Neighbours.zrf" in the Open dialog and click "Open"

Neighbours.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
