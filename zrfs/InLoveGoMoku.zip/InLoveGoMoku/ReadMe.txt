In Love Go-Moku
---------
by Vincent Everaert, january 2006.
vincent.everaert@club-internet.fr
---------
In Love Go-Moku is an attempt to give to both players equal chances
without the help of the Renju's rules.

To play, one has to drop a first stone on the board and then an enemy stone nearby.
If there is no vacant square around the first stone, this second drop cannot occur.
The first player who obtains a line of 5 (or more) stones of his color wins the game.

Any comment from Renju and Go-moku players is welcome!
----------------------------------------------------------------
To play:

Double click the ILGM icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "ILGM.zrf" in the Open dialog and click "Open"

Area.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
