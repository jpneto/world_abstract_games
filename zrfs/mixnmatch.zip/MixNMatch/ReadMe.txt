Mix-n-Match
-----------
Created by Chris Huntoon, February 2001.


One player is Mix, the other Match. Both may move either of the 
two types of pieces. However, Mix can only jump and capture pieces 
if they are different from each other (i.e. an Apple with an Orange) 
and Match can only jump and capture pieces if they are the same as 
each other (i.e. an Apple with an Apple). 
�
Pieces can jump in any direction. If the capturing piece can make 
another capture, it may do so or it may pass. Pieces can only move 
by capturing. The first player unable to make a move on his turn, 
loses. 


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "MixNMatch.zrf" in the Open dialog and click "Open"

MixNMatch.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

