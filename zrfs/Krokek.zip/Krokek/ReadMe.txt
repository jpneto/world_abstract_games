Krokek
------
Invented and implemented by Markus Salo, August 2003.


On each turn, each player must do one of the following things: 

Capture a stone on a orthogonal forward direction (White: north or east, 
Black: south or west) by jumping over it and landing on the immediate 
empty cell. Captures are multiple and mandatory.

Drop a captured friendly stone on any empty cell.

Move a stone on a orthogonal forward direction (White: north or east, 
Black: south or west) to an empty cell.

The player that moves his army to the opponent's setup wins.


Krokek is a derivative of my earlier game 'Vanakriget'.  Krokek is a 
better game than 'Vanakriget' with more strategy and depth.
        
Krokek is a village in Norrk�ping county with a beautiful view over the 
Br�viken Bay.

----------------------------------------------------------------
To play:

Double click the Krokek icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Krokek.zrf" in the Open dialog and click "Open"

Krokek.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
