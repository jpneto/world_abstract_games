Nu, Pogodi!
-----------
Invented by Isaak G Shafran, 
implemented by Ivan A Derzhanski, August 2001.


The object for the Wolves is to surround the Hare so he can't move.
The object for the Hare is to get past the Wolves to the other side of the
board.  
The Hare moves one hex in any direction.  The Wolves move only forwards.
There is no capturing in this game.

This is Wolf and Sheep, a version of the game known in the anglophone
word as Fox and Geese, adapted to a hexagonal board by the Soviet geologist
Isaak Grigor'evich Shafran, who has also created a hexagonal chess game
(see <http://www.math.bas.bg/~iad/tyalie/shegra/shegrax.html> for a description
and ZRF) and two versions of hexagonal draughts.

The original name of the game was Kid and Wolves,
after a Russian `horror nursery rhyme' (who said that England
had a monopoly on those?) about a careless little goat
who walks into the woods and gets eaten by a pack of famished grey predators.
In this game, however, the chased party has very good chances of not getting
caught, which may be the reason it acquired a new name.
'Nu, pogodi!' ('Just You Wait!') is a very popular Soviet cartoon
featuring the foolish Big Bad Wolf's repeated and vain efforts
to seize the cheerful Good Little Hare.


----------------------------------------------------------------
To play:

Double click the Nu_Pogodi icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Nu_Pogodi.zrf" in the Open dialog and click "Open"

Nu_Pogodi.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
