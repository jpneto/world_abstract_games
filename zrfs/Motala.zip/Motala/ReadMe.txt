Motala Str�m
------------
Invented and implemented by Markus Salo, February 2003.
Updated November 29, 2003: new graphics


Both players take turns placing their four pieces on the board. 
The pieces move one space att the time.  
Enemy pieces are captured by jumping.  Capturing is mandatory.  
Multiple capture jumps must be made if possible.  
The goal is to capture all enemy pieces or have your last piece 
on the space of your color.


This game is the only turn based 1D strategy I have ever seen.
I think it is not possible to make the board and rules simplier and 
still have a working strategy game.  
The game is suprisingly challenging and the computer opponent is hard to beat.  
Motala Str�m is the river that flows through my beloved Norrkoping, Sweden.

Please send your comments to msalo71@yahoo.com


----------------------------------------------------------------
To play:

Double click the Motala game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Motala.zrf" in the Open dialog and click "Open"

Motala.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

