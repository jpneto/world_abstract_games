Walls
-----
Implemented by Karl Scherer, May-June 2000.


Object: Grow as many flowers as possible.

Each square that is enclosed by four walls will grow a flower. 
The flower is yours if you added the fourth wall.

The player with the most flowers wins.

In variants 5 to 8 you get a free turn for every flower.

Walls is a very old game adapted here for Zillions
by Karl Scherer in May 2000.

In Germany it is called 'K�sek�stchen' = 'Cheeseboxes'
and is widely played amongst pupils.


More freeware as well as real puzzles and games under 
http://karl.kiwi.gen.nz.


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Walls.zrf" in the Open dialog and click "Open"

Walls.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

