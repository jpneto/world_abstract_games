Bunny War
---------
Invented and implemented by L. Lynn Smith, August 2001.


Bunny War is an 8x8 board game for two players, who each
begin with two ranks of Bunnies.

A Bunny can run straight, orthogonally or diagonally, through
adjacent vacant spaces.

A Bunny can capture by hopping over an adjacent opponent Bunny.
Once a Bunny begins hopping, its must continue to hop until there
are no more legal hops.

The game is won when your opponent has one Bunny left.

So, get hopping.


----------------------------------------------------------------
To play:

Double click the BunnyWar icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "BunnyWar.zrf" in the Open dialog and click "Open"

BunnyWar.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
