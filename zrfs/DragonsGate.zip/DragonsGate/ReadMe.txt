Dragons Gate
-----------------
Created 2013
Copyright (c) 2013, Chris Huntoon
Please send any feedback to Hartunga66@yahoo.com

In a typical game of breakthrough/attainment there are usually two basic elements: 1. - The player is trying to advance his own pieces across the board. 2. � The player attacks his opponent�s pieces to prevent him from doing the same. Backwards captures is a mechanic that affects both of these simultaneously. You can remove one of your opponent�s pieces only at the cost of delaying your own advancement.


The goal of this game is to be the first player to get one of your own Dragons across the board and through the enemy�s gate. (The corner spaces marked with Chinese characters are nominally the posts of the gate.)

A Dragon moves forward by taking a single step, either diagonally or vertically, onto an empty space. A Dragon may also fly (jump) forward over a single friendly Dragon to the empty space just beyond. But it may not fly over an enemy Dragon.


A Dragon captures enemy pieces by withdrawal. This means if a Dragon begins its turn with an enemy Dragon adjacent and just in front of it, it may take a single step backwards, in the opposite direction, to the empty space just behind it. (Imagine a Dragon rearing its head back to breathe fire.) The enemy Dragon is then removed from the board.

----------------------------------------------------------------
To play:

Double click the Dragons Gate game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Dragons Gate.zrf" in the Open dialog and click 
   "Open"

Dragons Gate.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
