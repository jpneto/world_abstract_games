Blue Nile

(c) 2002  W. D. Troyka
dtroyka@justice.com


Blue Nile is played on a radial hex board with a common set of pieces.  The 
first piece is dropped on any empty space.  The players then take turns dropping 
pieces adjacent to the last piece played but not adjacent to any other pieces.  
The line of pieces thus formed is called the `River.`  The River winds around 
the board but cannot turn back on itself.  Win by stalemating the opponent.

To distinguish between the players' pieces, select `Switch Piece Set` from the 
View menu.  The game comes in two board sizes, one with five hexes to a side, the 
other six.  Also included are two variants featuring a looped hex board.  The 
edges wrap around along all three axes so that the River can flow off one edge 
of the board and re-emerge on another.

You can think of your mission as finding the source of the Nile.  You follow the 
River until it goes no farther.  The last player to move is the first to find the 
source, and that player is the winner

Please send any comments or bug reports to dtroyka@justice.com. 


----------------------------------------------------------------


To play:

Double click the Blue Nile game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "BlueNile.zrf" in the Open dialog and click "Open"

BlueNile.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play 
any number of games against the computer or over the Internet. 
Zillions of Games can be purchased online.  For more information,
please visit the Zillions of Games website:

              <http://www.zillions-of-games.com> 
