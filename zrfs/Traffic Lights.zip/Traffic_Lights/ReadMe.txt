Traffic Lights v1.1
-------------------
Invented and implemented by Karl Scherer, March 2001.


Object: Make all Traffic Lights show the green light.
(1 randomized variant).

Click anywhere on the board to allow Zillions to create a random setup.

Each Traffic Light will go from green to orange to red when you click it.
However, each Traffic Light will also advance certain other Traffic Lights.
It may affect every second or every third or every fourth Traffic Light or...,
counting clockwise and starting at the clicked Traffic Light.
You have to find this out for yourself.  

How a certain Traffic Light affects the other Traffic Lights changes 
from game to game.


Background: Photo from click-art CD collection 'Imagine It'.


For more free software and (real) puzzles and games see  
http://karl.kiwi.gen.nz .


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Traffic_Lights.zrf" in the Open dialog and click "Open"

Traffic_Lights.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

