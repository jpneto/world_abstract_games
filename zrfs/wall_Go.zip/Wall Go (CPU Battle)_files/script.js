document.addEventListener('DOMContentLoaded', () => {
    // --- DOM要素取得 ---
    const gameSetupScreen = document.getElementById('game-setup-screen');
    const gameBoardScreen = document.getElementById('game-board-screen');
    const cpuLevelSelect = document.getElementById('cpu-level');
    const playerOrderSelect = document.getElementById('player-order');
    const startGameButton = document.getElementById('start-game-button');

    const boardElement = document.getElementById('board-grid');
    const turnDisplayElement = document.getElementById('turn-display');
    const resetButtonElement = document.getElementById('reset-button');
    const reselectButtonElement = document.getElementById('reselect-button');
    const playerScoreLabelElement = document.getElementById('player-score-label');
    const cpuScoreLabelElement = document.getElementById('cpu-score-label');
    const messageBox = document.getElementById('message-box');
    const messageText = document.getElementById('message-text');
    const messageOkButton = document.getElementById('message-ok-button');

    // --- 定数定義 ---
    const ROWS = 7;
    const COLS = 7;
    const PLAYERS = ["red", "blue"];

    const initialFixedPiecesCoordinates = {
        red: [{ row: 1, col: 1 }, { row: 5, col: 5 }],
        blue: [{ row: 1, col: 5 }, { row: 5, col: 1 }]
    };
    let placementSequenceActual;


    // --- ゲーム状態変数 ---
    let boardState;
    let walls;
    let cellsDOM = [];
    let gamePhase;
    let selectedPiece = null;
    let lastMovedPieceCoordinates = null;
    let movedPieceInfoForReselect = null;
    let playerScore = 0;
    let cpuScore = 0;
    let humanPlayerColor;
    let cpuPlayerColor;
    let currentTurnPlayerColor;
    let currentPlacementTurnIndex;
    let piecesPlacedCount;
    let cpuLevel;

    // --- メッセージボックス ---
    function showMessageBox(message) {
        messageText.textContent = message;
        messageBox.classList.add('show');
    }
    function hideMessageBox() { messageBox.classList.remove('show'); }
    messageOkButton.addEventListener('click', hideMessageBox);

    // --- 初期化 ---
    function initializeBoardAndWallsState() {
        boardState = Array(ROWS).fill(null).map(() =>
            Array(COLS).fill(null).map(() => ({ piece: null, areaOwner: null }))
        );

        if (humanPlayerColor && cpuPlayerColor) {
            initialFixedPiecesCoordinates[humanPlayerColor].forEach(coord => {
                boardState[coord.row][coord.col].piece = humanPlayerColor;
            });
            initialFixedPiecesCoordinates[cpuPlayerColor].forEach(coord => {
                boardState[coord.row][coord.col].piece = cpuPlayerColor;
            });
        }


        walls = {
            horizontal: Array(ROWS - 1).fill(null).map(() => Array(COLS).fill(false)),
            vertical: Array(ROWS).fill(null).map(() => Array(COLS - 1).fill(false))
        };
        selectedPiece = null;
        lastMovedPieceCoordinates = null;
        movedPieceInfoForReselect = null;
        playerScore = 0;
        cpuScore = 0;
        currentPlacementTurnIndex = 0;
        // piecesPlacedCount は startGameButton の中で初期化
        if (humanPlayerColor && cpuPlayerColor) { // 安全のため
             piecesPlacedCount = { [humanPlayerColor]: 0, [cpuPlayerColor]: 0 };
        }
    }

    // --- 描画 ---
    function createBoardDOM() {
        boardElement.innerHTML = '';
        cellsDOM = [];
        for (let i = 0; i < ROWS * COLS; i++) {
            const cell = document.createElement('div');
            cell.classList.add('cell');
            cell.dataset.index = i;
            boardElement.appendChild(cell);
            cellsDOM.push(cell);
        }
    }

    function renderBoardAndWalls(cpuLastMove = null) {
        document.querySelectorAll('.wall-candidate').forEach(el => el.remove());
        // CPUハイライトクラスのクリア
        cellsDOM.forEach(cell => {
            cell.classList.remove('cpu-move-from', 'cpu-wall-top', 'cpu-wall-right', 'cpu-wall-bottom', 'cpu-wall-left');
            const pieceEl = cell.querySelector('.piece.cpu-move-to');
            if (pieceEl) pieceEl.classList.remove('cpu-move-to');
        });

        if (cpuLastMove && cpuLastMove.from) {
             cellsDOM[cpuLastMove.from.row * COLS + cpuLastMove.from.col].classList.add('cpu-move-from');
        }

        cellsDOM.forEach((cellDOM, index) => {
            cellDOM.innerHTML = '';
            let cellClasses = ['cell'];
            const row = Math.floor(index / COLS);
            const col = index % COLS;

            const areaOwner = boardState[row][col].areaOwner;
            if (areaOwner) {
                cellClasses.push(`area-${areaOwner}`);
            }
            if (cellsDOM[index].classList.contains('cpu-move-from')) { // cpu-move-from は維持
                cellClasses.push('cpu-move-from');
            }
            cellDOM.className = cellClasses.join(' ');


            const pieceColor = boardState[row][col].piece;
            if (pieceColor) {
                const pieceElement = document.createElement('div');
                pieceElement.classList.add('piece', `piece-${pieceColor}`);
                if (selectedPiece && selectedPiece.row === row && selectedPiece.col === col) {
                    pieceElement.classList.add('selected');
                }
                if (cpuLastMove && cpuLastMove.to && cpuLastMove.to.row === row && cpuLastMove.to.col === col) {
                    pieceElement.classList.add('cpu-move-to');
                }
                cellDOM.appendChild(pieceElement);
            }

            if (row > 0 && walls.horizontal[row - 1][col]) cellDOM.classList.add('wall-top');
            if (col > 0 && walls.vertical[row][col - 1]) cellDOM.classList.add('wall-left');
            if (row < ROWS - 1 && walls.horizontal[row][col]) cellDOM.classList.add('wall-bottom');
            if (col < COLS - 1 && walls.vertical[row][col]) cellDOM.classList.add('wall-right');

            if (cpuLastMove && cpuLastMove.wall) {
                const { type, r_idx, c_idx } = cpuLastMove.wall;
                if (type === 'horizontal') {
                    if (r_idx === row && c_idx === col) cellDOM.classList.add('cpu-wall-bottom');
                    if (r_idx === row - 1 && c_idx === col) cellDOM.classList.add('cpu-wall-top');
                } else if (type === 'vertical') {
                    if (r_idx === row && c_idx === col) cellDOM.classList.add('cpu-wall-right');
                    if (r_idx === row && c_idx === col - 1) cellDOM.classList.add('cpu-wall-left');
                }
            }

            if (gamePhase === `move_piece_player` && selectedPiece && currentTurnPlayerColor === humanPlayerColor) {
                const validMoves = getValidMoves(selectedPiece.row, selectedPiece.col, humanPlayerColor, boardState, walls);
                if (validMoves.find(m => m.row === row && m.col === col)) {
                    cellDOM.classList.add('valid-move');
                }
            }
        });

        if (gamePhase === `place_wall_player` && lastMovedPieceCoordinates && currentTurnPlayerColor === humanPlayerColor) {
            prepareWallPlacementUI(lastMovedPieceCoordinates.row, lastMovedPieceCoordinates.col);
        }
    }


    function renderScores() {
        playerScoreLabelElement.textContent = `あなた (${humanPlayerColor === "red" ? "赤" : "青"}): ${playerScore}`;
        cpuScoreLabelElement.textContent = `CPU (${cpuPlayerColor === "red" ? "赤" : "青"}): ${cpuScore}`;
    }

    function updateTurnDisplay() {
        let message = "";
        if (gamePhase === "game_over") return;
        if (gamePhase === "setup") {
            turnDisplayElement.textContent = "設定画面";
            return;
        }

        let turnPlayerForDisplayLogic;
        let colorForDisplayLogic;

        if (gamePhase === "placement") {
            if (!placementSequenceActual || currentPlacementTurnIndex >= placementSequenceActual.length) {
                message = "配置完了。ゲーム開始待ち...";
            } else {
                turnPlayerForDisplayLogic = placementSequenceActual[currentPlacementTurnIndex] === humanPlayerColor ? "あなた" : "CPU";
                colorForDisplayLogic = placementSequenceActual[currentPlacementTurnIndex];
                const piecesAlreadyPlacedByCurrent = piecesPlacedCount[colorForDisplayLogic];
                const pieceNumberToPlace = piecesAlreadyPlacedByCurrent + 1;
                message = `${turnPlayerForDisplayLogic} (${colorForDisplayLogic === "red" ? "赤" : "青"}) の追加駒配置 (${pieceNumberToPlace}個目/2個)。空きマスを選んでください。`;
            }
        } else {
            turnPlayerForDisplayLogic = currentTurnPlayerColor === humanPlayerColor ? "あなた" : "CPU";
            colorForDisplayLogic = currentTurnPlayerColor;
            switch (gamePhase) {
                case `select_piece_player`:
                    message = `${turnPlayerForDisplayLogic} (${colorForDisplayLogic === "red" ? "赤" : "青"}) の駒選択ターンです。`;
                    break;
                case `move_piece_player`:
                    message = `${turnPlayerForDisplayLogic} (${colorForDisplayLogic === "red" ? "赤" : "青"}) の駒移動ターンです。`;
                    break;
                case `place_wall_player`:
                    message = `${turnPlayerForDisplayLogic} (${colorForDisplayLogic === "red" ? "赤" : "青"}) の壁設置ターンです。`;
                    break;
                case "cpu_thinking":
                    message = `CPU (${colorForDisplayLogic === "red" ? "赤" : "青"}) が考えています...`;
                    break;
                default:
                    message = "状況不明";
            }
        }
        turnDisplayElement.textContent = message;
    }

    // --- ゲーム進行 ---
    function proceedToNextPlacementOrGame() {
        currentPlacementTurnIndex++;
        if (currentPlacementTurnIndex >= placementSequenceActual.length) {
            currentTurnPlayerColor = playerOrderSelect.value === "first" ? humanPlayerColor : cpuPlayerColor; // 設定画面での選択に基づく
            if (currentTurnPlayerColor === cpuPlayerColor) {
                gamePhase = "cpu_thinking";
                setTimeout(makeCpuMove, 100);
            } else {
                gamePhase = `select_piece_player`;
            }
        } else {
            currentTurnPlayerColor = placementSequenceActual[currentPlacementTurnIndex];
             if (currentTurnPlayerColor === cpuPlayerColor) {
                setTimeout(placePieceForCpu_PlacementPhase, 500);
            }
        }
        updateTurnDisplay();
        renderBoardAndWalls();
    }

    function placePieceForCpu_PlacementPhase() {
        if (gamePhase !== "placement" || currentTurnPlayerColor !== cpuPlayerColor) return;
        if (piecesPlacedCount[cpuPlayerColor] >= 2) {
            proceedToNextPlacementOrGame();
            return;
        }

        let placed = false;
        let attempts = 0;
        const centerMin = 1;
        const centerMax = 5;
        const availableCellsCenter = [];
        for(let r = centerMin; r <= centerMax; r++) {
            for(let c = centerMin; c <= centerMax; c++) {
                if (boardState[r][c].piece === null) {
                    availableCellsCenter.push({r,c});
                }
            }
        }

        if (availableCellsCenter.length > 0) {
            const randomCell = availableCellsCenter[Math.floor(Math.random() * availableCellsCenter.length)];
            boardState[randomCell.r][randomCell.c].piece = cpuPlayerColor;
            piecesPlacedCount[cpuPlayerColor]++;
            placed = true;
        } else { // 中央に置けなかった場合、全域で探す
            const availableCellsAll = [];
            for(let r = 0; r < ROWS; r++) {
                for(let c = 0; c < COLS; c++) {
                    if (boardState[r][c].piece === null) {
                        availableCellsAll.push({r,c});
                    }
                }
            }
            if (availableCellsAll.length > 0) {
                const randomCell = availableCellsAll[Math.floor(Math.random() * availableCellsAll.length)];
                boardState[randomCell.r][randomCell.c].piece = cpuPlayerColor;
                piecesPlacedCount[cpuPlayerColor]++;
                placed = true;
            }
        }


        if (placed) {
            proceedToNextPlacementOrGame();
        } else {
            showMessageBox("CPUが追加の駒を配置できる空きマスがありませんでした。ゲームを続行します。");
            proceedToNextPlacementOrGame();
        }
    }


    function switchTurn() {
        findAllAreasAndColor(); // エリア計算とスコア更新
        renderScores();        // スコア表示更新
        renderBoardAndWalls(); // 盤面をエリアハイライト込みで再描画

        if (checkGameOver()) {
            determineAndDisplayWinner(); // ゲーム終了判定と勝者表示
            return;
        }

        currentTurnPlayerColor = (currentTurnPlayerColor === humanPlayerColor) ? cpuPlayerColor : humanPlayerColor;
        movedPieceInfoForReselect = null;
        selectedPiece = null;

        if (currentTurnPlayerColor === cpuPlayerColor) {
            gamePhase = "cpu_thinking";
        } else {
            gamePhase = `select_piece_player`;
        }
        updateTurnDisplay();
        // renderBoardAndWalls(); // CPU思考前、またはプレイヤー選択前に再度描画 (ハイライトなし)
        if (gamePhase === "cpu_thinking") {
            setTimeout(makeCpuMove, 1000);
        } else {
            renderBoardAndWalls(); // プレイヤーのターン開始時に盤面をクリアに（移動候補ハイライトなど）
        }
    }

    // --- プレイヤー操作 ---
    function handleCellClick(event) {
        if (gamePhase === "game_over" || gamePhase === "cpu_thinking") return;

        const clickedCell = event.target.closest('.cell');
        if (!clickedCell) return;
        const index = parseInt(clickedCell.dataset.index);
        const row = Math.floor(index / COLS);
        const col = index % COLS;

        if (gamePhase === "placement") {
            if (currentPlacementTurnIndex < placementSequenceActual.length) { // まだ配置中か
                const currentPlacer = placementSequenceActual[currentPlacementTurnIndex];
                if (currentPlacer === humanPlayerColor) {
                    if (piecesPlacedCount[humanPlayerColor] < 2) {
                        if (boardState[row][col].piece === null) {
                            boardState[row][col].piece = humanPlayerColor;
                            piecesPlacedCount[humanPlayerColor]++;
                            proceedToNextPlacementOrGame();
                        } else {
                            showMessageBox("既に駒または壁があります。空きマスを選んでください。");
                        }
                    }
                }
            }
        } else if (currentTurnPlayerColor === humanPlayerColor) {
            if (gamePhase === `select_piece_player`) {
                handlePieceSelection(row, col, humanPlayerColor);
            } else if (gamePhase === `move_piece_player`) {
                handlePieceMovement(row, col, humanPlayerColor);
            }
        }
    }

    function handlePieceSelection(row, col, playerColor) {
        if (gamePhase !== `select_piece_player`) return; // 駒選択フェーズでのみ動作

        if (boardState[row][col].piece === playerColor) {
            if (selectedPiece && selectedPiece.row === row && selectedPiece.col === col) {
                selectedPiece = null;
            } else {
                selectedPiece = { row, col, color: playerColor };
                gamePhase = `move_piece_player`;
            }
        } else if (boardState[row][col].piece !== null) {
            showMessageBox("それは相手の駒です。");
            selectedPiece = null; // 選択解除
        } else {
            showMessageBox("自分の駒を選んでください。");
            selectedPiece = null; // 選択解除
        }
        renderBoardAndWalls();
        updateTurnDisplay();
    }


    function handlePieceMovement(targetRow, targetCol, playerColor) {
        if (!selectedPiece || gamePhase !== `move_piece_player`) return;
        const validMoves = getValidMoves(selectedPiece.row, selectedPiece.col, playerColor, boardState, walls);
        const isValid = validMoves.some(m => m.row === targetRow && m.col === targetCol);

        if (isValid) {
            movedPieceInfoForReselect = {
                originalRow: selectedPiece.row, originalCol: selectedPiece.col, pieceColor: playerColor,
                movedToRow: targetRow, movedToCol: targetCol
            };
            if (selectedPiece.row !== targetRow || selectedPiece.col !== targetCol) {
                 boardState[selectedPiece.row][selectedPiece.col].piece = null;
                 boardState[targetRow][targetCol].piece = playerColor;
            }
            lastMovedPieceCoordinates = { row: targetRow, col: targetCol };
            selectedPiece = null;
            gamePhase = `place_wall_player`;
        } else {
            showMessageBox("そこへは移動できません。");
        }
        renderBoardAndWalls();
        updateTurnDisplay();
    }

    function getValidWallPlacementLocations(pieceRow, pieceCol) {
        const locations = [];
        if (pieceRow > 0 && !walls.horizontal[pieceRow - 1][pieceCol]) {
            locations.push({ type: 'horizontal', r_idx: pieceRow - 1, c_idx: pieceCol, position: 'top' });
        }
        if (pieceRow < ROWS - 1 && !walls.horizontal[pieceRow][pieceCol]) {
            locations.push({ type: 'horizontal', r_idx: pieceRow, c_idx: pieceCol, position: 'bottom' });
        }
        if (pieceCol > 0 && !walls.vertical[pieceRow][pieceCol - 1]) {
            locations.push({ type: 'vertical', r_idx: pieceRow, c_idx: pieceCol - 1, position: 'left' });
        }
        if (pieceCol < COLS - 1 && !walls.vertical[pieceRow][pieceCol]) {
            locations.push({ type: 'vertical', r_idx: pieceRow, c_idx: pieceCol, position: 'right' });
        }
        return locations;
    }

    function prepareWallPlacementUI(pieceRow, pieceCol) {
        document.querySelectorAll('.wall-candidate').forEach(el => el.remove());
        const validWallLocations = getValidWallPlacementLocations(pieceRow, pieceCol);
        const cellElement = cellsDOM[pieceRow * COLS + pieceCol];
        if (!cellElement) return;

        validWallLocations.forEach(loc => {
            const wallCandidateDiv = document.createElement('div');
            wallCandidateDiv.classList.add('wall-candidate', loc.type, loc.position);
            wallCandidateDiv.dataset.wallType = loc.type;
            wallCandidateDiv.dataset.wallRowIndex = loc.r_idx;
            wallCandidateDiv.dataset.wallColIndex = loc.c_idx;
            wallCandidateDiv.addEventListener('click', (e) => {
                e.stopPropagation();
                if (currentTurnPlayerColor === humanPlayerColor && gamePhase === `place_wall_player`) {
                    const placed = handleWallPlacementAttempt(loc.type, parseInt(loc.r_idx), parseInt(loc.c_idx));
                    if (placed) {
                         switchTurn();
                    } else {
                        renderBoardAndWalls();
                        updateTurnDisplay();
                    }
                }
            });
            cellElement.appendChild(wallCandidateDiv);
        });
    }
    
    function handleWallPlacementAttempt(wallType, wallRowIndex, wallColIndex) {
        let wallPlaced = false;
        // TODO: ここで壁設置の可否判定（他の壁との交差、エリアの完全封鎖など）を厳密に行う
        // 今回は単純な空き判定のみ
        if (wallType === 'horizontal') {
            if (wallRowIndex >= 0 && wallRowIndex < ROWS - 1 && wallColIndex >= 0 && wallColIndex < COLS && !walls.horizontal[wallRowIndex][wallColIndex]) {
                walls.horizontal[wallRowIndex][wallColIndex] = true; wallPlaced = true;
            }
        } else { // vertical
            if (wallRowIndex >= 0 && wallRowIndex < ROWS && wallColIndex >= 0 && wallColIndex < COLS - 1 && !walls.vertical[wallRowIndex][wallColIndex]) {
                walls.vertical[wallRowIndex][wallColIndex] = true; wallPlaced = true;
            }
        }
        if (!wallPlaced && currentTurnPlayerColor === humanPlayerColor) {
             showMessageBox("そこには壁を設置できません。");
        }
        return wallPlaced;
    }


    // --- エリア判定とスコア ---
    function findAllAreasAndColor() {
        for (let r = 0; r < ROWS; r++) {
            for (let c = 0; c < COLS; c++) {
                boardState[r][c].areaOwner = null;
            }
        }
        playerScore = 0;
        cpuScore = 0;
        
        const visited = Array(ROWS).fill(null).map(() => Array(COLS).fill(false));

        for (let r_start = 0; r_start < ROWS; r_start++) {
            for (let c_start = 0; c_start < COLS; c_start++) {
                if (!visited[r_start][c_start]) {
                    const areaCells = [];
                    const piecesInArea = { [humanPlayerColor]: 0, [cpuPlayerColor]: 0 };
                    const q = [{ row: r_start, col: c_start }];
                    visited[r_start][c_start] = true;
                    let head = 0;
                    while(head < q.length){
                        const curr = q[head++];
                        areaCells.push(curr);
                        const piece = boardState[curr.row][curr.col].piece;
                        if (piece && piecesInArea[piece] !== undefined) piecesInArea[piece]++;

                        const directions = [
                            { dr: -1, dc: 0, wallCheck: (cr, cc) => cr > 0 && !walls.horizontal[cr - 1][cc] },
                            { dr: 1,  dc: 0, wallCheck: (cr, cc) => cr < ROWS - 1 && !walls.horizontal[cr][cc] },
                            { dr: 0,  dc: -1, wallCheck: (cr, cc) => cc > 0 && !walls.vertical[cr][cc - 1] },
                            { dr: 0,  dc: 1, wallCheck: (cr, cc) => cc < COLS - 1 && !walls.vertical[cr][cc] }
                        ];
                        for(const dir of directions){
                            const nextR = curr.row + dir.dr;
                            const nextC = curr.col + dir.dc;
                            if(nextR >= 0 && nextR < ROWS && nextC >= 0 && nextC < COLS && !visited[nextR][nextC]){
                                if(dir.wallCheck(curr.row, curr.col)){
                                    visited[nextR][nextC] = true;
                                    q.push({row: nextR, col: nextC});
                                }
                            }
                        }
                    }
                    
                    let owner = null;
                    if (piecesInArea[humanPlayerColor] > 0 && piecesInArea[cpuPlayerColor] === 0) owner = humanPlayerColor;
                    else if (piecesInArea[cpuPlayerColor] > 0 && piecesInArea[humanPlayerColor] === 0) owner = cpuPlayerColor;
                    
                    if (owner) {
                        areaCells.forEach(cell => boardState[cell.row][cell.col].areaOwner = owner);
                        if (owner === humanPlayerColor) playerScore += areaCells.length;
                        else cpuScore += areaCells.length;
                    }
                }
            }
        }
    }

    // --- ゲーム終了と勝敗判定 ---
    function checkGameOver() {
        let allPiecesInArea = true;
        let piecesOnBoardCount = 0;
        for (let r = 0; r < ROWS; r++) {
            for (let c = 0; c < COLS; c++) {
                const piece = boardState[r][c].piece;
                if (piece) {
                    piecesOnBoardCount++;
                    if (!boardState[r][c].areaOwner) {
                        allPiecesInArea = false;
                        break;
                    }
                }
            }
            if (!allPiecesInArea) break;
        }
        return piecesOnBoardCount === 8 && allPiecesInArea; // 固定4 + 追加4 = 8駒
    }

    function determineAndDisplayWinner() {
        // 最後の盤面描画（エリアハイライト込み）
        renderBoardAndWalls();

        let winnerMessage = "";
        if (playerScore > cpuScore) {
            winnerMessage = `あなたの勝利です！ (スコア: ${playerScore} vs ${cpuScore})`;
        } else if (cpuScore > playerScore) {
            winnerMessage = `CPUの勝利です！ (スコア: ${cpuScore} vs ${playerScore})`;
        } else {
            winnerMessage = "引き分けです。";
        }
        showMessageBox(winnerMessage);
        turnDisplayElement.textContent = "ゲーム終了！ " + winnerMessage;
        gamePhase = "game_over";
    }

    // --- 選び直し ---
    function handleReselectPiece() {
        if (currentTurnPlayerColor !== humanPlayerColor || gamePhase === "game_over" || gamePhase === "cpu_thinking" || gamePhase === "placement") return;

        if (gamePhase === `place_wall_player` && movedPieceInfoForReselect) {
            if(movedPieceInfoForReselect.originalRow !== movedPieceInfoForReselect.movedToRow || movedPieceInfoForReselect.originalCol !== movedPieceInfoForReselect.movedToCol) {
                boardState[movedPieceInfoForReselect.movedToRow][movedPieceInfoForReselect.movedToCol].piece = null;
            }
            boardState[movedPieceInfoForReselect.originalRow][movedPieceInfoForReselect.originalCol].piece = movedPieceInfoForReselect.pieceColor;
            
            document.querySelectorAll('.wall-candidate').forEach(el => el.remove());
            lastMovedPieceCoordinates = null;
        }
        selectedPiece = null;
        movedPieceInfoForReselect = null;
        gamePhase = `select_piece_player`;
        renderBoardAndWalls();
        updateTurnDisplay();
    }

    // --- リセット・開始 ---
    function resetToSetupScreen() {
        gameSetupScreen.style.display = 'flex';
        gameBoardScreen.style.display = 'none';
        gamePhase = "setup";
        selectedPiece = null;
        if (turnDisplayElement) updateTurnDisplay();
    }
    
    startGameButton.addEventListener('click', () => {
        cpuLevel = cpuLevelSelect.value;
        const playerOrder = playerOrderSelect.value;
        if (playerOrder === "first") {
            humanPlayerColor = "red";
            cpuPlayerColor = "blue";
        } else {
            humanPlayerColor = "blue";
            cpuPlayerColor = "red";
        }

        placementSequenceActual = [];
        if (playerOrder === "first") { // 人間先手
            placementSequenceActual.push(humanPlayerColor); // H
            placementSequenceActual.push(cpuPlayerColor);   // C
            placementSequenceActual.push(cpuPlayerColor); // H
            placementSequenceActual.push(humanPlayerColor);   // C
        } else { // CPU先手
            placementSequenceActual.push(cpuPlayerColor);   // C
            placementSequenceActual.push(humanPlayerColor); // H
            placementSequenceActual.push(humanPlayerColor);   // C
            placementSequenceActual.push(cpuPlayerColor); // H
        }


        gameSetupScreen.style.display = 'none';
        gameBoardScreen.style.display = 'block';
        
        initializeBoardAndWallsState();
        if (!cellsDOM.length) createBoardDOM();
        
        gamePhase = "placement";
        currentTurnPlayerColor = placementSequenceActual[0];

        if (currentTurnPlayerColor === cpuPlayerColor && piecesPlacedCount[cpuPlayerColor] < 2) {
            setTimeout(placePieceForCpu_PlacementPhase, 500);
        }
        
        renderBoardAndWalls();
        updateTurnDisplay();
        renderScores();
    });

    resetButtonElement.addEventListener('click', resetToSetupScreen);
    reselectButtonElement.addEventListener('click', handleReselectPiece);
    boardElement.addEventListener('click', handleCellClick);

    // --- CPUロジック (前回提示のものを流用) ---
    const CPU_PLAYERS_FOR_EVAL = ["red", "blue"];

    function getShortestDistancesToAllPieces(fromR, fromC, currentBoardState, currentWalls) {
        const distances = {};
        PLAYERS.forEach(p => distances[p] = Infinity);
        
        const q = [{r: fromR, c: fromC, dist: 0}];
        const visited = new Set([`${fromR},${fromC}`]);
        let head = 0;
        let piecesFoundCount = 0;

        while(head < q.length) {
            const curr = q[head++];
            const pieceAtCurr = currentBoardState[curr.r][curr.c].piece;
            if (pieceAtCurr && distances[pieceAtCurr] === Infinity) {
                 distances[pieceAtCurr] = curr.dist;
                 piecesFoundCount++;
                 if (piecesFoundCount >= PLAYERS.length) break;
            }
            if (curr.dist > ROWS * COLS) continue;

            const directions = [
                { dr: -1, dc: 0, wallCheck: (r, c) => r > 0 && !currentWalls.horizontal[r - 1][c] },
                { dr: 1,  dc: 0, wallCheck: (r, c) => r < ROWS - 1 && !currentWalls.horizontal[r][c] },
                { dr: 0,  dc: -1, wallCheck: (r, c) => c > 0 && !currentWalls.vertical[r][c - 1] },
                { dr: 0,  dc: 1, wallCheck: (r, c) => c < COLS - 1 && !currentWalls.vertical[r][c] }
            ];

            for (const dir of directions) {
                const nextR = curr.r + dir.dr;
                const nextC = curr.c + dir.dc;
                const nextKey = `${nextR},${nextC}`;

                if (nextR >= 0 && nextR < ROWS && nextC >= 0 && nextC < COLS && !visited.has(nextKey)) {
                    if (dir.wallCheck(curr.r, curr.c)) {
                        visited.add(nextKey);
                        q.push({r: nextR, c: nextC, dist: curr.dist + 1});
                    }
                }
            }
        }
        return distances;
    }

    function evaluateBoard(currentBoardState, currentWalls, perspectivePlayerColor) {
        let evaluation = 0;
        const opponentColor = perspectivePlayerColor === humanPlayerColor ? cpuPlayerColor : humanPlayerColor;

        const tempScores = { [humanPlayerColor]: 0, [cpuPlayerColor]: 0 };
        const tempVisitedAreas = Array(ROWS).fill(null).map(() => Array(COLS).fill(false));
        const tempBoardAreaOwners = Array(ROWS).fill(null).map(() => Array(COLS).fill(null));

        for (let r_start = 0; r_start < ROWS; r_start++) {
            for (let c_start = 0; c_start < COLS; c_start++) {
                if (!tempVisitedAreas[r_start][c_start]) {
                    const areaCells = [];
                    const piecesInArea = { [humanPlayerColor]: 0, [cpuPlayerColor]: 0 };
                    const q = [{ row: r_start, col: c_start }];
                    tempVisitedAreas[r_start][c_start] = true;
                    let head = 0;
                    while(head < q.length){
                        const curr = q[head++];
                        areaCells.push(curr);
                        const piece = currentBoardState[curr.row][curr.col].piece;
                        if (piece && piecesInArea[piece] !== undefined) piecesInArea[piece]++;
                        const directions = [
                            { dr: -1, dc: 0, wallCheck: (cr, cc) => cr > 0 && !currentWalls.horizontal[cr - 1][cc] },
                            { dr: 1,  dc: 0, wallCheck: (cr, cc) => cr < ROWS - 1 && !currentWalls.horizontal[cr][cc] },
                            { dr: 0,  dc: -1, wallCheck: (cr, cc) => cc > 0 && !currentWalls.vertical[cr][cc - 1] },
                            { dr: 0,  dc: 1, wallCheck: (cr, cc) => cc < COLS - 1 && !currentWalls.vertical[cr][cc] }
                        ];
                        for(const dir of directions){
                            const nextR = curr.row + dir.dr;
                            const nextC = curr.col + dir.dc;
                            if(nextR >= 0 && nextR < ROWS && nextC >= 0 && nextC < COLS && !tempVisitedAreas[nextR][nextC]){
                                if(dir.wallCheck(curr.row, curr.col)){
                                    tempVisitedAreas[nextR][nextC] = true;
                                    q.push({row: nextR, col: nextC});
                                }
                            }
                        }
                    }
                    let owner = null;
                    if (piecesInArea[humanPlayerColor] > 0 && piecesInArea[cpuPlayerColor] === 0) owner = humanPlayerColor;
                    else if (piecesInArea[cpuPlayerColor] > 0 && piecesInArea[humanPlayerColor] === 0) owner = cpuPlayerColor;
                    if (owner) {
                        areaCells.forEach(cell => tempBoardAreaOwners[cell.row][cell.col] = owner);
                        tempScores[owner] += areaCells.length;
                    }
                }
            }
        }
        evaluation += tempScores[perspectivePlayerColor] * 10;
        evaluation -= tempScores[opponentColor] * 10;


        for (let r = 0; r < ROWS; r++) {
            for (let c = 0; c < COLS; c++) {
                if (currentBoardState[r][c].piece === null && tempBoardAreaOwners[r][c] === null) {
                    const distances = getShortestDistancesToAllPieces(r, c, currentBoardState, currentWalls);
                    const myDist = distances[perspectivePlayerColor];
                    const opDist = distances[opponentColor];

                    if (myDist < opDist && myDist !== Infinity) {
                        evaluation += 9;
                    } else if (opDist < myDist && opDist !== Infinity) {
                        evaluation -= 9;
                    }
                }
            }
        }
        return evaluation;
    }
    
    function getValidMoves(startRow, startCol, playerColorForPiece, boardStateForEval, wallsForEval) {
        const possibleMoves = [];
        const q = [{ r: startRow, c: startCol, dist: 0 }];
        const visited = new Set();
        
        if (boardStateForEval[startRow][startCol].piece === playerColorForPiece) {
             possibleMoves.push({ row: startRow, col: startCol }); // 0マス移動
             visited.add(`${startRow},${startCol}`);
        }

        let head = 0;
        while (head < q.length) {
            const { r, c, dist } = q[head++];
            if (dist < 2) {
                const directions = [
                    { dr: -1, dc: 0, wallCheck: (cr, cc) => cr > 0 && !wallsForEval.horizontal[cr - 1][cc] },
                    { dr: 1,  dc: 0, wallCheck: (cr, cc) => cr < ROWS - 1 && !wallsForEval.horizontal[cr][cc] },
                    { dr: 0,  dc: -1, wallCheck: (cr, cc) => cc > 0 && !wallsForEval.vertical[cr][cc - 1] },
                    { dr: 0,  dc: 1, wallCheck: (cr, cc) => cc < COLS - 1 && !wallsForEval.vertical[cr][cc] }
                ];
                for (const dir of directions) {
                    const nextR = r + dir.dr;
                    const nextC = c + dir.dc;
                    const nextKey = `${nextR},${nextC}`;
                    if (nextR >= 0 && nextR < ROWS && nextC >= 0 && nextC < COLS && !visited.has(nextKey)) {
                        if (dir.wallCheck(r, c)) {
                            if (boardStateForEval[nextR][nextC].piece === null) {
                                visited.add(nextKey);
                                q.push({ r: nextR, c: nextC, dist: dist + 1 });
                                possibleMoves.push({ row: nextR, col: nextC });
                            }
                        }
                    }
                }
            }
        }
        return possibleMoves;
    }

    function getAllPossibleMoves(playerColToSimulate, currentBoardState, currentWalls) {
        const possibleMovesFull = [];
        const playerPieces = [];
        for (let r = 0; r < ROWS; r++) {
            for (let c = 0; c < COLS; c++) {
                if (currentBoardState[r][c].piece === playerColToSimulate) {
                    playerPieces.push({row: r, col: c});
                }
            }
        }

        if (playerPieces.length === 0) return []; // 動かせる駒がない

        playerPieces.forEach(piecePos => {
            const pieceValidMoves = getValidMoves(piecePos.row, piecePos.col, playerColToSimulate, currentBoardState, currentWalls);
            pieceValidMoves.forEach(move => {
                const wallPlacementLocations = getValidWallPlacementLocations(move.row, move.col);
                if (wallPlacementLocations.length === 0) {
                } else {
                    wallPlacementLocations.forEach(wallLoc => {
                        possibleMovesFull.push({
                            pieceMove: { from: { ...piecePos }, to: { ...move } },
                            wallPlacement: { type: wallLoc.type, r_idx: wallLoc.r_idx, c_idx: wallLoc.c_idx }
                        });
                    });
                }
            });
        });
        return possibleMovesFull;
    }

    function makeCpuMove() {
        if (gamePhase !== "cpu_thinking") return;

        let bestMoveSet = [];
        let bestEval = -Infinity;
        const possibleCpuMoves = getAllPossibleMoves(cpuPlayerColor, boardState, walls);

        if (possibleCpuMoves.length === 0) {
            showMessageBox("CPUが指せる手がありません。ゲームに問題がある可能性があります。");
            // ゲームを終了させるか、プレイヤーにターンを渡す
            // ここではプレイヤーにターンを渡して続行を試みる
            console.error("CPU has no moves! This shouldn't happen.");
            switchTurn();
            return;
        }

        for (const move of possibleCpuMoves) {
            const tempBoard = JSON.parse(JSON.stringify(boardState));
            const tempWalls = JSON.parse(JSON.stringify(walls));

            if (move.pieceMove.from.row !== move.pieceMove.to.row || move.pieceMove.from.col !== move.pieceMove.to.col) {
                tempBoard[move.pieceMove.from.row][move.pieceMove.from.col].piece = null;
                tempBoard[move.pieceMove.to.row][move.pieceMove.to.col].piece = cpuPlayerColor;
            }

            if (move.wallPlacement) {
                // 壁設置の可否をチェックする仮関数（実際はもっと複雑）
                // ここでは単純に空いていれば置けるとするが、交差や完全封鎖は考慮しない
                let canPlaceTempWall = false;
                if (move.wallPlacement.type === 'horizontal') {
                    if (tempWalls.horizontal[move.wallPlacement.r_idx] && tempWalls.horizontal[move.wallPlacement.r_idx][move.wallPlacement.c_idx] === false) {
                        tempWalls.horizontal[move.wallPlacement.r_idx][move.wallPlacement.c_idx] = true;
                        canPlaceTempWall = true;
                    }
                } else { // vertical
                     if (tempWalls.vertical[move.wallPlacement.r_idx] && tempWalls.vertical[move.wallPlacement.r_idx][move.wallPlacement.c_idx] === false) {
                        tempWalls.vertical[move.wallPlacement.r_idx][move.wallPlacement.c_idx] = true;
                        canPlaceTempWall = true;
                    }
                }
                if (!canPlaceTempWall || move.wallPlacement == null) continue; // 壁が置けない手はスキップ（ただし、wallPlacement:nullの手もある）
            }


            let currentMoveEval;
            if (cpuLevel === "beginner") {
                currentMoveEval = evaluateBoard(tempBoard, tempWalls, cpuPlayerColor);
            } else {
                let worstEvalForCpuAfterPlayerReply = Infinity;
                const possiblePlayerReplies = getAllPossibleMoves(humanPlayerColor, tempBoard, tempWalls);
                
                if (possiblePlayerReplies.length === 0) {
                    worstEvalForCpuAfterPlayerReply = evaluateBoard(tempBoard, tempWalls, cpuPlayerColor);
                } else {
                    for (const playerReply of possiblePlayerReplies) {
                        const tempBoardAfterPlayer = JSON.parse(JSON.stringify(tempBoard));
                        const tempWallsAfterPlayer = JSON.parse(JSON.stringify(tempWalls));
                        if (playerReply.pieceMove.from.row !== playerReply.pieceMove.to.row || playerReply.pieceMove.from.col !== playerReply.pieceMove.to.col) {
                            tempBoardAfterPlayer[playerReply.pieceMove.from.row][playerReply.pieceMove.from.col].piece = null;
                            tempBoardAfterPlayer[playerReply.pieceMove.to.row][playerReply.pieceMove.to.col].piece = humanPlayerColor;
                        }
                        if (playerReply.wallPlacement) {
                             let canPlacePlayerWall = false;
                            if (playerReply.wallPlacement.type === 'horizontal') {
                                if (tempWallsAfterPlayer.horizontal[playerReply.wallPlacement.r_idx] && tempWallsAfterPlayer.horizontal[playerReply.wallPlacement.r_idx][playerReply.wallPlacement.c_idx] === false) {
                                     tempWallsAfterPlayer.horizontal[playerReply.wallPlacement.r_idx][playerReply.wallPlacement.c_idx] = true;
                                     canPlacePlayerWall = true;
                                }
                            } else {
                                if (tempWallsAfterPlayer.vertical[playerReply.wallPlacement.r_idx]&& tempWallsAfterPlayer.vertical[playerReply.wallPlacement.r_idx][playerReply.wallPlacement.c_idx] === false) {
                                    tempWallsAfterPlayer.vertical[playerReply.wallPlacement.r_idx][playerReply.wallPlacement.c_idx] = true;
                                    canPlacePlayerWall = true;
                                }
                            }
                            if(!canPlacePlayerWall || playerReply.wallPlacement == null) continue; // プレイヤーが壁置けないならその手は考慮外
                        }
                        const evalAfterPlayerReply = evaluateBoard(tempBoardAfterPlayer, tempWallsAfterPlayer, cpuPlayerColor);
                        if (evalAfterPlayerReply < worstEvalForCpuAfterPlayerReply) {
                            worstEvalForCpuAfterPlayerReply = evalAfterPlayerReply;
                        }
                    }
                }
                currentMoveEval = worstEvalForCpuAfterPlayerReply;
            }

            if (currentMoveEval > bestEval) {
                bestEval = currentMoveEval;
                bestMoveSet = [move];
            } else if (currentMoveEval === bestEval) {
                bestMoveSet.push(move);
            }
        }
        
        if (bestMoveSet.length === 0) { // 万が一、有効な手が見つからなかった場合
            showMessageBox("CPUの思考でエラーが発生しました。ランダムな手を指します。");
            // 完全にランダムな手を指すか、最初の可能な手を指す
            const emergencyMove = possibleCpuMoves[Math.floor(Math.random() * possibleCpuMoves.length)] || possibleCpuMoves[0];
            if (emergencyMove) bestMoveSet.push(emergencyMove);
            else { // これもなければ本当に手がない
                console.log("cant find move");
                switchTurn(); return;
            }
        }

        const finalChosenMove = bestMoveSet[Math.floor(Math.random() * bestMoveSet.length)];

        const cpuMovedFrom = { ...finalChosenMove.pieceMove.from };
        const cpuMovedTo = { ...finalChosenMove.pieceMove.to };
        let cpuPlacedWallInfo = null;

        if (cpuMovedFrom.row !== cpuMovedTo.row || cpuMovedFrom.col !== cpuMovedTo.col) {
            boardState[cpuMovedFrom.row][cpuMovedFrom.col].piece = null;
            boardState[cpuMovedTo.row][cpuMovedTo.col].piece = cpuPlayerColor;
        }
        lastMovedPieceCoordinates = { ...cpuMovedTo };

        if (finalChosenMove.wallPlacement) {
            const placedSuccessfully = handleWallPlacementAttempt(
                finalChosenMove.wallPlacement.type,
                finalChosenMove.wallPlacement.r_idx,
                finalChosenMove.wallPlacement.c_idx
            );
            if (placedSuccessfully) {
                 cpuPlacedWallInfo = { ...finalChosenMove.wallPlacement };
            }
        }
        
        renderBoardAndWalls({ from: cpuMovedFrom, to: cpuMovedTo, wall: cpuPlacedWallInfo });
        
        setTimeout(() => {
            // ハイライトを消すために再度描画する前に、エリア計算とスコア更新を挟む
            findAllAreasAndColor();
            renderScores();
            renderBoardAndWalls(); // 通常描画に戻す
            switchTurn();
        }, 1500);

    }

    resetToSetupScreen();
});