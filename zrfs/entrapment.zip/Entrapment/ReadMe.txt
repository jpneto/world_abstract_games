*****************************************************************
***** Entrapment for Zillions of Games                      *****
***** v1.12                                                 *****
***** Invented by:                                          *****
***** Rich Gowell      --- http://www.GowellGames.com       *****
*****                                                       *****
***** ZRF by:                                               *****
***** Jens Markmann    --- http://cruise.de/jens.markmann/  *****
*****************************************************************

-------------
Requirements:
-------------

This ZRF requires Zillions of Games v1.1.1 or later.
To display the boards, a screen resolution of at least 1024x768 is recommended.

--------------------------
Installation instructions:
--------------------------

If you want to play alone, you can unzip the archive to any folder, as long as your zip program
puts all image files in the correct subfolders (in WinZIP, the option 'Use Folder Names' in the
Extract dialog must be checked).

However, when playing online at a Net session, you must ensure that Zillions of Games finds the
Entrapment ZRF by placing it in the Rules folder. You should place the image files in Zillions'
respective subfolders in this case.

Example:
Assume you installed Zillions to C:\ProgramFiles\Zillions\
Then Entrapment.ZRF must reside in C:\ProgramFiles\Zillions\Rules\
and all BMPs must be in C:\ProgramFiles\Zillions\Images\_Custom\Entrapment\

--------------------
Troubleshooting FAQ:
--------------------

Q: When trying to load the ZRF, Zillions displays a parse error concerning image files.
A: You probably do not possess the latest version of Zillions. Versions before v1.1.1 did not
   support multiple piece sets. Please update your program at www.zillions-of-games.com.

Q: When trying to load the ZRF, Zillions tells me it can't find an image.
A: Your images are not stored in the right directory, probably because no folders were
   created during the unzipping. Refer to installation instructions.

Q: I get challenged at a Net session, but Zillions can't find Entrapment.ZRF!
A: When getting challenged, Zillions looks for ZRF only in its Rules folder. Refer to installation
   instructions.

Q: During a Net session I just placed a Barrier, but my opponent claims the move didn't arrive,
   and now the game seems to be frozen.
A: It is frozen; alas, this game cannot be continued. This problem is caused by entering moves
   *too fast*. Your opponent's Zillions is unable to process two moves in a row when they come in
   without any pause between them. Avoid this problem in the future by waiting a few seconds after
   entering your first move.

Q: I'm disappointed by the quality of the AI, even at high thinking times.
   Is there a way to improve it?
A: You might want to try one of the variants, especially those with more Barriers, less Roamers
   or a smaller board. Zillions can play them better than the original Entrapment.
