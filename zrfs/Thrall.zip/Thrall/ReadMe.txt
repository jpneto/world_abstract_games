Thrall v1.0
-----------
Created by L. Lynn Smith, October 2005


Thrall is a game for two players on a field composed of hexagon and triangle cells.

The FIRST player has a black STONE and the SECOND player a white STONE.  There is a common pool of red PINs.

At a turn, each player must move their STONE then place a PIN. There is no passing.

The STONE slides through directly adjacent vacant hexagon cells. Except for the first turn when it is merely placed on a vacant hexagon cell of the field.  Hexagon cells are considered joined by their touching corners.  The STONE is not permitted to slide between two adjacent triangle cells which are occupied.

The PIN is placed on any vacant triangle cell.

The game is lost by the player unable to move their STONE.
     

----------------------------------------------------------------
To play:

Double click the Thrall icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Thrall.zrf" in the Open dialog and click "Open"

Thrall.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
		  <http://www.zillions-of-games.com> 

 
