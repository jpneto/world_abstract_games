Axiomatic Thrall (version 1.0)
------------------------------
Greg Schmidt (gschmidt958@yahoo.com)

Thrall created by L. Lynn Smith.
This "Axiomatic Thrall" implementation by Greg Schmidt.
Graphics by Mats W (K�lroten) & Greg Schmidt.
Game variations conceived by Mats W (K�lroten), Alfred Pfeiffer, and Greg Schmidt.

Updated October 27, 2007: now using version 1.3 of the Axiom Development Kit


Axiomatic Thrall is a game for two players on a field composed of hexagon and triangle cells.

The FIRST player has a black STONE and the SECOND player a white STONE.  There is a common pool of red PINs.

At a turn, each player must move their STONE then place a PIN. There is no passing.

The STONE slides through directly adjacent vacant hexagon cells. Except for the first turn when it is merely
placed on a vacant hexagon cell of the field.  Hexagon cells are considered joined by their touching corners.
The STONE is not permitted to slide between two adjacent triangle cells which are occupied.

The PIN is placed on any vacant triangle cell.

The game is lost by the player unable to move their STONE.

Axiomatic Thrall uses the "Axiom" Meta-game engine.

----------------------------------------------------------------
This game requires the "Zillions of Games" program.  Please
visit <http://www.zillions-of-games.com> for details.
----------------------------------------------------------------