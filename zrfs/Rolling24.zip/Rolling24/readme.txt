Roll-Ing to Four

Copyright June 2003
by Ingo Althofer and Thomas Rolle
althofer @ minet.uni-jena.de


Try to roll four of your balls into a row, 
either horizontally or vertically or diagonally.

Players Red and Blue roll in turn.
Red balls roll upwards only, one step either
to the north or the northwest or the northeast.
Blue balls roll downwards only, one step either
to the south or the southwest or the southeast.
Balls may roll to free squares only. Passing is
not allowed. The game will end in a win for
for one side, because players can not block each
other permanently in the center - at least from
this starting position.

The first idea for "Roll-Ing" rose when
we had fun with H.D. Ruderman's nice
little game "Nu TicTacToe" which is also
realized in the basic Zillions collection.

On strategy: 
Don't make the mistake to roll away
your central pieces. Instead, try to
clump all your balls in one big cluster.
Then a winning combination will follow
almost automatically. Ok, ok, the opponent may 
try the same. But ... at least Zillions does 
not understand this plan - see the screenshot.
