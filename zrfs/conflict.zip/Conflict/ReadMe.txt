Conflict
--------
Invented and implemented by Alexander Stevens, September 2000.


The objective of Conflict is to capture all your opponents, 
"Myrmidons" (their simple soldier piece). Among Myrmidons, you 
will also be provided with "Bucklers", which cannot capture nor 
be captured, and "Assassins", whom are limited in range, but can 
jump over other pieces. 

The rule in Conflict that makes it different from most games of 
this style is that, Myrmidons cannot capture, unless they are 
initially defended. That is to say, you cannot capture unless 
the Myrmidon you wish to capture with is in an unobstructed line 
with another friendly Myrmidon. This is called the support rule, 
and gives the game a greater need for defensive play. A Myrmidon 
that is isolated from another Myrmidon is a valuable target for 
your opponent. 

In addition to those basic rules, each player is allowed to 
liberally set up their pieces at the start of the game with in 
their first four rows. 

From my observations, Zillions Of Games plays this game fairly 
well with very few AI quirks. 


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Conflict.zrf" in the Open dialog and click "Open"

Conflict.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

