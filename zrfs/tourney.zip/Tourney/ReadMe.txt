Tourney
-------
Created by Chris Huntoon, May 2001.


Checkers played with a Knight-like move. 
�
Chargers move like a Knight in Chess, except that they can't jump 
over other pieces. They step outward on a row or column, then 
diagonally outward one step. If something is adjacent to a Charger 
on a row or column, it can't move in that direction. They are 
forbidden from moving backwards. 
�
Landing on an enemy piece captures it. Capturing is mandatory, 
and you must keep moving and capturing as long as it is possible. 
�
When your Charger reaches the other end of the board, it becomes 
a Champion and can then also move backwards. 
�
There are three different ways to win: be the first to return a 
Champion to your own home rank, capture all your opponent's pieces, 
or stalemate the opponent so he has no moves. 


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Tourney.zrf" in the Open dialog and click "Open"

Tourney.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

