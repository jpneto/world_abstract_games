
Fission
-------------------------------------------------------------------
***** Requires Zillions version 1.3 or higher to play. *****
-------------------------------------------------------------------
Designed by Robert A. Kraus in 2000.
Implemented by Robert A. Kraus for Zillions of Games in 2002
E-mail:  BobKraus@csi.com
WebSite:   http://www.geocities.com/bob_kraus_2000
-------------------------------------------------------------------
The White and Black players each start with 14 Atoms of their color.
Click the green  'start thinking'  circle to automatically randomize the starting
position of atoms. (In the Fixed-Start variants there is no randomizing.)
The object of the game is to get rid of your opponent's atoms.
(In the Losing variants the object is to get rid of your own atoms.)
Each player can move an atom of his color in any direction, but it must keep moving
through all empty squares until it hits another atom or comes to rest against a wall.
If it hits another atom  (of either color)  it explodes and destroys all atoms of both
players which are adjacent to it as well as itself. If it hits a wall it does not explode.
If a move by either player leaves atoms belonging to only one player, that player wins.. 
(In the Losing variants that player loses.)
If the last move leaves an empty board it is a draw. 
If each player has only one atom left it is a draw.
If a player has atoms left but has no legal moves he is stalemated and it counts as a draw.
-------------------------------------------------------------------
You should have extracted this zip file preserving path names,
(Check "Use Folder Names" box in Win-Zip Extract Files Dialog Box);
and you should extract to your Zillions Rules folder.This will
create a Fission folder within the Rules folder.
-------------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Fission" folder in the Open dialog and click "Open"
4. Select "Fission.zrf" in the Open dialog and click "Open"
-------------------------------------------------------------------
Fission.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
-------------------------------------------------------------------
