Force
-----
Created by Chris Huntoon, July 2000.
Updated October 2000: fixed problems with Zillions v1.2
                      and image problem with Windows NT/2000.


Individually, a Man can move one space in any direction. When 
combined with other Men of the same side to form a connected line, 
all the pieces in that line can move in the direction it 
delineates. Also, the line moves, forward or backward, the number 
of spaces equal to the number of pieces it contains, i.e. a line 
of three Men would move together three spaces. To move a line, 
click on the last piece in that line, which then moves to the 
head of the line.

Captures are made by landing on opponent's pieces. Lines make 
multiple captures possible.

A Man that reaches the far end of the board becomes a Hero. 
Heroes function the same as regular Men. However, the first player 
to have two Heroes on the board at the same time, wins. If one 
side is reduced to less then two pieces, they automatically 
forfeit the game.


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Force.zrf" in the Open dialog and click "Open"

Force.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

