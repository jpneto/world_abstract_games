Ugly Duck

(c) 2001  W. D. Troyka


Object:  Promote your ugly duckling to a beautiful swan, then swim 
triumphantly home.  Ugly ducks move forward or diagonally forward and 
capture diagonally forward.  Upon reaching the far side of the pond, 
they become swans and reverse directions.  You win when a swan returns 
to your side of the pond.
	
This is a variant of the game Breakthrough, also available on Zillions.

You should extract the game from the downloaded zip file 
preserving path names. 

----------------------------------------------------------------
To play:

Double click the UglyDuck icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "UglyDuck.zrf" in the Open dialog and click "Open"

UglyDuck.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 