Groups
Game (c) 1998 Richard Hutnik
richardhutnik@hotmail.com
Invented in the early to mid-1980s

Rules file and graphics (c) 2002  W. D. Troyka.
dtroyka@justice.com

Rules modified to add jumping move by Richard Hutnik
richardhutnik@hotmail.com


Groups is played on an 8x8 board.  Each player has six pieces.  The board is empty at the beginning of the game.  The players take turns dropping their pieces onto the 4x4 square in the middle of the board.  White drops its pieces only onto the checker pattern defined by c4, c6, d3, d5, e4, e6, f4, and f6.  Black drops its pieces only onto the other center squares.  After all twelve pieces are placed on the board, the players take turn moving a piece one space in any direction -- orthogonal or diagonal -- to an empty square.  The first player to connect all six pieces orthogonally is the winner.  In a winning connection, it is possible to move from any piece to any other friendly piece by moving only through orthogonally adjacent friendly pieces.

Groups is related to Lines of Action, with the differences being that pieces in Groups move only one space, 
only orthogonal connections count, there are no captures, and the game begins with a drop phase.  The game 
also bears a resemblance to Teeko, with the movement of pieces to attain a configuration, although in Groups 
a winning configuration can take any form provided all pieces are orthogonally connected.

In the Fixed Set-up variants, the pieces begin the game already on the board and there is no drop phase.  
In the Queen variants, all pieces can move like a Queen to an empty square.
In the Jumping variants, all pieces can jump over a piece of either player.

For more information on Groups, please visit Richard Hutnik's web site at:
http://www.geocities.com/TimesSquare/Fortress/7537/index.html.


----------------------------------------------------------------

To play:

Double click the Groups game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Groups.zrf" in the Open dialog and click "Open"

Groups.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play 
any number of games against the computer or over the Internet. 
Zillions of Games can be purchased online.  For more information,
please visit the Zillions of Games website:

              <http://www.zillions-of-games.com> 
