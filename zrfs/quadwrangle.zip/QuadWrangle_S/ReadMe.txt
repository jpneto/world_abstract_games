Quad Wrangle (small version)
----------------------------
Invented and implemented by Keith Carter, October 2001.
Updated February 21, 2009: more efficient drop code


Board and piece graphics by Keith Carter (updated October 2005).
Scoring system based on the work of the innovative Karl Scherer 
with some advice from W.D. Troyka and code streamlining by Ed van Zon. 
Please send comments and advice to litigation.technology@gmail.com 


The object of the game is to have the most pieces on the board 
when the board is full. � 
Quad Wrangle is a conversion game derived from Blobs that comes 
with Zillions. � An added feature is in game scoring. 

Play is very dynamic. � Interaction is immediate and each turn presents 
the player with a number of critical options. � The balance of the game 
can change with any move. � Zillions plays a very sharp game. 


The game is packaged to give the player options. � There are two zip files. � 
There's another QuadWrangle_L.zip using a large version of the 
game graphics. The Zillions window will nearly fill a 1024 x 768 display. � 
QuadWrangle_S.zip (the one this ReadMe is in) uses a smaller graphics set 
that fits on a 640 x 480 display. � 
Each zip file contains two ZRF files, one with scoring and one without 
because scoring reduces the number of positions Zillions examines 
in timed moves by 30% to 50% depending on the time allowed. 


----------------------------------------------------------------
To play:

Double click the QuadW_S (or QuadW_S_ns) icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "QuadW_S.zrf" or "QuadW_S_ns.zrf" in the Open dialog 
   and click "Open"

QuadW_S.zrf and QuadW_S_ns.zrf are rules files used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
