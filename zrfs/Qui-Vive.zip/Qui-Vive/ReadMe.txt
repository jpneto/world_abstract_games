Qui Vive
--------
Invented by Eugene de Wolf
Implemented by David F. Leigh, September 2005

There is another game by the name Quivive (one word). This isn't it.

I first saw Qui Vive in a book on programming the TI-99/4a in 1983.
I've never seen it implemented anywhere else. It's a shame, because it's a
nice little game. I've probably re-implemented it seven times. The Zillions 
AI plays a very nice game if you crank up the computer opponent strength 
and variety.

Each player has five pieces and begins the game by dropping them on the 5x5 
board. Once all pieces are placed then the players take turns moving them.
Pieces can be moved to any vacant space on the board.

The object is to arrange your own pieces in one of five patterns.

. . . . .
. . X . .
. X X X .
. . X . .
. . . . . a plus

. . . . .
. X . X .
. . X . .
. X . X . 
. . . . . a cross

X . . . .
. X . . .
. . X . .
. . . X .
. . . . X a straight line (diagonal or orthagonal)

. . . . .
X . . . X
. X . X .
. . X . .
. . . . . a "V" or "wing"

. . . . .
. X . . .
. X . . .
. X X X .
. . . . . an "L"

These patterns can be in any orientation, anywhere on the board. 
The phrase "to be on the qui vive" means to be on the alert, which
makes it an appropriate name for the game. That it has so many 
winning patterns means that you can easily get "caught" by
an opponent who prepares two winning positions, either of which can 
be completed by a single move. Of course, this is the strategy
you should adopt yourself. Don't get yourself into a situation where
you are reacting to your opponent's moves: that's a sure recipe for
defeat.

The file contains three variants:

Qui-Vive:  The original rules. 

	This original game can be over pretty quick. A typical game
	lasts anywhere from 6 to 16 moves. the following variants
	restrict piece movement to improve strategy and forward-thinking
	during the initial drop phase, and to draw out game play in the
	movement phase:

King-moves only:  Pieces move one square in any direction.
Queen-moves only:  Pieces move like a chess queen.

----------------------------------------------------------------
Reference:
Hal Renko/Sam Edwards (1983) Terrific Games for the TI-99/4a. 
Addison-Wesley Publishing Company pp.32-42

----------------------------------------------------------------

For proper gameplay, you should have extracted this zip 
file preserving path names.

----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Qui Vive.zrf" in the Open dialog and click "Open"

Qui Vive.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

