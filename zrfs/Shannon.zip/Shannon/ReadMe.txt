********************************************
***                                      ***
*** Shannon v2.0                         ***
***                                      ***
*** Invented by Claude Shannon           ***
*** Implemented by Greg Schmidt.         ***
***                                      ***
*** Copyright (c) 2008.                  ***
*** Uses the Axiom (c) meta-game engine. ***
*** All rights reserved.                 ***
***                                      ***
********************************************
"Shannon" - The Shannon Switching Game

The players take turns placing a bridge that connects two opposing towers of their color.
A player wins by connecting both sides of their color.  Draws are not possible.

The additional variant games limit the number of bridges available to each player.
Once a player's bridges have all been placed, they must be repositioned.

This game is also known as `Gale` or `Bridg-it`.  It has been solved and there is
a published strategy which guarantees a first player win.  Still, if you are unaware
of the strategy, the game may offer a challenge.  Try to develop the winning strategy
on your own.  Also, if you're looking for an additional challenge, try playing second.

Dedicated to Claude Shannon,

 -= The Father of Information Theory (1916-2001) =-