Black & White
-------------

Black&White is a game made by Dan-spil in the 1990's something...

Implemented by Roland Johansson, 2003.


It's a cross between Gomoku, Checkers and Othello !!! 

Two players alternate placing a disc on the board. The object is 
to get 5 in a row on a 5x5-board or to force your opponent out of moves..

Each player has 5 discs and when all discs are on the board, they are
moved, 1 step in any direction.

If it's possible to jump over an opponent disc, you must and that disc
is flipped. Multiple jumps are allowed (by that first disc).

Blackwhite II is different, captures are not mandatory in that variant.

The rules that came with the game doesn't say if captures are mandatory,
so you can play either way.... 


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "blackwhite.zrf" in the Open dialog and click "Open"

blackwhite.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillionsofgames.com> 

