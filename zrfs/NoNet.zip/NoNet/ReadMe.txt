NoNet
-----
Invented and implemented by L. Lynn Smith, June 2004.


NoNet is played on a field divided into nine distinct cells; a central cell, four flanking cells and four corner cells.

Two players, in turn, each place one to nine Seeds to a single cell. There will be no more than nine seeds permitted in any cell.

The object is to avoid "balancing" the cells of the field.  This can be accomplished if every pair of adjacent or opposing cells have the same number of Seeds.

"Balancing" cells are divided into the flanking and corner cells, with the center cell standing alone.  Each of these sets of cells will determine the "balance" of the field.

For example, if two opposing corner cells each contain five Seeds, the other two corner cells each contain three Seeds, two adjacent flanking cells each contain one Seed and the remaining two flanking cells are empty, the field is "balanced" and the player who placed last has lost the game.  "Balance" can also be determined by pairs of adjacent corner cells and pairs of opposing flanking cells.

The center cell is important, as it allows the placement of Seeds and effectively creates a possible passing move.  Of course, a player would be foolish to place anything in this cell with an empty field since the remaining field would then be "in balance" with equally empty cells.  And by filling this center cell with nine Seeds, the player has removed the passing option for the remainder of the game.

A well-played game should end with all the cells of the field containing nine Seeds.  Of course, this means the player who created this position has lost the game.



----------------------------------------------------------------
To play:

Double click the NoNet icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "NoNet.zrf" in the Open dialog and click "Open"

NoNet.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

