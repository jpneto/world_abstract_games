Roll 4
------
Implemented by Nagy L�szl�, February 11, 2001.

Rolling-Connect-4 (7x7):
The player rolling four own balls in a row will win. 
The balls can be rolled onto the board from the edge until they are hit.
So, you will have to click twice to make a move: 
one click to put your ball down and another to roll it in.


Hunted from somewhere on the Internet by Istv�n Vir�g under the 
name CONNECT 4X4.

It's popular in Hungary for approx. two years.

----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Roll4.zrf" in the Open dialog and click "Open"

Roll4.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

