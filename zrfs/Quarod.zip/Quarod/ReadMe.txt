QUAROD
------

Quarod was invented by Luis Bola�os Mures in December, 2020.

Zillions implementation by Luis Bola�os Mures.

--------------------------------------------------------
To play:

Double click the Quarod game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Quarod.zrf" in the Open dialog and click "Open"

Quarod.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com>

--------------------------------------------------------
Quarod is a finite territory game for two players: Black and White. It is played on the spaces (squares) of an initially empty square board.

Each player must have access to a sufficient number of square-shaped pieces of their own color. Each piece has a line (rod) connecting its center to the center of one of its edges.

DEFINITIONS

In these rules, "adjacent" always means "orthogonally adjacent".

Two adjacent opposite-colored pieces are engaged to each other if their rods form a single continuous line.

A group is a piece along with all other pieces one could reach from it through a series of steps between adjacent like-colored pieces. Thus, all pieces in a group are the same color.

The size of a group is the number of pieces in it.

PLAY

On your turn, if possible, perform exactly one of these actions:

- Place two pieces of different colors on adjacent empty squares so that they are engaged to each other.

- Swap the positions of two adjacent pieces of different colors that are already engaged but not to each other, and rotate them so that they are engaged to each other.

If you have no moves available, you must pass. Passing is otherwise not allowed.

The game ends when both players pass in succession. Then, the players jointly remove pairs of opposite-colored groups of the same size until there are no more such pairs to remove. The player with the biggest group left over wins. If the board is empty, whoever made the last move before the game's end loses.

PIE RULE

The pie rule is used in order to make the game fair. This means White will have the option, on their first turn only, to swap sides with their opponent instead of making a regular move.

NOTES

The win condition is not checked by the program. Players have to manually count the scores.