Lewthwaite's Game
Invented by G. Lewthwaite
Rules file and graphics (c) 2002 W. D. Troyka
dtroyka@justice.com


Take turns moving a piece orthogonally into the empty square.  Win by 
stalemating the opponent.

Lewthwaite's Game is more of a puzzle than a game.  It has been proven a 
win for the second player.  In Winning Ways For Your Mathematical Plays, 
the authors suggest adding a rule:  A player may slide a connected row or 
column of stones (up to four) provided both ends of the moving group belong 
to the player.  Even with this rule change, however, the game remains a 
simple win for the second player, as the computer will quickly demonstrate.

At the World of Abstract Games web site (www.di.fc.ul.pt/~jpn/gv), where 
the game is profiled, Joao Pedro Neto suggests a "switch rule" whereby a 
stone adjacent to the empty square can swap with an adjacent enemy stone.  
This rule addition, coupled with the requirement that the opponent cannot 
swap the same two stones on the next turn, appears to make the game more 
competitive.

This file includes the original game, a "push" variant incorporating the 
rule suggested in Winning Ways, a "swap" variant following Neto's suggestion, 
and a combination push and swap variant.


----------------------------------------------------------------

To play:

Double click the Lewthwaite game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Lewthwaite.zrf" in the Open dialog and click "Open"

Lewthwaite.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play 
any number of games against the computer or over the Internet. 
Zillions of Games can be purchased online.  For more information,
please visit the Zillions of Games website:

              <http://www.zillions-of-games.com> 
