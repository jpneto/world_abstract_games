Alak
----
Invented by A. K. Dewdney 
Modified by A. Baljeu 
Implemented and circular variant by V. Everaert, February 2003.

Updated February 8, 2003: added board; included ZoG 1 compatible zrf (by Alfred Pfeiffer)


Alak is a pseudo-Go played on a line. 

Players alternate moves in dropping new stones on the board. 
When a piece takes the last liberty of an enemy stone or group, this stone or    
group is captured (immediately). 
It is forbidden to drop a stone on places left vacant by the last enemy capture    
(if he captured pieces). 
The winner is designed by the number of stones on the board when a player is    
stalemated. 


Zillions thinks that the game is a draw, on sufficiently long boards. 
So, you should not lose ! (Could it be so easy ?) 


----------------------------------------------------------------
To play:

Double click the Alak game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Alak.zrf" in the Open dialog and click "Open"

Alak.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

