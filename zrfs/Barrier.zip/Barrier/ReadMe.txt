Barrier v1.1
------------
Invented and implemented by Karl Scherer, November 2002.
Updated January 12, 2008: code improved


Object: Build fences and stalemate your opponent.
(5 variants)

First the players drop a Rabbit each.
A Rabbit moves similar to a chess knight, but in two steps rather than one.
First it moves one (two) step(s) in one direction, then two (one) step(s) orthogonally.
Hence each player has two moves per turn.

All positions moved to or jumped over turn into an impenetrable barrier
for both players.

You lose if you are stalemated. 

The other variants use larger boards.


More freeware and real puzzles and games at my homepage: karl.kiwi.gen.nz .


----------------------------------------------------------------
To play:

Double click the Barrier icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Barrier.zrf" in the Open dialog and click "Open"

Barrier.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
