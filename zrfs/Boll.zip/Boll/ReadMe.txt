Boll's Game
-----------
Invented by David Boll, implemented by Matthew M. Burke. March 2003.


In Boll's game, the object is to eliminate all your opponent's pieces.  
There is, however, no capture.  Each player has a set of pieces each of 
which moves like a Chess Rook.  There also is a set of pieces that belong 
to neither player.  These neutral pieces move in the same fashion (as a 
Chess Rook) and can be moved by either player on her turn. 

At the end of a turn, if exactly two types of pieces are orthogonally 
adjacent, then they are all changed to be the third type.  Thus, if at 
the end of the move, a neutral piece and one of your opponent's pieces 
are adjacent, they are both changed into your pieces. 

Please send any comments or bug reports to zrfwriter@bluedino.net .


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Boll.zrf" in the Open dialog and click "Open"

Boll.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

