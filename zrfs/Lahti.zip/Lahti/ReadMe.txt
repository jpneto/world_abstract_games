Lahti
-----
Invented and implemented by Markus Salo, September 2003.


Both players take turns placing their four pieces on the board.
When done, the pieces are can be moved orthogonally or diagonally to the next square.
Enemy pieces are captured by jumping.  Capturing is mandatory.
Multiple capture jumps must be made if possible.
The goal is to capture all enemy pieces or move your last piece on the marked square.

This game is a variant of my earlier game Vilbergen.

Lahti is a city in Finland where I live and work at the moment.


----------------------------------------------------------------
To play:

Double click the Lahti game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Lahti.zrf" in the Open dialog and click "Open"

Lahti.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

