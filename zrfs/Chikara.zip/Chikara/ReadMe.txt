Chikara
---------------
Created by Chris Huntoon, 2011
Please send any feedback to Hartunga66@yahoo.com

Chikara is an attempt to 'modernize' Hasami-Shogi and make it more appealing and challenging to contemporary players.

Object: Get 5 pawns in a line in any direction, within the 5 rows on your opponent's side of the board. A player may also win by reducing their opponent's pieces to 4 or less, thus making it impossible for their opponent to form a line of 5.

The pieces slide like Queens in Chess, i.e. any number of empty spaces up, down, left, right, or diagonally.  A piece can also make a single jump in any direction over another piece of either color that is adjacent to it.  The jumping piece lands on the other side.  This is not a capture.  The only capturing is achieved by sandwiching your opponent's pieces between yours along a row, column or diagonal.  This is similar to Reversi, except that the pieces are removed from the board instead of flipped.

The War variant is played the same as the primary game. The only difference is that the 5-in-a-row goal is removed, while the goal of reducing your opponent to 4 pieces or less remains.  So the focus of the game becomes one of pure elimination.  

Because in the War variant there is less motivation to move pieces from one's home ranks,  a sandwich capture along an edge may wrap around the corner.
----------------------------------------------------------------
To play:

Double click the Chikara game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Chikara.zrf" in the Open dialog and click 
   "Open"

Chikara.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 