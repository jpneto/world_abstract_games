Chase II
--------
Invented and implemented by Karl Scherer, November 2001.


Object: Stalemate the opponent's king.
(20 variants)

Firstly each player drops a King.
Then each player has a double move:
First you move your King, then you drop a blocking square. 

If the king is enclosed by eight blocking squares, he is stalemated if he 
does not have an 'escape route'. An 'escape route' are two adjacent blocks 
positioned of the same colour pointing in one of the four orthogonal directions 
of the king's position.  The king may then move onto the first of these blocks 
and capture it. 

You lose if you are stalemated.  
 
In variants 2, 3, 4, 5 another piece is used instead of the king.
Note that King, Knight and Bishop move differently from the way they move in chess.

In variants 6, 7, 8, 9, 10 you are only allowed to escape three times.

Variants 11 to 20 are like variants 1 to 10, but the escape route has to be
of your own colour.


More freeware and real puzzles and games at my homepage: karl.kiwi.gen.nz .


----------------------------------------------------------------
To play:

Double click the Chase2 icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Chase2.zrf" in the Open dialog and click "Open"

Chase2.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
