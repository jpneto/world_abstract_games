Isolation
---------
Invented by Bernd Kienitz, 1978
Implemented by Keith Carter and Greg Schmidt, March 2009.
Graphics by Keith Carter


Object: Isolate your opponent so they cannot move.  On your turn move your pawn one space in any direction, then punch out any empty square except the two starting squares.

The alternate graphics show which player punched which hole in the board. 

This game uses the Axiom plug-in engine for Zillions


Based on Isolation designed by Bernd Kienitz and published by Lakeside 1978. The board spaces were made of plastic with flexible corners and you literally did punch holes in the playing field.  A variant of this without the non-removable starting squares was done for Zillions as Isola by L. Lynn Smith in May of 2002.
       

----------------------------------------------------------------
To play:

Double click the Isolation game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Isolation.zrf" in the Open dialog and click "Open"

Isolation.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

