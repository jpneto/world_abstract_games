Bagels
------
Created 2009, Impelemented 2011
Copyright (c) 2011, Chris Huntoon
Please send any feedback to Hartunga66@yahoo.com


A common defense strategy in Checkers is to keep a piece on the edge of the board so it can not be jumped.  This game is played on an edgeless board - a torus.  That means all pieces are equally exposed to capture. The top and the bottom of the game board are considered to be connected, as well as the two sides with each other, forming a donut - or bagel - shaped playing field.

A secondary effect of playing on a torus is there is no need for Kings.  A piece leaving one edge of the board will simply be re-entered at the appropriate space on the other edge.

Object: Capture all your opponent's Bagels by jumping over them, or stalemate the opponent so he has no moves.

Bagels move one square diagonally forward, but may capture in any of the five non-retreating directions - vertically, diagonlly forward, or sideways.  Jumping over a piece captures it.  Capturing is mandatory, and you must keep jumping and capturing as long as it is possible, taking the maximum number of pieces


----------------------------------------------------------------
To play:

Double click the Bagels game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Bagels.zrf" in the Open dialog and click 
   "Open"

Bagels.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 