4-line Gonu
-----------

This is custodianship Gonu game. Balls move one square orthogonally.
Two balls adjacent capture the enemy's ball, if that same line has a 
free square.

To win, capture all the enemy's balls or stalemate him.

