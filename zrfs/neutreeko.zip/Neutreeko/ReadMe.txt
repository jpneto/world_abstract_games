Neutreeko
---------
Invented by Jan Kristian Haugland in 2001. 
Implemented by Jonathan Welton, April 2002.
Updated June 9, 2002: added a 5x4 variant.


The name Neutreeko is a contraction of Neutron, from which the method of movement
is derived, and Teeko, from which the object of the game is derived.

Pieces move by sliding orthogonally or diagonally until blocked by the edge 
of the board or another piece.
The object of the game is to arrange your pieces in a line of three either 
orthogonally or diagonally.

For more information visit http://www.neutreeko.com


----------------------------------------------------------------
To play:

Double click the Neutreeko game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Neutreeko.zrf" in the Open dialog and click "Open"

Neutreeko.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

