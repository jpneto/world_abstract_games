***********************************************
***               o Splay o                 ***
***                                         ***
*** Designed and programmed by Greg Schmidt ***
***   for the rec.games.abstract stacking   ***
***   games contest in 2011.                ***
***                                         ***
*** gschmidt958@yahoo.com                   ***
***                                         ***
*** Utilizes the Axiom Meta-Game System.    ***
*** Copyright 2011.  All rights reserved.   ***
***********************************************

Splay - A Stacking Game of Territorial Conquest

Splay is a two player abstract strategy game. The object of the game is to acquire more
territory than your opponent. The two players, called �white� and �black�, alternately take
turns placing their pieces on the playing field, or stacking them on their previously played
pieces. Once a piece is played, it is never removed from the board. Splay is a game where the
players are constantly battling for territory acquisition. A space which has a player�s piece(s)
on it represents a unit of territory which is owned by that player. A �tower� consists of one or
more like-colored checkers stacked on top of one another. A tower represents potential for
acquiring additional territory. Players who utilize their towers effectively will gain a territorial
advantage. Towers can also pose a liability so they must be developed with care.

Splay was inspired by the process by which borders are formed between competing entities.

Please refer to "Splay_Rules.pdf" for a complete description of the rules.

Splay placed first in the 2011 rec.games.abstract stacking games contest.

Note: A free stand-alone version of Splay with improved graphics and animation can be
downloaded from: http://www.mindsports.nl/index.php/axiom