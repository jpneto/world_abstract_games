-----------------------------------------------
*** Chip - checkers that flip               ***
* * adapted by K. Franklin, Dec 26, 2001    ***
* *                                         * *
* * Updated v1.1, Jan 2015 (win-conditions) * *
* * e-mail: frnklnk@yahoo.ca                * *
-----------------------------------------------

*** based on Zillions Development's Checkers.zrf  v1.2 (and images)
*** Copyright 1998-2000 Zillions Development

You need to purchase Zillions of Games to load this rules file
Visit the Zillions web site at http://www.zillions-of-games.com
---------------------------------------------------------------
v1.1 update:
Extra win-conditions for partial moves gaining multiple opponent King Checkers.
Board and piece image sets re-sync'd for both Zillions program v2 and v1.
The NE-Diagonal layout subvariant is dropped.


The same old game with a new twist:

It's Checkers but with Owner switching instead of Captures.
The revised Goal is to achieve 6 King Checkers or reduce the opponent to 5 standard checkers.
Repetition is a loss condition & 'No-Move Forced' Passing is allowed
In the variants, the number of King Checkers & standard checkers is adjusted to reflect approx. 
half of a player's opening total.  	 

As usual, Checkers can only move diagonally forward, either by sliding to an adjacent 
empty square or by jumping over an enemy piece to a vacant square on the other side.
But,
Jumping over an opponent's piece SWITCHES it.  Jumping is mandatory *, and you must keep
jumping and checker flipping as long as it is possible.
When your Checker reaches the other end of the board, it becomes a King and can then also move 
diagonally backwards.
* Note that this version does not contain the requirement that a player must choose the 
maximum number of available captures.


-------------------------------------------------------------------
The board (and checkers) may be switched with the standard Zillions 
board by selecting "Switch Piece Set" from the "View" menu.

Two colour schemes: Black & White checkers on a Double Blue board,
and the basic Black & Red layout.

You should extract the game preserving path names. 


-------------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Chip.zrf" in the Open dialog and click "Open"

Chip.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 


 