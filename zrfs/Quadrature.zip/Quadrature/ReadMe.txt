Quadrature (version 2.0)
------------------------

Conceived of by Mark Steere.
Graphics by Keith Carter.
Game development by Karl Scherer and Greg Schmidt.

Updated February 14th, 2009: Improve playing strength


INTRODUCTION:
Quadrature is a unique board game for two players.  Each player has 18 men and
two types of 'markers'.  A marker has one or two vertical bars imprinted on its
face.  A player's marker is the same color as his men.  There are two goal
positions, one for each player, consisting of three locations.

OBJECT OF THE GAME:
There are two ways to win in Quadrature.  One is to reduce the number of on-board,
opposing men to two or less.  The other is to advance three of your men into the
goal position in your furthest row.

BASIC MOVES:
Players take turns making basic moves, one basic move per turn.  You begin your
turn by moving one of your men one location directly forward, diagonally forward,
or sideways to an unoccupied location.  If you have no moves available, you must
sit the game out until you do have a move available.  Players are not otherwise
allowed to pass on their turn.  If neither player has a move available, the game
is a draw.  A draw can also occur due to repitition.

SQUARING:
If you move to form a rectangle (henceforth 'rectangle') with horizontal and vertical
sides defined by three of your men and one opposing man, you have 'squared' the
opposing man.  At such time you must immediately remove your opponent's man from
the board and replace it with one of your off-board pieces - this is called an
'exchange'.  Note that there is an unlimited supply of off-board pieces.  If the
result of an exchange causes further 'squaring', then the current player continues
to exchange pieces.  A single squaring and exchange can trigger a cascade of further
squaring and exchanges.  The current player continues until no further exchanges
are possible.  At that time, the turn is concluded.

You are not allowed to move a man to a location which is squared by your opponent.
That is, you cannot move to form a rectangle defined by your moved man and three
opposing men.  However, by way of exchange, you may add men onto locations which
are squared by your opponent.

If, at the outset of your turn, opposing men are already squared by your men, you
cannot begin you turn by exchanging said opposing men.  You must begin your turn
with a basic move, and you can only initiate exchanges on opposing men which were
squared by your current move, or which were squared by men which you added to the
board during your current turn.

MARKER:
If you make a non-squaring, sideways move while your marker is not on the board,
your marker with the single bar, is placed on the board while it is still your turn.
If you make a non-squaring, sideways move while your marker is on the board with
the single bar showing, the marker is replaced with one that has two bars.  If your
marker is on the board with double bars showing, you cannot make a non-squaring,
sideways move.  If you make a forward, diagonally forward, or squaring sideways
move, your marker is removed from the board.

For additional information, see 'Quadrature_rules.pdf'.")


For additional information, see 'Quadrature_rules.pdf'.")
Quadrature uses the "Axiom" Meta-game engine.

----------------------------------------------------------------
This game requires the "Zillions of Games" program.  Please
visit <http://www.zillions-of-games.com> for details.
----------------------------------------------------------------