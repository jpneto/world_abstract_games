Guard and Towers
----------------
Invented by Christoph Endres and Robert Wirth, 1997, 
implemented by Jens Markmann, January 2002.


Every player starts with one Guard and seven Tower pieces.
The goal of the game is to either capture the enemy Guard or move your own
Guard to the marked square on the enemy side of the board.

All pieces move orthogonally only.
The Guard steps one square, capturing
anything on its destination square.

A Tower steps exactly as many squares as the number of pieces it consists of.
It can capture the enemy Guard or an enemy Tower by replacement, but only if the
enemy Tower consists of equal or less pieces. A Tower cannot jump. However,
smaller Towers may be split off from it, which move according to their height too
(this is done by clicking on the destination square for the sub-Tower).


For further information please check:
www.turm-und-waechter.de (german)
www.gameplate.org (english)


----------------------------------------------------------------
To play:

Double click the GaT icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "GaT.zrf" in the Open dialog and click "Open"

GaT.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
