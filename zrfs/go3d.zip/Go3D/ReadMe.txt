Go 3D
-----
Developed and implemented by L. Lynn Smith, October 2001.


Go3D is a two-player game played upon a 5x5x5 field and
follows the rules of 2D Go.

Black begins the game with 63 Stones, White with 62.

Like in 2D Go, you must deny your opponent's Stones their
'liberties' in order to capture them.  In Go3D, there are
potentially two extra 'liberties', one above and one below.

The 'ko' rule is enforced.

The ending of the game after one player passes two consecutive
turns is enforced by the players.

When the last stone is played, or there are no legal moves, or
both players pass together, the game is over.  The players must
calculate their own scores.

The Go player should find this game a fair challenge.


Go is considered both the oldest and the most challenging game
in the world.  Go3D represents the latest step in this great
game's evolution.


----------------------------------------------------------------
To play:

Double click the Go3D icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Go3D.zrf" in the Open dialog and click "Open"

Go3D.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
