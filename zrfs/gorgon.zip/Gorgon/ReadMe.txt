Gorgon
------
Created by Chris Huntoon, May 2001.


Object: Completely immobilize your opponent's forces. 
�
A Gorgon moves diagonally forward, sliding to an adjacent empty 
square. A Gorgon may petrify an opponent's piece by jumping over 
it to a vacant square on the other side. A petrified piece is 
unable to move and blocks the space it occupies for the remainder 
of the game. 
Jumps may be in any of the five nonretreating directions: vertically, 
diagonally forward, and sideways. Multiple jumps are possible. 
�
The top and bottom of the board are considered to be connected, as 
if forming a tube. A piece leaving one edge will be re-entered at 
the appropriate space on the other edge. 
�
The first player unable to make a move on his turn, loses.


----------------------------------------------------------------
To play:

Double click the Gorgon icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Gorgon.zrf" in the Open dialog and click "Open"

Gorgon.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

