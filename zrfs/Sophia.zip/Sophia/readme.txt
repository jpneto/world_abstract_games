Object:
   To get a certain number of pieces in a row, either vertically, horizontally or diagonally of a
color/pattern a player selected at start of game as their winning color/shape.  The winning color/shape
could be one of a piece controlled by either player.  



Order of play:
    Play consists of two phases.  These phases are placement phase and movement phase.  In either
phase a player could win the game.

Phase 1, Placement: 

Players alternate turns placing one of their piece on an empty space on the board.  Pieces place
consist of the type of piece placed, rather than the color of the piece.  For example, assume one
player controls pennies, while the other player controls dimes.  Play would follow with the player
who controls pennies going first, placing one of their pennies on the board, on an empty space. 
The player who controls the dimes would then place one of their dimes on the board. 
Player alternates until both players have placed all of their pieces on the board, or one player has
won the game.  When done placing pieces, there should be 2 vacant spaces left on the board. 
Important note: Each player may place one of their pieces on the board, either color side up. 
There may be times where a player may want to put one of their pieces on the board the color
needed for his opponent to win, rather than the color he needs to win. 

Phase 2, Movement: 

If a player is able to move a piece he must make a move.  If a player cannot make a move, their
turn end and their opponent's turn begin. 
During a turn, if a player can make a move, they must move one, and only one, of their pieces. 
Players keep alternating turns until one player reaching their winning objective. (See Object of the
Game section). 
There are two types of movement, slides and jumps:
A. Slide move:
  1. A player moves one of their pieces to an unoccupied adjacent space, either vertically,
horizontally or vertically (depends on variant).
B. Jump move:
  1. A player jumps one of their pieces over a piece, either theirs or their opponents, and lands on
an empty space.
  2. The pieces jumped over then is flipped over and its color (or pattern) is changed.  It is
possible by jumping over a piece a player could cause a winning condition for their opponent.  In
this case, the player's opponent would win the game.  In the event that such a move would cause
both players to reach a winning condition, the players' opponent would be considered to be the
victor.



Description of variants:
- No diagonal win.  Players win only if they get a certain number of pieces in a row in a line
vertically or horizontally.  The number in a row needed depends on variant.
- Diagonal win. Players also win the game if they get a certain number of pieces in a row diagonally.
- No diagonal movement.  Pieces only move vertically and/or horizontally (neither jump capture nor slide diagonal also).
- Diagonal movement.  Pieces also can move (slide or jump) diagonally.
- 4x4 board or 6x6 board. The 6x6 board leads to a more strategic type game.
- (N pieces each).  N = the number of pieces a player gets at start of game.
- N in a row.  N = the number of pieces in a row needed to win.



Closing Comments:
    I found a used copy of Rubik's Magic at a flea market for 50 cents, along with some other
games. I purchased it and found out 
it was missing the rules.  Upon pondering what the rules might be for the game, I came up with
the rules above, with the exception 
of placing pieces down either color side up (I added this rule later).  I tried the game with other
people and found out that it 
played real well and people enjoyed it.  I later found out what the actual rules were to Rubik's
Magic.  With the exception of the 
types of pieces that are used, the rules I created for the game are almost completely different than
those of Rubik's Magic.
    I do want to thank Guenther Rosenbaum and David Wichert for helping to get this game implemented in Zillions.  Without their
help, Sophia likely would not have been ported to Zillions.  Also, I want to thank anyone else who may of helped that I have not
mentioned.