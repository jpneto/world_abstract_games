*********************************************************************
*** Orbitalis V2.0                                                ***
***                                                               ***
*** Implemented by Greg Schmidt, 2008.                            ***
*** All rights reserved.                                          ***
*** Please send comments and suggestions to gschmidt958@yahoo.com ***
*********************************************************************

Orbitalis - A Game of Valence

The object of the game is to create the most particles.  Players take turns dropping a
proton on an empty cell.  When a proton is dropped, the surrounding cells are examined
in order to determine if an electron is to be created there or not.  An electron is created
in a surrounding cell if there is a majority of one color's protons surrounding that cell.
In that case, the newly created electron takes on that color and orbits the surrounding
protons.  If the number of surrounding protons of either color is the same, then an electron
is not created in that cell, or if the cell already contains an electron, that electron vanishes.

The score indicators display the total number of particles owned by each player.  The
game ends when no remaining proton placements are available.  The player with the
most particles wins.  Ties are not possible.

Please refer to "Orbitalis.pdf" for the official rule sheet.


NOTE:
A free stand-alone version of this game may be downloaded from:
http://www.boardgamegeek.com/filepage/88369/orbitalis-axiom-pc-game