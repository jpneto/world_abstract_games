Bolotoudou
----------
2 variants

Bolotoudou is a traditional West African game.
Arrange the pieces as "3 in row" and capture opponent's pieces.

Implemented by: Valentin Chelnokov
Graphics by: Peter Aronson
