Lambchop
(c) 2001  W. D. Troyka
dtroyka@justice.com


(Requires ZoG v.1.3 or higher!)

Lambchop is a simple and intuitive game well-suited for young 
children -- in particular the default one-sheep version with "smart 
moves" on -- but it is by no means trivial.

Your mission is simple:  Drop your sheep onto any square, then 
on each turn move it one space in any direction, orthogonally or 
diagonally, eating any grass it lands on.  Win by eating more than 
half the grass on the board.

The amount of grass you eat is tracked by a patented Grass-o-Meter 
on the right side of the board.  The winning position for each player 
is marked by a little flag.

In the variants you have multiple sheep, with flocks ranging from 
one to seven.  All sheep must be dropped before any can be moved.

Lambchop is a basic game that poses an age-old problem:  In the 
struggle for existence, who gets more food?  The principal strategy 
comes naturally.  You want to eat your opponent into grazed portions 
of the board, leaving your own sheep free to chomp the remaining 
grass.  But this is not always so easy, and delicate tradeoffs 
must be made.  Should you eat this patch of grass in the corner? 
Or should you rush across grazed portions of the board to a 
larger patch of grass, so your opponent does not eat it first?
Such is life in the pasture.

Lambchop is designed to be immediately playable with a minimalist 
rule set.  In this it follows the mold of Breakthrough, Sidewinder, 
and Zonesh.


----------------------------------------------------------------
To play:

Double click the Lambchop game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Lambchop.zrf" in the Open dialog and click "Open"

Lambchop.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information,
please visit the Zillions of Games website:

              <http://www.zillions-of-games.com> 


 