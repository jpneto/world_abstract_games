Dipole (version 2.0)
--------------------

Revision History.
2.0 - Improved graphics and updated to use Axiom version 1.46.
1.1 - Revised initial setup to be symmetrical as per Mark Steere's request.
1.0 - Initial release

Invented by Mark Steere
Implemented by Greg Schmidt (gschmidt958@yahoo.com)

Dipole is played with a Checkers set.  Only the dark squares can
be occupied.  The game starts with two stacks of 12 checkers, one
red and one black. To win, all of your opponent's checkers must
be removed from the board.  Draws cannot occur.

BASIC MOVES:
Players take turns moving stacks of their own checkers, one stack
per turn.  Red moves first.  You can move an entire stack or just
a portion of it.  A non-capturing move must be made forward or
diagonally forward.

If your move takes your stack out of bounds, then you must remove
that stack from the board.

If you have no moves available, you must pass until you do have a
move available.  If you have any moves available, you must move.
There will always be a move available to one player or another.

MERGING MOVES:
Stacks can be moved onto other, like-colored stacks. The merged
stack gains the same number of pieces as the number of spaces
moved.  The original stack is reduced by the same amount.
Merging moves are always made forward or diagonally forward.

CAPTURING MOVES:
Capturing moves can be made in any of the eight directions.  A stack
can capture only an entire enemy stack, which must be of an equal
or smaller size than the capturing stack.

For additional information, see 'Dipole_rules.pdf'.")

Dipole uses the "Axiom" Meta-game engine.

----------------------------------------------------------------
This game requires the "Zillions of Games" program.  Please
visit <http://www.zillions-of-games.com> for details.
----------------------------------------------------------------