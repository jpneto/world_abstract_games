Kings of Babylon
----------------
Invented and implemented by Markus Salo, January 2002.


Win by moving your king to the opposite side corner.  

Pieces move like Rooks in Chess and enemy pieces are captured by
surrounding them from two opposite sides.
To capture enemy King it has to be surrounded from all four
(three if the King is on the edge of the board) sides.

The Black Squares can only be entered by the King
and they can be used to capture opponent pieces like in Tafl.


Kings of Babylon is a variant of Ancient Boardsgames, the Latrunculi 
and Hnefatafl.


----------------------------------------------------------------
To play:

Double click the Kings of Babylon icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Kings of Babylon.zrf" in the Open dialog and click "Open"

Kings of Babylon.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
